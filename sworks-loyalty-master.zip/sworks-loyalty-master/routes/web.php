<?php

use App\Http\Controllers\AccessController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\DynamicSessionController;
use App\Http\Controllers\PDfController;
use App\Http\Controllers\RegionController;
use App\Http\Controllers\TextSmsController;
use App\Http\Controllers\TransController;
use App\Http\Controllers\UserPermissionsController;
use App\Http\Middleware\EnsureIsAuthenticatedTrans;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoyaltyController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\VerifySigninController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\ConfirmablePasswordController;
use App\Http\Controllers\Auth\EmailVerificationNotificationController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\Auth\ManageUserController;
use App\Http\Controllers\Auth\VerifyEmailController;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/**
 * Route Encryption
 * 
 */
// routes/api.php
Route::post('/param/encrypt', function (Request $request) {
    $validated = $request->validate(['value' => 'required']);

    return response()->json([
        'encrypted' => Crypt::encrypt($validated['value'])
    ]);
});

Route::get('error', function () {
    return Inertia::render('Error/Index');
})->name('error.page');

Route::get('getUsers', [ManageUserController::class, 'index'])->middleware('dynamic.connection');

Route::middleware('guest')->group(function () {
    //Route::controller(RegisteredUserController::class)->group(function () {
    //    Route::get('register', 'create')->name('auth.register');
    //   Route::post('register', 'store');
    //});

    // Route::controller(AuthenticatedSessionController::class)->group(function () {
    //   Route::get('admin_login', 'adminCreate')->name('admin.login');
    //     Route::post('admin_login', 'adminStore');
    // });

    Route::controller(AuthenticatedSessionController::class)->group(function () {
        Route::get('login', 'create')->name('login');
        Route::post('login', 'store');
    });


    Route::controller(PasswordResetLinkController::class)->group(function () {
        Route::get('forgot-password', 'create')->name('password.request');
        Route::post('forgot-password', 'store')->name('password.email');
    });

    Route::controller(NewPasswordController::class)->group(function () {
        Route::get('reset-password/{token}', 'create')->name('password.reset'); //http://localhost:8000/reset-password/4a053d43a921ab12ecd7d54e6308a551aa5c3dd47988f114a14feb3fbf128b05?email=danson%40sworks.co.ke
        Route::post('reset-password', 'store')->name('password.store');
    });
});

Route::middleware('auth')->group(function () {
    Route::get('verify-email', [VerifyEmailController::class, 'index'])->name('verification.notice');

    Route::get('verify-email/{id}/{hash}', VerifyEmailController::class)
        ->middleware(['signed', 'throttle:6,1'])
        ->name('verification.verify');

    Route::post('email/verification-notification', [EmailVerificationNotificationController::class, 'store'])
        ->middleware('throttle:6,1')
        ->name('verification.send');

});

Route::middleware(['auth', 'verified'])->group(function () {
    //set password on first logon
    Route::controller(NewPasswordController::class)->group(function () {
        Route::get('/set-password', 'index')->name('first.logon');
        Route::post('/set-new-password', 'storePassword')->name('first.logon.store');
    });

    //Authorize access with unique code
    Route::controller(VerifySigninController::class)->group(function () {
        Route::get('/authorize/{token}', 'authView')->name('auth.session');
        Route::post('/resend-code', 'ResendCode')->name('auth.resend');
        Route::post('/authorize', 'verify')->name('auth.verify');
        Route::get('/verify-code', 'verifyCode')->name('auth.verifyCode');
    });


    Route::get('logout', [AuthenticatedSessionController::class, 'destroy'])
        ->name('logout');
});

Route::middleware(['auth', 'verified', 'auth.code', 'auth.first.login'])->group(function () {

    Route::get('signout', [AuthenticatedSessionController::class, 'signout'])
        ->name('signout');

    Route::get('logout-all', [AuthenticatedSessionController::class, 'destroyAll'])
        ->name('logout.all');

    //select company sesion for multi-access user
    Route::controller(DynamicSessionController::class)->group(function () {
        Route::get('/authenticate-session/{token}', 'index')->name('companySelect');
        Route::post('/authenticate-session', 'store')->name('store.sessionCompany');
    });
});

//Dynamic routes for authenticated users with company access
Route::middleware(['auth', 'verified', 'auth.code', 'auth.first.login', 'auth.master', 'dynamic.connection','route.encrypt'])->group(function () {


    Route::get('/app/license-manager/validate/company', function () {
        return Inertia::render('Company/LicenseManager');
    })->name('license.index')->withoutMiddleware('valid.company');

    Route::controller(HomeController::class)->group(function () {
        Route::get('/', 'index')->name('home');
        Route::get('/get-dashboard-data', 'show')->name('home.show');
        Route::get('/dashboard/getCustomers', 'showCustomers')->name('dashboard.show');
    });


    Route::controller(LoyaltyController::class)->group(function () {
        Route::get('/search-cust', 'searchCust')->name('loyalty.search');

        //loyalty masters
        Route::get('/loyalty/masters', 'masterIndex')->name('loyalty.master.index');
        Route::post('/loyalty/masters/location', 'storeLocation')->name('loyalty.master.location.store');
        Route::patch('/loyalty/masters/{id}/location', 'updateLocation')->name('loyalty.master.location.update');
        Route::delete('/loyalty/masters/{id}/location', 'destroyLocation')->name('loyalty.master.location.destroy');
        Route::post('/loyalty/masters/group', 'storeGroup')->name('loyalty.master.group.store');
        Route::patch('/loyalty/masters/{id}/group', 'updateGroup')->name('loyalty.master.group.update');
        Route::delete('/loyalty/masters/{id}/group', 'destroyGroup')->name('loyalty.master.group.destroy');

        Route::get('/loyalty/bulk-masters', 'showMasters')->name('loyalty.master.show');
        Route::get('/loyalty/bulk-count', 'custCount')->name('loyalty.count');

        //assign customer group or location
        Route::post('/loyalty/masters', 'assignMaster')->name('loyalty.master.assign');

        //customers
        Route::get('/customers', 'index')->name('loyalty.index');
        Route::get('/create-customer', 'create')->name('loyalty.create');
        Route::post('/save-customer', 'store')->name('loyalty.store');
        Route::get('/customer/{id}/edit', 'edit')->name('loyalty.edit');
        Route::patch('/customer/{id}', 'update')->name('loyalty.update');
        Route::delete('/customer/{id}', 'destroy')->name('loyalty.destroy');

        Route::get('/points-award', 'awardCreate')->name('award.create');
        Route::get('/getcust', 'show')->name('loyalty.show');
        Route::post('/customer/{id}/award-points', 'storePoints')->name('award.store')->middleware(EnsureIsAuthenticatedTrans::class);
        Route::get('/cancel-points', 'awardCancel')->name('award.cancel');
        Route::post('/customer/{id}/cancel-points', 'cancelPoints')->name('points.cancel')->middleware(EnsureIsAuthenticatedTrans::class);

        Route::get('/points-adj', 'pointsAdj')->name('points.adj');
        Route::post('/customer/{id}/adjust-points', 'adjustPoints')->name('award.adjust')->middleware(EnsureIsAuthenticatedTrans::class);

        Route::get('/customer-listing', 'customerList')->name('customers');
        Route::get('/loyalty-balance', 'balanceEnquiry')->name('loyalty.balance');
        Route::get('/get-bal/{id}', 'getBalanceEnquiry')->name('loyalty.enquiry');
        Route::post('/redeem-points', 'redeemPoints')->name('loyalty.redeem');
        Route::get('/loyalty-statement', 'loyaltyStatement')->name('customers.statement');
        Route::get('/loyalty/get-statement', 'loyaltyReport')->name('loyalty.Report');

        Route::get('/export-loyalty', 'LoyaltyExport')->name('exportLoyalty');
        Route::get('/print-loyalty', 'LoyaltyPrint')->name('printLoyalty');

        Route::get('/export-listing', 'ListingExport')->name('exportListing');
        Route::get('/print-listing', 'ListingPrint')->name('printListing');

        Route::get('/trans-listing', 'transListing')->name('trans.create');
        Route::get('/load-trans', 'LoadTrans')->name('trans.load');

        Route::get('/print-trans/{type}', 'LoyaltyPrint')->name('print.Loyalty');

        Route::get('/voucher-listing', 'loyaltyVouchers')->name('vouchers');
        Route::get('/get-vouchers', 'getVouchers')->name('voucherslisting');
        Route::get('/voucher/print/{doc}', 'printVoucher')->name('voucher.print');

        //export & import
        Route::get('/export-template', 'downloadImportTemplate')->name('export.loyalty.template');
        Route::post('/import-customers', 'importCustomers')->name('import.loyalty.customers');
    });

    Route::post('/export-pdf', [PDfController::class, 'exportPDF'])->name('export.pdf');

    //regions
    Route::prefix('regions')->controller(RegionController::class)->group(function () {
        Route::get('/', 'index')->name('region.index');
    });

    //CRM (SMS) routes
    Route::prefix('crm')->controller(TextSmsController::class)->group(function () {
        Route::post('send-bulk', 'storeBulk')->name('crm.send.bulk.post');
    });
});

//General routes which are not dependant on dynamic connections
Route::middleware(['auth', 'verified', 'auth.code', 'auth.first.login', 'auth.master', 'route.encrypt'])->group(function () {

    Route::get('confirm-password', [ConfirmablePasswordController::class, 'show'])
        ->name('password.confirm');

    Route::post('confirm-password', [ConfirmablePasswordController::class, 'store']);

    Route::put('password', [PasswordController::class, 'update'])->name('password.update');

    Route::get('/access/show', [AccessController::class, 'show'])->name('access.show');
    Route::get('/branch/show', [BranchController::class, 'show'])->name('branch.show');

    Route::prefix('user')->controller(UserController::class)->group(function () {
        Route::get('/', 'index')->name('users');
        Route::get('/create', 'create')->name('users.create');
        Route::post('/', 'store')->name('users.store');
        Route::get('/get-user', 'show')->name('users.search');
        Route::get('/company-users', 'getUsers')->name('company.users');
        Route::get('/profile', 'showProfile')->name('user.profile');
        Route::post('/profile/{user}/update', 'updateProfile')->name('update.profile');
        Route::post('/profile/{user}/PasswordReset', 'ProfilePasswordReset')->name('profile.PasswordReset');
        Route::delete('/{user}', 'destroy')->name('users.delete');
        Route::post('/{id}/restore', 'restore')->name('users.restore');
        Route::get('/{id}/edit', 'edit')->name('users.edit');
        Route::patch('/{user}/update', 'update')->name('user.update');
        Route::get('/sys-admin', 'sysAdmin')->name('user.company.admin');
    });

    Route::controller(UserPermissionsController::class)->group(function () {
        Route::get('/permissions', 'index')->name('permissions');
        Route::get('/user/permissions', 'show')->name('user.permissions');
        Route::post('/permissions', 'store')->name('store.permissions');
    });

    //CRM (SMS) routes
    Route::prefix('crm')->controller(TextSmsController::class)->group(function () {
        Route::get('masters', 'masterIndex')->name('crm.master');
        Route::get('masters/show', 'show')->name('crm.master.show');
        Route::post('masters', 'store')->name('crm.store.master');
        Route::get('send-bulk', 'sendBulk')->name('crm.send.bulk');
        Route::get('outbox', 'outbox')->name('crm.outbox');
        Route::get('outbox/trans', 'outboxTrans')->name('crm.outbox.trans');
    });

    //transaction auth routes
    Route::prefix('/trans/auth')->group(function(){
    //transaction routes
    Route::controller(TransController::class)->group(function(){
        //request authentication code
        Route::post('/reqcode', 'store')->name('trans.auth.code');
        //validate code input
        Route::post('/validate', 'authenticate')->name('trans.auth.validate');
    });
    
    });

});

require __DIR__ . '/Oauth.php';
require __DIR__ . '/Settings.php';