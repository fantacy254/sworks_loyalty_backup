<?php

use App\Http\Controllers\DeployController;
use App\Http\Controllers\SmartSyncController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::prefix('v2')->group(function () {
    //API routes
    Route::controller(ApiController::class)->group(function () {
        //Route::get('/accessToken', 'generateAccessToken')->name('AccessTokens');
    });

    Route::middleware(['auth.token', 'auth.client'])->group(function () {
        Route::controller(ApiController::class)->group(function () {
            Route::post('/addSystemUser', 'addSysUser')->name('addSystemUser');
            Route::post('/registerCustomer', 'addLoyaltyCustomer')->name('loyalty.customer.register');
            Route::post('/validateCustomer', 'validateCustomer')->name('loyalty.customer.validate');
            Route::post('/postEarnPoints', 'storeEarnedPoints')->name('loyalty.earn');
            Route::post('/validateVoucher', 'validateLoyaltyVoucher')->name('loyalty.validate.voucher');
            Route::post('/consumeLoyaltyVoucher', 'consumeVoucher')->name('loyalty.consume.voucher');
        });

    });
});

//Deployment hook
Route::post('/deploy', [DeployController::class, 'handle']);
