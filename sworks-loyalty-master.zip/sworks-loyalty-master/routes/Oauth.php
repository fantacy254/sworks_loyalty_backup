<?php

use App\Http\Controllers\BranchController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\DynamicSessionController;
use App\Http\Controllers\OauthController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth', 'master.auth', 'verified'])->group(function () {
    Route::controller(DynamicSessionController::class)->group(function () {
        Route::get('/master-dashboard', 'masterIndex')->name('master.dashboard');
    });

    Route::controller(CompanyController::class)->group(function () {
        Route::get('/company-center', 'index')->name('company.center');
        Route::post('/company', 'store')->name('company.store');
        Route::get('/company/admin/show', 'adminShow')->name('company.admin.show');
        Route::post('/company/admin', 'adminStore')->name('company.admin.store');
        Route::get('/company/sms-usage', 'smsUsage')->name('company.sms.usage');
        Route::get('/company/sms-usage-trans', 'smsTrans')->name('company.sms.trans');
    });

    Route::controller(BranchController::class)->group(function () {
        Route::get('/branch', 'index')->name('branch.index');
        Route::get('/branch/show', 'show')->name('branch.show');
        Route::post('/branch', 'store')->name('branch.store');
    });

    //Oauth routes
    Route::prefix('oauth')->controller(OauthController::class)->group(function () {
        Route::get('/integration', 'index')->name('oauth.index');
        Route::post('/generate-token', 'store')->name('oauth.generate.token');
        Route::post('/generate-branch-token', 'genBranchToken')->name('oauth.generate.branch-token');
    });

});