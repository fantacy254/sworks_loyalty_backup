<?php

use App\Http\Controllers\SettingsController;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes for settings
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['auth', 'verified', 'auth.first.login', 'dynamic.connection'])
    ->group(function () {
        Route::prefix('settings')->controller(SettingsController::class)->group(function () {
            Route::get('/', 'index')->name('settings.index');
            Route::get('/notifications', 'notify')->name('settings.notifications');
            Route::get('/notifications/show', 'showNotify')->name('settings.show.notifications');
            Route::post('/notifications', 'storeNotify')->name('settings.store.notifications');
            Route::get('/privacy', 'privacy')->name('settings.privacy');
            Route::get('/privacy/show', 'showPrivacy')->name('settings.show.privacy');
            Route::post('/privacy/two-factor', 'enableTwoFactor')->name('settings.privacy.2fa');
            Route::post('/privacy/can-sms', 'enableSMSAuthentication')->name('settings.privacy.sms');
            Route::post('/privacy/can-email', 'enableEmailAuthentication')->name('settings.privacy.email');
            Route::post('/notifications/sender', 'updateSender')->name('settings.notifications.sender');
        });
    });