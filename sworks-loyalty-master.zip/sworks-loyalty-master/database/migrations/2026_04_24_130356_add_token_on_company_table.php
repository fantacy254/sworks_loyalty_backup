<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        // Rename column
        DB::statement("
        ALTER TABLE company 
        CHANGE client_sync_key token VARCHAR(300)
    ");

        // Drop columns separately
        Schema::connection('smart_core')->table('company', function (Blueprint $table) {
            $table->dropColumn(['expire_at', 'start_at']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->table('company', function (Blueprint $table) {
            $table->dropColumn('token');
        });
    }
};
