<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::create('loy_masters', function (Blueprint $table) {
            $table->id();
            $table->string('item', 30);
            $table->string('last_no', 20)->nullable();
            $table->string('length', 20);
            $table->boolean('status');
            $table->string('notes', 300);
            $table->timestamps();

            $table->unique(['id', 'item'], 'loy_master_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }
        
        Schema::dropIfExists('loy_masters');
    }
};
