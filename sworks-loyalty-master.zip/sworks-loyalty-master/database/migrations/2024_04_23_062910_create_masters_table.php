<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::create('masters', function (Blueprint $table) {
            $table->id();
            $table->boolean('active');
            $table->string('earn');
            $table->string('redeem');
            $table->string('min_redeem');
            $table->string('last_redeem');
            $table->double('expiry');
            $table->boolean('has_hq');
            //$table->foreignId('company_id')->unique();
            $table->timestamps();

            //$table->foreign('company_id')->references('id')->on('companies');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }
        
        Schema::dropIfExists('masters');
    }
};
