<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::create('loy_customer', function (Blueprint $table) {
            $table->string('accno', 20)->unique();
            $table->string('code', 20)->unique(); //customer ID no
            $table->string('name', 50)->unique();
            $table->string('email', 30)->nullable();
            $table->string('phone', 50)->unique();
            $table->string('pin_no', 11)->unique()->nullable();
            $table->double('bal_bf')->nullable();
            $table->double('actual_bal')->nullable();
            $table->boolean('active')->default(false);
            $table->string('address')->nullable();
            $table->string('input_by', 15)->nullable();
            $table->string('edit_by', 15)->nullable();
            $table->string('card_no', 20)->nullable();
            $table->foreignId('branch_id');
            $table->string('gender', 1)->nullable();
            $table->date('dob')->nullable();
            $table->timestamps();

            $table->softDeletes();

            $table->foreign('branch_id')->references('id')->on('branch');
            $table->unique(['code', 'branch_id'], 'loy_customer_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    { 
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::dropIfExists('loy_customer');
    }
};
