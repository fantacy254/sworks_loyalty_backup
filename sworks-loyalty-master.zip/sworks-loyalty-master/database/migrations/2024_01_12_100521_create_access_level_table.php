<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->create('access_level', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('notes');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->dropIfExists('access_level');
    }
};
