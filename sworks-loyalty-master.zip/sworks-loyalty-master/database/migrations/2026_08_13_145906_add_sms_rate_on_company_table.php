<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')
            ->table('company', function (Blueprint $table) {
                $table->after('sender_id', function ($table) {
                    $table->double('sms_rate')->nullable()->default(0.8);
                });
            });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')
            ->table('company', function (Blueprint $table) {
                $table->dropColumn('sms_rate');
            });
    }
};
