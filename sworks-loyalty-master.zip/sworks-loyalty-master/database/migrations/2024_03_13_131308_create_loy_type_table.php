<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::create('loy_type', function (Blueprint $table) {
            $table->string('type', 10);
            $table->string('sub_type', 10);
            $table->string('short_desc', 30);
            $table->string('long_desc', 140);
            $table->integer('last_no');
            $table->string('sign', 2);
            $table->boolean('print');
            $table->boolean('show');
            $table->string('def_analy_code', 10);

            $table->unique('type', 'loy_type_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {        
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::dropIfExists('loy_type');
    }
};
