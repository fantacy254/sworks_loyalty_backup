<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('username')->unique();
            $table->string('email')->unique();
            $table->string('phone_no')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->foreignId('access_level_id');
            $table->foreignId('company_id');
            $table->unsignedBigInteger('branch_id')->default(1);
            $table->boolean('multi_access')->default(false);
            $table->boolean('first_login')->default(true);
            $table->timestamps();

            $table->softDeletes();

            $table->foreign('access_level_id')->references('id')->on('access_level');
            $table->foreign('company_id')->references('id')->on('company');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->dropIfExists('users');
    }
};
