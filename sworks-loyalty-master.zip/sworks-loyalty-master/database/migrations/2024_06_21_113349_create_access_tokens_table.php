<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }
        
        Schema::connection('smart_core')->create('access_tokens', function (Blueprint $table) {
            $table->id();
            $table->string('api_token', 100)->unique();
            $table->timestamp('verified_at');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->dropIfExists('access_tokens');
    }
};
