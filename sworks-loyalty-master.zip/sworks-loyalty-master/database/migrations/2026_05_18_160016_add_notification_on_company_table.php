<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::table('company', function (Blueprint $table) {
            $table->after('admin', function ($table) {
                $table->boolean('send_sms')->default(false);
                $table->boolean('send_email')->default(false);
            });
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::table('company', function (Blueprint $table) {
            $table->dropColumn('send_sms');
            $table->dropColumn('send_email');
        });
    }
};
