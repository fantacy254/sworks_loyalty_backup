<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::table('sms_trans', function (Blueprint $table) {
            $table->after('sender', function ($table) {
                $table->string('initiator')->nullable();
            });
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::table('sms_trans', function (Blueprint $table) {
            $table->dropColumn('initiator');
        });
    }
};
