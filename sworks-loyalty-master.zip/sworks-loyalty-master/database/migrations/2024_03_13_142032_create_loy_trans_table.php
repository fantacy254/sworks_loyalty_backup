<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::create('loy_trans', function (Blueprint $table) {
            $table->bigInteger('id');
            $table->string('doc_no', 30);
            $table->string('type', 20);
            $table->date('run_date');
            $table->string('reference', 30)->nullable();
            $table->double('amount', 8, 2);
            $table->string('status', 2);
            $table->string('input_by', 20);
            $table->double('points', 8, 2);
            $table->string('accno', 20);
            $table->date('period');
            $table->string('notes', 255)->nullable();
            $table->foreignId('branch_id');
            $table->boolean('sync');
            $table->string('till_no', 15)->nullable();
            $table->string('operator', 100)->nullable();
            $table->string('zed_no', 30)->nullable();
            $table->string('eod_no', 50)->nullable();
            $table->timestamps();

            $table->foreign('branch_id')->references('id')->on('branch');
            $table->unique(['doc_no', 'type', 'branch_id'], 'loy_trans_index');
            $table->unique(['run_date', 'reference', 'branch_id'], 'loy_trans_ern_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }
        
        Schema::dropIfExists('loy_trans');
    }
};
