<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::create('sms_template', function (Blueprint $table) {
            $table->id();
            $table->string('temp_id', 50);
            $table->string('name', 50);
            $table->longText('description');
            $table->foreignId('company_id')->nullable()->constrained('company')->onDelete('cascade');
            $table->string('level', 100)->nullable()->comment('level of the template, can be account notifications or loyalty notifications');
            $table->string('input_by', 50)->nullable();
            $table->string('edit_by', 50)->nullable();
            $table->timestamps();

            $table->unique(['temp_id', 'company_id'], 'sms_template_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::dropIfExists('sms_template');
    }
};
