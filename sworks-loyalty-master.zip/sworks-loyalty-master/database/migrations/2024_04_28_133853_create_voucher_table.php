<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::create('voucher', function (Blueprint $table) {
            $table->string('doc_no', 20);
            $table->string('payload', 500);
            $table->date('date');
            $table->string('our_ref', 30);
            $table->string('cust_accno', 20);
            $table->string('cust_name', 50);
            $table->string('cust_code', 50);
            $table->double('amount');
            $table->boolean('used')->nullable();
            $table->string('input_by', 15);
            $table->timestamp('input_date');
            $table->string('edit_by', 15)->nullable();
            $table->timestamp('edit_date')->nullable();
            $table->boolean('printed')->nullable();
            $table->date('expiry')->nullable();
            $table->double('points');
            $table->unsignedBigInteger('br_code');
            $table->timestamp('used_date')->nullable();
            $table->string('used_branch', 3)->nullable();
            $table->string('used_receipt', 10)->nullable();
            $table->date('used_rdate')->nullable();
            $table->string('used_till', 2)->nullable();
            $table->string('sync_stamp', 30)->nullable();

            $table->unique(['doc_no', 'date', 'cust_code', 'br_code'], 'voucher_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {        
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::dropIfExists('voucher');
    }
};
