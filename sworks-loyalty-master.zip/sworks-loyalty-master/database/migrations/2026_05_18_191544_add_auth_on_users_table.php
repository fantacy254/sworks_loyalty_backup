<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::table('users', function (Blueprint $table) {
            $table->after('first_login', function ($table) {
                $table->boolean('two_factor')->default(false);
                $table->boolean('auth_email')->default(false);
                $table->boolean('auth_sms')->default(false);
            });
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('two_factor');
            $table->dropColumn('auth_email');
            $table->dropColumn('auth_sms');
        });
    }
};
