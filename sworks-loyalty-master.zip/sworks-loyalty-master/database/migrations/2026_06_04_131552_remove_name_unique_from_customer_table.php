<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::table('loy_customer', function (Blueprint $table) {
            $table->dropUnique(['name']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::table('loy_customer', function (Blueprint $table) {
            $table->string('name', 50)->unique();
        });
    }
};
