<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->create('company', function (Blueprint $table) {
            $table->id();
            $table->string('name', 140)->unique();
            $table->string('address', 140);
            $table->string('phone', 96)->nullable();
            $table->string('pin_no', 20)->unique();
            $table->string('vat_no', 20)->nullable();
            $table->string('email', 100)->nullable();
            $table->string('db', 50);
            $table->string('sender_id');
            $table->text('license')->nullable();
            $table->timestamp('start_at')->nullable();
            $table->timestamp('expire_at')->nullable();
            $table->string('client_sync_key', 100)->nullable();

            $table->timestamps();

            $table->unique(['name', 'db', 'pin_no'], 'company_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core ')->dropIfExists('company');
    }

};
