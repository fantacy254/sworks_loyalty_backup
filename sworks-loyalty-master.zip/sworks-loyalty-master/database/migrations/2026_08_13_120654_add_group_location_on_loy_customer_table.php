<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::table('loy_customer', function (Blueprint $table) {
            $table->after('address', function ($table) {
                $table->foreignId('group_id')->nullable()->references('id')->on('groups')->onDelete('set Null');
                $table->foreignId('location_id')->nullable()->references('id')->on('locations')->onDelete('set Null');
            });
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Skip this migration on smart_core connection - dynamic tables only
        if (DB::getDefaultConnection() === 'smart_core') {
            return;
        }

        Schema::table('loy_customer', function (Blueprint $table) {
            $table->dropForeign(['group_id', 'location_id']);
            $table->dropColumn('group_id');
            $table->dropColumn('location_id');
        });
    }
};
