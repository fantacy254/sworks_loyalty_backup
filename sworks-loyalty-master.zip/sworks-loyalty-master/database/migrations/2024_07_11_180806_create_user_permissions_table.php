<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->create('user_permissions', function (Blueprint $table) {
            $table->string('permission_id');
            $table->foreignId('user_id');
            $table->string('input_by');
            $table->timestamps();

            $table->foreign('user_id')->references('id')->on('users');
            $table->unique(['permission_id', 'user_id'], 'user_permission_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Only run this migration on smart_core connection
        if (DB::getDefaultConnection() !== 'smart_core') {
            return;
        }

        Schema::connection('smart_core')->dropIfExists('user_permissions');
    }

};
