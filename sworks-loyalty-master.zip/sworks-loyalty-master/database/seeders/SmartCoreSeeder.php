<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class SmartCoreSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::setDefaultConnection('smart_core');

        DB::transaction(function () {

            DB::connection('smart_core')->table('access_level')->upsert([
                ['id' => 1, 'name' => 'superuser', 'notes' => 'user can overwrite all permissions for all companies'],
                ['id' => 2, 'name' => 'admin', 'notes' => 'Branch user has admin permissions'],
                ['id' => 3, 'name' => 'Manager', 'notes' => 'Branch user has managerial permissions'],
                ['id' => 4, 'name' => 'supervisor', 'notes' => 'Branch user has supervisor permissions'],
                ['id' => 5, 'name' => 'general User', 'notes' => 'Branch user has general permissions'],
            ], ['id', 'name'], ['notes']);

            DB::connection('smart_core')->table('company')->upsert([
                ['id' => 1, 'name' => 'SMARTWORKS TRADING CO. LTD', 'address' => 'P.O BOX 1234-00100', 'email' => 'info@sworks.co.ke', 'db' => 'sworksco_test', 'phone' => '0700000000', 'pin_no' => 'p', 'created_at' => now(), 'sender_id' => 'TextSMS']
            ], ['id', 'name', 'pin_no'], ['name', 'email', 'address', 'phone', 'pin_no', 'db']);

            DB::connection('smart_core')->table('permissions')->upsert([
                ['permission_id' => 'is_admin', 'permission' => 'Is Admin', 'description' => 'User is admin.', 'active' => true, 'category' => 'user management', 'level' => 1],
                ['permission_id' => 'can_create_user', 'permission' => 'can create system user', 'description' => 'user can create system users', 'active' => true, 'category' => 'user management', 'level' => 1],
                ['permission_id' => 'can_edit_user', 'permission' => 'can edit system user', 'description' => 'user can edit system users', 'active' => true, 'category' => 'user management', 'level' => 1],
                ['permission_id' => 'can_delete_user', 'permission' => 'can delete system user', 'description' => 'user can delete system users', 'active' => true, 'category' => 'user management', 'level' => 1],
                ['permission_id' => 'is_superuser', 'permission' => 'is superuser', 'description' => 'User is superuser.', 'active' => true, 'category' => 'user management', 'level' => 1],
                ['permission_id' => 'can_view_loyalty_customers', 'permission' => 'can view loyalty customers', 'description' => 'User can view loyalty customers', 'active' => true, 'category' => 'Loyalty customer', 'level' => 2],
                ['permission_id' => 'can_create_loy_customer', 'permission' => 'can create loy customer', 'description' => 'User can create loyalty customer', 'active' => true, 'category' => 'Loyalty customer', 'level' => 2],
                ['permission_id' => 'can_edit_loy_customer', 'permission' => 'can edit loy customer', 'description' => 'User can edit loyalty customer', 'active' => true, 'category' => 'Loyalty customer', 'level' => 2],
                ['permission_id' => 'can_delete_loy_customer', 'permission' => 'can delete loy customer', 'description' => 'User can delete loyalty customer', 'active' => true, 'category' => 'Loyalty customer', 'level' => 2],
                ['permission_id' => 'can_award_points', 'permission' => 'can award loyalty points', 'description' => 'User can award loyalty points', 'active' => true, 'category' => 'transactions', 'level' => 2],
                ['permission_id' => 'can_cancel_points', 'permission' => 'can cancel loyalty points', 'description' => 'User can cancel loyalty points', 'active' => true, 'category' => 'transactions', 'level' => 2],
                ['permission_id' => 'can_adjust_points', 'permission' => 'can adjust loyalty points', 'description' => 'User can adjust loyalty points', 'active' => true, 'category' => 'transactions', 'level' => 2],
                ['permission_id' => 'can_view_balance_enquiry', 'permission' => 'user can view balance enquiry', 'description' => 'User can view balance enquiry', 'active' => true, 'category' => 'transactions', 'level' => 2],
                ['permission_id' => 'can_redeem_points', 'permission' => 'user can redeem loyalty points', 'description' => 'User can redeem loyalty points', 'active' => true, 'category' => 'transactions', 'level' => 2],
                ['permission_id' => 'can_load_transactions', 'permission' => 'user can load loalty transactions', 'description' => 'User can load loalty transactions', 'active' => true, 'category' => 'reports', 'level' => 2],
                ['permission_id' => 'can_view_statement', 'permission' => 'user can view customer statement', 'description' => 'User can view customer statement', 'active' => true, 'category' => 'reports', 'level' => 2],
                ['permission_id' => 'can_get_statement', 'permission' => 'user can get customer statement', 'description' => 'User can get customer statement', 'active' => true, 'category' => 'reports', 'level' => 2],
                ['permission_id' => 'can_print_voucher', 'permission' => 'user can print loyalty voucher', 'description' => 'User can print loyalty voucher receipt', 'active' => true, 'category' => 'reports', 'level' => 2],
            ], ['permission_id'], ['permission', 'description', 'active']);

            DB::connection('smart_core')
                ->table('users')
                ->upsert([
                ['id' => 1, 'name' => 'SMART ENGINE', 'username' => 'ENGINE', 'email' => 'danson@sworks.co.ke', 'email_verified_at' => now(), 'password' => Hash::make('swdonot!123'), 'company_id' => 1, 'branch_id' => 1, 'access_level_id' => 1, 'multi_access' => true]
            ], ['id', 'username', 'email', 'company_id'], ['name', 'password']);

            DB::connection('smart_core')
                ->table('user_permissions')
                ->upsert([
                ['permission_id' => 'is_admin', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_edit_user', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_delete_user', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'is_superuser', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_view_loyalty_customers', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_create_loy_customer', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_edit_loy_customer', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_delete_loy_customer', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_award_points', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_cancel_points', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_adjust_points', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_view_balance_enquiry', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_redeem_points', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_load_transactions', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_view_statement', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_get_statement', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()],
                ['permission_id' => 'can_print_voucher', 'user_id' => 1, 'input_by' => 'ENGINE', 'created_at' => now(), 'updated_at' => now()]
            ], ['permission_id', 'user_id'], ['input_by', 'created_at', 'updated_at']);

            //sms default teemplates
            DB::connection('smart_core')
                ->table('sms_template')
                ->upsert([
                    ['id' => 1, 'temp_id' => 'authentication', 'name' => 'MF Authentication', 'description' => 'Your authorization code is: {auth_code}\nThis code is only valid withn 2 min(s).\nPlease DO NOT share with anyone.', 'company_id' => null, 'level' => 'account notificaions', 'input_by' => 'Engine', 'edit_by' => 'Engine', 'created_at' => now(), 'updated_at' => now()],
                    ['id' => 2, 'temp_id' => 'account_creation', 'name' => 'Account Creation', 'description' => 'Dear {user_name}\nYour account has been created.\nUsername:  {user_email}\nPassword:  {user_password}\nChange your password on login.', 'company_id' => null, 'level' => 'account notificaions', 'input_by' => 'Engine', 'edit_by' => 'Engine', 'created_at' => now(), 'updated_at' => now()],
                    ['id' => 3, 'temp_id' => 'customer_onboard', 'name' => 'Customer Onboarding', 'description' => 'Dear {cust_name}\nWelcome to our loyalty program!\nShop more to grow your points balance.', 'company_id' => null, 'level' => 'loyalty notifications', 'input_by' => 'Engine', 'edit_by' => 'Engine', 'created_at' => now(), 'updated_at' => now()],
                    ['id' => 4, 'temp_id' => 'earned_points', 'name' => 'Earned Points', 'description' => 'Dear {cust_name}\nYou have earned {points} smart points!\nKeep shopping to grow your points balance.', 'company_id' => null, 'level' => 'loyalty notifications', 'input_by' => 'Engine', 'edit_by' => 'Engine', 'created_at' => now(), 'updated_at' => now()],
                    ['id' => 5, 'temp_id' => 'redeemed_points', 'name' => 'Redeemed Points', 'description' => 'Dear {cust_name},\You have redeemed {points} smart points.\nVoucher No:  {voucher}\nValue:  {points} \nExpiry: {expiry}\nThank you for shopping with us!', 'company_id' => null, 'level' => 'loyalty notifications', 'input_by' => 'Engine', 'edit_by' => 'Engine', 'created_at' => now(), 'updated_at' => now()],
                    ['id' => 6, 'temp_id' => 'promotional', 'name' => 'Promotional Message', 'description' => 'Dear {cust_name},\nCheck out our latest offers!\nDon\'t miss out on great deals!', 'company_id' => null, 'level' => 'loyalty notifications', 'input_by' => 'Engine', 'edit_by' => 'Engine', 'created_at' => now(), 'updated_at' => now()]
                ], ['temp_id', 'company_id'], ['id', 'name', 'description', 'level', 'input_by', 'edit_by', 'created_at', 'updated_at']);

        });
    }
}
