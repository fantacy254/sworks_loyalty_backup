<?php

namespace Database\Seeders;

use App\Models\county;
use App\Models\Group;
use App\Models\Location;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        DB::transaction(function () {

            //loyalty trans masters
            DB::table('loy_masters')->upsert([
                ['id' => 1, 'item' => 'loyalty', 'last_no' => 0, 'length' => '4', 'status' => true, 'notes' => 'true : The system must uses customer loyalty module FALSE: Does not have customer loyalty', 'created_at' => now(), 'updated_at' => now()]
            ], ['id', 'item'], ['length', 'status', 'notes', 'created_at', 'updated_at']);

            //loyalty trans types
            DB::table('loy_type')->upsert([
                ['type' => 'CAN', 'sub_type' => 'CAN', 'short_desc' => 'CANCEL SMARTPOINTS', 'long_desc' => 'CANCEL SMARTPOINTS', 'last_no' => 0, 'sign' => '-', 'print' => true, 'show' => true, 'def_analy_code' => '0001'],
                ['type' => 'CRD', 'sub_type' => 'CRD', 'short_desc' => 'REINSTATE SMARTPOINTS', 'long_desc' => 'REINSTATE SMARTPOINTS', 'last_no' => 0, 'sign' => '+', 'print' => true, 'show' => true, 'def_analy_code' => '0001'],
                ['type' => 'AWD', 'sub_type' => 'AWD', 'short_desc' => 'AWARD SMARTPOINTS', 'long_desc' => 'AWARD SMARTPOINTS', 'last_no' => 0, 'sign' => '+', 'print' => true, 'show' => true, 'def_analy_code' => '0001'],
                ['type' => 'AD+', 'sub_type' => 'ADJ', 'short_desc' => 'SMARTPOINTS +VE ADJUSTMENT', 'long_desc' => 'SMARTPOINTS +VE ADJUSTMENT', 'last_no' => 0, 'sign' => '+', 'print' => true, 'show' => true, 'def_analy_code' => '0001'],
                ['type' => 'AD-', 'sub_type' => 'ADJ', 'short_desc' => 'SMARTPOINTS -VE ADJUSTMENT', 'long_desc' => 'SMARTPOINTS -VE ADJUSTMENT', 'last_no' => 0, 'sign' => '-', 'print' => true, 'show' => true, 'def_analy_code' => '0001'],
                ['type' => 'RED', 'sub_type' => 'RED', 'short_desc' => 'REDEEMING SMARTPOINTS', 'long_desc' => 'REDEEMING SMARTPOINTS', 'last_no' => 0, 'sign' => '-', 'print' => true, 'show' => true, 'def_analy_code' => '0001'],
                ['type' => 'ERN', 'sub_type' => 'ERN', 'short_desc' => 'EARNING SMARTPOINTS', 'long_desc' => 'EARNING SMARTPOINTS', 'last_no' => 0, 'sign' => '+', 'print' => true, 'show' => true, 'def_analy_code' => '0001'],
            ], ['type'], ['sub_type', 'short_desc', 'long_desc', 'sign']);

            //loyalty Master
            DB::table('masters')->upsert(
                [
                    ['id' => 1, 'active' => true, 'earn' => '100', 'redeem' => '1', 'min_redeem' => '200', 'last_redeem' => '0', 'expiry' => 7, 'has_hq' => false, 'created_at' => now()]
                ],
                ['id'],
                ['active', 'expiry']
            );

            //Customers Master
            Location::upsert(
                [
                    ['id' => 1, 'name' => 'Default', 'input_by' => 'Engine', 'created_at' => now()]
                ],
                ['id'],
                ['name', 'input_by']
            );

            Group::upsert(
                [
                    ['id' => 1, 'name' => 'Default', 'input_by' => 'Engine', 'created_at' => now()]
                ],
                ['id'],
                ['name', 'input_by']
            );

            //update auth on loy_type
            DB::connection('dynamic')
            ->table('loy_type')
            ->whereNotIn('type',['ERN','RED'])
            ->update([
                'auth'=>true
            ]);
        });
    }
}
