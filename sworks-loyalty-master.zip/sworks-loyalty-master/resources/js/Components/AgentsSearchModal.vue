<script setup>
import axios from "axios";
import { computed, inject, onMounted, onBeforeUnmount, ref } from "vue";
import MyTransition from "@/Components/MyTransition.vue";
import { computedAmount } from "@/utlis/smartFun";

const showModal = inject("showModal");
const { agent, getAgentDetails } = inject("agentID");

const agents = ref([]);
const searchItem = ref("");
const headers = ref();
const loading = ref(false);

const filteredData = computed(() => {
    return agents.value.filter((item) => {
        return (
            (item.agent_id &&
                item.agent_id
                    .toLowerCase()
                    .indexOf(searchItem.value.toLowerCase())) !== -1 ||
            (item.agent_name &&
                item.agent_name
                    .toString()
                    .toLowerCase()
                    .includes(searchItem.value.toLowerCase()))
        );
    });
});

const showAgents = async () => {
    loading.value = true;
    await axios
        .get("/sub-agents/searchAgents")
        .then((res) => {
            //console.log(res)
            headers.value = Object.keys(res.data[0]).map((key) => ({
                name: key,
                headerName: key
                    .split("_")
                    .map(
                        (word) =>
                            word.charAt(0).toLocaleUpperCase() + word.slice(1),
                    )
                    .join(" "),
            }));
            if (res.data.length > 0) {
                agents.value = res.data;
            } else {
                agents.value.splice(0, agents.value.length);
            }
        })
        .catch((error) => {
            //console.log(error)
        })
        .finally(() => {
            loading.value = false;
        });
};

const agentHandler = (id) => {
    //console.log(id)
    closeModal();
    agent.value = id;
    getAgentDetails();
};

const closeModal = () => {
    showModal.value = false;
};
const handleKeyPress = (event) => {
    if (event.key === "Escape" || event.key === "ESC") {
        closeModal();
    }
};

onMounted(() => {
    window.addEventListener("keypress", handleKeyPress);
    showAgents();
});
onBeforeUnmount(() => {
    agents.value.splice(0, agents.value.length);
    window.removeEventListener("keydown", handleKeyPress);
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showModal"
            @click.self="closeModal()"
            @keydown="handleKeyPress"
            class="w-full backdrop-blur-sm mx-auto absolute z-9999 pt-20 inset-0 bg-black/40 min-h-screen"
        >
            <my-transition>
                <div
                    @click.stop
                    class="md:mx-auto mx-2 md:w-2/4 w-auto bg-white dark:bg-gray-800 rounded-md md:px-3 py-1 space-y-1"
                >
                    <!---search section-->
                    <div class="flex items-center justify-start px-2">
                        <i
                            class="fa-solid fa-magnifying-glass text-lg text-slate-300 dark:text-slate-300"
                        ></i>
                        <input
                            ref="search"
                            v-model="searchItem"
                            type="text"
                            name="search"
                            id="search"
                            class="border-none text-xs md:text-sm ring-0 focus:ring-0 focus:border-none text-left w-full bg-inherit dark:text-slate-300"
                            placeholder="Search customer"
                            autofocus
                        />
                        <span
                            class="bg-slate-100 dark:bg-inherit dark:text-slate-400 rounded-lg p-2 text-xs"
                        >
                            ESC
                        </span>
                    </div>
                    <hr />
                    <!--table section-->
                    <div
                        ref="tableContainer"
                        class="overflow-auto scrollbar-thin w-full h-80 md:mx-auto rounded-t-md"
                    >
                        <table
                            class="table-auto w-full mx-auto border-collapse dark:bg-inherit dark:text-slate-300"
                        >
                            <thead
                                class="sticky top-0 bg-slate-200 dark:bg-gray-900 text-xs"
                            >
                                <tr
                                    v-if="filteredData.length > 0"
                                    class="text-left"
                                >
                                    <th
                                        v-for="(head, index) in headers"
                                        :key="index"
                                        class="px-2 py-3 text-nowrap font-normal border border-slate-300 dark:border-gray-600"
                                    >
                                        {{ head.headerName }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-sm">
                                <tr
                                    v-if="filteredData.length > 0 && !loading"
                                    v-for="(item, rowIndex) in filteredData"
                                    :key="rowIndex"
                                    @click="agentHandler(item.agent_id)"
                                    class="text-sm odd:bg-slate-100 hover:bg-orange-100 hover:cursor-pointer dark:odd:bg-gray-800 dark:hover:bg-gray-700"
                                >
                                    <td
                                        v-for="(header, colIndex) in headers"
                                        :key="colIndex"
                                        class="px-2 py-2 border text-nowrap border-gray-100 dark:border-gray-700 text-xs uppercase"
                                    >
                                        <span v-if="header.name === 'acc_bal'">
                                            {{
                                                computedAmount(
                                                    item[header.name],
                                                )
                                            }}
                                        </span>
                                        <span v-else>{{
                                            item[header.name]
                                        }}</span>
                                    </td>
                                </tr>
                                <tr
                                    v-else-if="
                                        filteredData.length === 0 && !loading
                                    "
                                    class=""
                                >
                                    <td colspan="10" class="p-14 text-center">
                                        No Records found
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr />
                    <!--footer section-->
                    <div class="p-2 flex items-center text-xs justify-end">
                        <p class="text-slate-400 text-xs">
                            powered by
                            <i
                                class="text-slate-700 dark:text-slate-500 font-semibold text-xs"
                                >smartSearch</i
                            >
                        </p>
                    </div>
                </div>
            </my-transition>
        </div>
    </teleport>
</template>
