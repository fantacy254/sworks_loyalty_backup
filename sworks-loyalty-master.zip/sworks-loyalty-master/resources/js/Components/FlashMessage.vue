<script setup>
import { usePage } from "@inertiajs/vue3";
import { onMounted, ref, watch } from "vue";

//page
const page = usePage();

const show = ref(true);
const flashMessages = ref([]);

const removeFlash = (index) => {
    return flashMessages.value.splice(index, 1);
};

onMounted(() => {
    page.props?.flash;
});

//watch for flash messages
watch(
    () => page.props?.flash?.info,
    (newVal) => {
        if (newVal) {
            const id = Date.now() + Math.random();
            flashMessages.value.push({
                id: page.props?.flash?.token ?? id,
                header: "info",
                message: (page.props?.flash ?? {}).info,
                icon: "fa-solid fa-triangle-exclamation text-amber-500 text-sm",
                class: "bg-amber-100 border-amber-300 text-amber-800",
            });

            // Remove the item after 1 second
            setTimeout(() => {
                flashMessages.value.shift();
            }, 5000);
        }
    },
    { deep: true, immediate: true },
);
watch(
    () => page.props?.flash?.error,
    (newVal) => {
        if (newVal) {
            const id = Date.now() + Math.random();
            flashMessages.value.push({
                id: page.props?.flash?.token ?? id,
                header: "error",
                message: newVal,
                icon: "fa-solid fa-circle-exclamation text-sm text-red-800",
                class: "bg-red-400 text-red-900 border-red-500",
            });

            // Remove the item after 1 second
            setTimeout(() => {
                flashMessages.value.shift();
            }, 5000);
        }
    },
    { deep: true, immediate: true },
);
watch(
    () => page.props?.errors,
    (newVal) => {
        if (newVal.length > 0) {
            newVal.forEach((e) => {
                const id = Date.now() + Math.random();
                flashMessages.value.push({
                    id: page.props?.errors.token ?? id,
                    header: "error",
                    message: e,
                    icon: "fa-solid fa-circle-exclamation text-sm text-red-800",
                    class: "bg-red-400 text-red-900 border-red-500",
                });

                // Remove the item after 1 second
                setTimeout(() => {
                    flashMessages.value.shift();
                }, 7000);
            });
        }
    },
    { deep: true, immediate: true },
);
watch(
    () => page.props?.flash?.success,
    (newVal) => {
        if (newVal) {
            const id = Date.now() + Math.random();
            flashMessages.value.push({
                id: page.props?.flash?.token ?? id,
                header: "success",
                message: (page.props?.flash ?? {}).success,
                icon: "fa-regular fa-circle-check text-sm text-green-900",
                class: "bg-green-200",
            });

            // Remove the item after 1 second
            setTimeout(() => {
                flashMessages.value.shift();
            }, 5000);
        }
    },
    { deep: true, immediate: true },
);
watch(
    () => page.props?.flash?.status,
    (newVal) => {
        if (newVal) {
            let msg;
            if (newVal === "verification-link-sent") {
                msg = "A new verification link has been sent!";
            } else if (newVal === "two-factor-authentication-enabled") {
                msg = "2FA has been enabled";
            } else if (newVal === "two-factor-authentication-confirmed") {
                msg = "2FA confirmed successfully";
            } else {
                msg = (page.props?.flash ?? {}).status;
            }

            const id = Date.now() + Math.random();
            flashMessages.value.push({
                id: page.props?.flash?.token ?? id,
                header: "status",
                message: msg,
                icon: "fa-regular fa-circle-check text-sm text-green-700",
                class: "bg-green-200",
            });
            // Remove the item after 1 second
            setTimeout(() => {
                flashMessages.value.shift();
            }, 5000);
        }
    },
    { deep: true, immediate: true },
);
watch(
    () => page.props?.flash?.logout,
    (newVal) => {
        if (newVal) {
            //add flash message into the array
            const id = Date.now() + Math.random();
            flashMessages.value.push({
                id: page.props?.flash?.token ?? id,
                header: "logout",
                message: newVal,
                icon: "fa-regular fa-circle-check text-sm text-green-700",
                class: "bg-green-300",
            });
            // Remove the item after 1 second
            setTimeout(() => {
                flashMessages.value.shift();
            }, 5000);
        }
    },
    { deep: true, immediate: true },
);
</script>
<template>
    <!--flash messages-->
    <teleport to="body">
        <ul
            v-if="show && flashMessages.length > 0"
            class="space-y-3 z-999999 fixed top-4 right-0 px-2 overflow-hidden inline-block select-none"
        >
            <li
                :class="item.class"
                v-for="(item, index) in flashMessages"
                :key="item.id"
                class="flex items-center justify-start text-xs md:text-sm space-x-3 border rounded-md p-2 animate__animated animate__bounceInDown"
            >
                <i :class="item.icon"></i>
                <p class="text-xs flex-1 normal-case">{{ item.message }}</p>
                <button @click="removeFlash(index)" type="button">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </li>
        </ul>
    </teleport>
</template>
