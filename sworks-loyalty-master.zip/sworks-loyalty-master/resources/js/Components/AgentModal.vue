<script setup>
import { useForm } from "@inertiajs/vue3";
import MyTransition from "@/Components/MyTransition.vue";
import { inject, onMounted, ref } from "vue";
import axios from "axios";

import { usePage } from "@inertiajs/vue3";

const page = usePage();

const showModal = inject("showAgentModal");
const agtId = inject("agentId");
const refresh = inject("refreshAgents");
const canedit = inject("canEdit");

const form = useForm({
    agent_id: null,
    agent_name: null,
    agent_pin: null,
    address: null,
    email: null,
    county: null,
    city: null,
    region: null,
});
const regions = ref([]);
const counties = ref([]);

const getRegions = async () => {
    await axios.get("/regions").then((res) => {
        regions.value = res.data;
    });
};

const ShowCounties = async () => {
    try {
        const res = await axios.get("/counties");
        counties.value = res.data;
        console.log(counties.value);
    } catch (error) {
        console.log(error);
    }
};

const closeAgentModal = () => {
    showModal.value = false;
};

const getAgentDetails = async () => {
    await axios
        .get("/sub-agents/findAgent", {
            params: {
                agentsId: agtId.value,
            },
        })
        .then((res) => {
            console.log(res.data);
            if (res.status === 500) {
                page.props.flash.error = res.data;
            }

            form.agent_id = res.data.agent_id;
            form.agent_name = res.data.agent_name.toUpperCase();
            form.agent_pin = res.data.agent_pin;
            form.address = res.data.address;
            form.email = res.data.email.toLowerCase();
            form.county = res.data.county_id;
            form.city = res.data.city.toUpperCase();
            form.region = res.data.region_id;
        });
};

const updateAgent = () => {
    return form.patch(`/sub-agents/${agtId.value}`, {
        onSuccess: () => {
            closeAgentModal();
            refresh.value = true;
        },
        onError: () => (showModal.value = true),
    });
};

onMounted(() => {
    getRegions();
    getAgentDetails();
    ShowCounties();
    //console.log(form)
    //console.log(regions)
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showModal"
            @click.self="closeAgentModal"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex md:items-center justify-center dark:text-slate-300 px-4 md:px-0"
        >
            <MyTransition>
                <form
                    @submit.prevent="updateAgent()"
                    @click.stop
                    class="bg-white dark:bg-gray-900 rounded-md h-fit mt-8 space-y-3 md:w-2/5 w-full"
                >
                    <div
                        class="w-full border-b-gray-300 border-b shadow-sm rounded-t-md bg-indigo-800 flex items-center justify-center"
                    >
                        <h1 class="font-medium text-sm text-slate-200 p-4">
                            <span v-if="canedit">Edit</span> Sub-Agent
                            information details
                        </h1>
                    </div>
                    <p v-if="canedit" class="text-xs px-2 text-slate-400">
                        Provide details below. It's mandatory for spaces marked
                        with
                        <i class="text-red-500 font-medium">*</i>
                    </p>
                    <p v-else class="text-xs px-2 text-slate-400">
                        Sub-agent detailed information
                    </p>
                    <!--user details-->
                    <main class="px-3">
                        <div
                            class="py-3 flex md:flex-row flex-col md:space-x-3 space-y-3 md:space-y-0"
                        >
                            <text-input
                                type="text"
                                id="agent_id"
                                label="Contact person ID"
                                :must="canedit"
                                disabled
                                class="w-auto caret-slate-300 cursor-not-allowed text-slate-400"
                                v-model="form.agent_id"
                                :error="form.errors.agent_id"
                            />
                            <text-input
                                type="text"
                                id="agent_name"
                                label="Sub Agent Name"
                                :must="canedit"
                                :disabled="!canedit"
                                class="w-full text-slate-500"
                                v-model="form.agent_name"
                                :error="form.errors.agent_name"
                            />
                        </div>
                        <div
                            class="py-3 flex md:flex-row flex-col md:space-x-3 space-y-3 md:space-y-0"
                        >
                            <text-input
                                type="text"
                                id="agent_pin"
                                label="Pin Number"
                                :must="canedit"
                                :disabled="!canedit"
                                class="w-full text-slate-500"
                                v-model="form.agent_pin"
                                :error="form.errors.agent_pin"
                            />
                            <text-input
                                type="text"
                                id="address"
                                label="Address"
                                :must="canedit"
                                :disabled="!canedit"
                                class="w-full text-slate-500"
                                v-model="form.address"
                                :error="form.errors.address"
                            />
                        </div>
                        <div
                            class="py-3 flex md:flex-row flex-col md:space-x-3 space-y-3 md:space-y-0"
                        >
                            <text-input
                                type="email"
                                id="agent_email"
                                label="Email"
                                :must="canedit"
                                :disabled="!canedit"
                                class="w-full text-slate-500"
                                v-model="form.email"
                                :error="form.errors.email"
                            />
                            <div class="space-y-1 w-full text-slate-500">
                                <label
                                    class="text-xs md:text-xs text-slate-700 dark:text-slate-300"
                                    for="county"
                                    >county:<i
                                        v-if="canedit"
                                        class="text-red-500 font-semibold"
                                        >*</i
                                    ></label
                                >
                                <select
                                    id="county"
                                    ref="input"
                                    v-model="form.county"
                                    class="rounded-md w-full text-xs dark:border-b-blue-700 border-gray-100 dark:border-slate-700 focus:outline-none dark:bg-gray-800 dark:text-slate-300 form-input"
                                    :required="canedit"
                                    :disabled="!canedit"
                                >
                                    <option
                                        v-for="(county, index) in counties"
                                        :key="index"
                                        :value="county.id"
                                    >
                                        {{ county.name }}
                                    </option>
                                </select>
                                <div
                                    v-if="form.errors"
                                    class="font-thin text-red-500"
                                >
                                    {{ form.errors.region }}
                                </div>
                            </div>
                        </div>
                        <div
                            class="py-3 flex md:flex-row flex-col md:space-x-3 space-y-3 md:space-y-0"
                        >
                            <text-input
                                type="text"
                                id="city"
                                label="City"
                                :must="canedit"
                                :disabled="!canedit"
                                class="w-full text-slate-500"
                                v-model="form.city"
                                :error="form.errors.city"
                            />
                            <div class="space-y-1 w-full text-slate-500">
                                <label
                                    class="text-xs md:text-xs text-slate-700 dark:text-slate-300"
                                    for="agent_region"
                                    >Operator Region:<i
                                        v-if="canedit"
                                        class="text-red-500 font-semibold"
                                        >*</i
                                    ></label
                                >
                                <select
                                    id="agent_region"
                                    ref="input"
                                    v-model="form.region"
                                    class="rounded-md w-full text-xs dark:border-b-blue-700 border-gray-100 dark:border-slate-700 focus:outline-none dark:bg-gray-800 dark:text-slate-300 form-input"
                                    :required="canedit"
                                    :disabled="!canedit"
                                >
                                    <option
                                        v-for="(item, index) in regions"
                                        :key="index"
                                        :value="item.id"
                                    >
                                        {{ item.name }}
                                    </option>
                                </select>
                                <div
                                    v-if="form.errors"
                                    class="font-thin text-red-500"
                                >
                                    {{ form.errors.region }}
                                </div>
                            </div>
                        </div>
                    </main>
                    <hr />
                    <!--buttons section-->
                    <div class="p-3 space-x-2 flex items-center justify-end">
                        <primary-button
                            v-if="canedit"
                            name="Update"
                            type="submit"
                        />
                        <secondary-button
                            name="Cancel"
                            type="button"
                            @click="closeAgentModal"
                        />
                    </div>
                </form>
            </MyTransition>
        </div>
    </teleport>
</template>
