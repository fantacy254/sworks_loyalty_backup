<script setup>
    import { Bar, Doughnut, Line } from "vue-chartjs";

    import {
        Chart as ChartJS,
        Title,
        Tooltip,
        Legend,
        BarElement,
        ArcElement,
        RadialLinearScale,
        TimeScale,
        Filler,
        CategoryScale,
        LinearScale,
        LineElement,
        PointElement,
        LineController,
        BarController,
    } from "chart.js";
    import { computed } from "vue";
    import { computedAmount } from "@/utlis/smartFun";

    const isDark = document.documentElement.classList.contains('dark');
    const centerTextPlugin = {
        id: "centerText",
        beforeDraw(chart) {
            const { ctx, chartArea } = chart;
            const cfg = chart.options.centerText;
            if (!cfg) return;

            const x = (chartArea.left + chartArea.right) / 2;
            const y = (chartArea.top + chartArea.bottom) / 2;

            ctx.save();
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";

            // Label (top)
            ctx.font = "600 11px sans-serif";
            ctx.fillStyle = isDark ? '#ffffff' : "#3C3939"; // gray
            ctx.fillText(cfg.label, x, y - 10);

            // Value (bottom)
            ctx.font = "bold 16px sans-serif";
            ctx.fillStyle = isDark ? '#ffffff' : "#111";
            ctx.fillText(cfg.text, x, y + 12);

            ctx.restore();
        },
    };

    ChartJS.register(
        Title,
        Tooltip,
        Legend,
        BarElement,
        ArcElement,
        RadialLinearScale,
        CategoryScale,
        TimeScale,
        Filler,
        LinearScale,
        LineElement,
        LineController,
        BarController,
        PointElement,
        centerTextPlugin,
    );

    const props = defineProps({ trans: Object })

    const typeColor = {
        'customer_onboard': '#3B82F6',    // Bright blue
        'earned_points': '#10B981',       // Bright green
        'redeemed_points': '#F97316',     // Bright orange
        'promotional': '#2DD4BF',         // Bright teal
        'custom': '#EF4444',              // Bright red
        'unspecified': '#6B7280'          // Gray
    };

    const chartOptions = computed(() => {
        return {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: "index",
                intersect: false,
            },
            plugins: {
                datalabels: false,
                legend: {
                    position: "top",
                    labels: {
                        color: isDark ? '#ffffff' : "#000",
                        font: { size: 12 }
                    }
                },
                title: {
                    display: false,
                    text: `Loyalty analysis`,
                },
                tooltip: {
                    callbacks: {
                        label(ctx) {
                            return `${ctx.dataset.label}: ${computedAmount(ctx.raw)}`;
                        },
                    },
                },
            },
            scales: {
                x: {
                    ticks: {
                        color: isDark ? '#ffffff' : "#000"
                    },
                    grid: {
                        color: isDark ? '#544F4F' : '#DCDADA'
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        drawOnChartArea: true,
                        color: isDark ? '#544F4F' : '#DCDADA'
                    },
                    title: {
                        display: true,
                        text: "Count",
                        color: isDark ? '#ffffff' : "#000"
                    },
                    ticks: {
                        color: isDark ? '#ffffff' : "#000"
                    },
                },
            },
        };
    });

    const transMap = computed(() => {
        const grouped = {};

        props.trans.forEach((t) => {
            const date = new Date(t.created_at).toLocaleDateString();
            const type = t.sms_temp || "Unknown";

            if (!grouped[type]) {
                grouped[type] = {};
            }

            grouped[type][date] = (grouped[type][date] || 0) + 1;
        });

        return grouped;
    });

    const chartData = computed(() => {
        const dates = Array.from(
            new Set(
                props.trans.map((t) => {
                    return new Date(t.created_at).toLocaleDateString();
                }),
            ),
        ).sort((a, b) => new Date(a) - new Date(b));

        const transDatasets = Object.keys(transMap.value).map((type) => ({
            type: "bar",
            label: type,
            data: dates.map((date) => transMap.value[type][date] || 0),
            borderColor: typeColor[type] || "#000",
            backgroundColor: typeColor[type] || "#000",
            tension: 0.4,
            yAxisID: "y",
        }));

        return {
            labels: dates.map((dt) =>
                new Date(dt).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                }),
            ),
            datasets: transDatasets,
        };
    });

    const tlTrans = computed(() => {
        const gp = {};
        props.trans.forEach((t) => {
            gp[t.sms_temp] = (gp[t.sms_temp] || 0) + 1;
        });

        return gp; //custom_message:2
    });

    const polarData = computed(() => {
        return {
            labels: Object.keys(tlTrans.value),
            datasets: [
                {
                    data: Object.values(tlTrans.value),
                    backgroundColor: Object.keys(tlTrans.value).map(
                        (key) => typeColor[key],
                    ),
                    hoverOffset: 30,
                    borderWidth: 2,
                },
            ],
        };
    });

    const polarOptions = computed(() => {
        return {
            responsive: true,
            cutout: "45%",
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: "top",
                    labels: {
                        color: isDark ? '#ffffff' : "#000",
                        font: { size: 11 },
                        generateLabels(chart) {
                            const data = chart.data;
                            const values = data.datasets[0].data;

                            return data.labels.map((label, i) => ({
                                text: `${label} (${computedAmount(values[i]).toLocaleString()})`,
                                fillStyle: data.datasets[0].backgroundColor[i],
                                color: isDark ? '#ffffff' : "#000",
                                index: i,
                            }));
                        },
                    },
                },
                title: {
                    display: false,
                    text: `Transation Analysis`,
                },
                tooltip: {
                    backgroundColor: "rgba(0, 0, 0, 0.9)",
                    position: "nearest",
                    yAlign: "bottom",
                    callbacks: {
                        label(ctx) {
                            return `${ctx.label}: ${ctx.raw.toLocaleString()}`;
                        },
                    },
                },
                datalabels: {
                    color: isDark ? '#ffffff' : "#000",
                    font: {
                        weight: "bold",
                    },
                    formatter(value, ctx) {
                        const data = ctx.dataset.data;
                        const total = data.reduce((a, b) => a + b, 0);
                        return ((value / total) * 100).toFixed(0) + "%";
                    },
                },
            },
            centerText: {
                label: "Total Messages",
                text: `${props.trans.length}`,
            },
        };
    });

</script>
<template>
    <div class="grid md:grid-cols-3 grid-cols-1 gap-2 md:gap-3 mb-5">
        <!--bar graph-->
        <div class="rounded-lg md:col-span-2 shadow-md border dark:border-gray-500">
            <h1 class="capitalize font-medium p-4 text-sm text-center">
                Monthly analysis
            </h1>
            <hr class="dark:text-gray-600" />
            <div class="py-3 md:px-2 ">
                <Bar v-if="trans.length > 0" :data="chartData" :options="chartOptions" style="height: 400px" />
                <div v-else class="h-full w-full min-h-80 flex text-sm items-center justify-center">
                    <h1>No records</h1>
                </div>
            </div>
        </div>
        <!--doughut chart-->
        <div class="rounded-lg w-full shadow-md border dark:border-gray-500">
            <h1 class="capitalize font-medium text-sm p-4 text-center">
                transactions analysis
            </h1>
            <hr class="dark:text-gray-600" />
            <div class="px-2 py-3 w-full h-full">
                <div v-if="trans.length > 0">
                    <Doughnut :data="polarData" :options="polarOptions" style="height: 400px" />
                </div>
                <div v-else
                    class="h-full text-sm min-h-80 w-full flex items-center justify-center text-slate-600 dark:text-slate-300">
                    <h1>No records</h1>
                </div>
            </div>
        </div>
    </div>
</template>