<script>
import { useForm } from "@inertiajs/vue3";
import MyTransition from "@/Components/MyTransition.vue";

export default {
    inject: ["showPasswordModal"],
    props: {
        user_id: {
            type: Number,
            require: true,
        },
    },
    components: {
        MyTransition,
    },
    data() {
        return {
            form: useForm({
                current_password: null,
                password: null,
                password_confirmation: null,
            }),
        };
    },
    methods: {
        closePasswordModal() {
            this.showPasswordModal = false;
        },
        updateUserPassword() {
            return this.form.post(
                `/user/profile/${this.user_id}/PasswordReset`,
                {
                    onFinish: () => this.closePasswordModal(),
                    onError: () => (this.showUserModal = true),
                },
            );
        },
    },
};
</script>
<template>
    <teleport to="body">
        <div
            v-show="showPasswordModal"
            @click.self="closePasswordModal"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex md:items-center justify-center px-4 dark:text-slate-300"
        >
            <MyTransition>
                <form
                    @submit.prevent="updateUserPassword()"
                    @click.stop
                    class="bg-white dark:bg-gray-900 rounded-md space-y-3 md:w-2/5 h-fit mt-8"
                >
                    <div class="p-3 flex items-center justify-center">
                        <h1 class="font-semibold">Change Password</h1>
                    </div>
                    <hr />
                    <!--passowrd inputs-->
                    <div class="px-3 py-2 space-y-3 text-sm">
                        <text-input
                            label="Current Password"
                            must
                            type="password"
                            v-model="form.current_password"
                            id="current_password"
                            required
                            :error="form.errors.current_password"
                        />
                        <text-input
                            label="New Password"
                            must
                            type="password"
                            v-model="form.password"
                            id="password"
                            required
                            :error="form.errors.password"
                        />
                        <text-input
                            label="Confirm Password"
                            must
                            type="password"
                            v-model="form.password_confirmation"
                            id="password_confirmation"
                            required
                            :error="form.errors.password_confirma"
                        />
                    </div>
                    <!--buttons section-->
                    <div class="p-3 space-x-2 flex items-center justify-end">
                        <primary-button name="Update" type="submit" />
                        <secondary-button
                            name="Cancel"
                            type="button"
                            @click="closePasswordModal"
                        />
                    </div>
                </form>
            </MyTransition>
        </div>
    </teleport>
</template>
