<script setup>
import { ref } from "vue";

const showSearch = ref(false);

const openSearch = () => {
    showSearch.value = !showSearch.value;
    if (showSearch.value) {
        setTimeout(() => {
            document.getElementById("search-mobile")?.focus();
        }, 0);
    }
};

defineProps({
    modelValue: String,
});

defineEmits(["update:modelValue"]);
</script>
<template>
    <!--on Big screen-->
    <div
        :class="$attrs.class"
        class="space-x-2 hidden text-xs md:flex md:items-center md:justify-start"
    >
        <input
            v-bind="{ ...$attrs, class: null }"
            @input="$emit('update:modelValue', $event.target.value)"
            :value="modelValue"
            type="text"
            name="search"
            id="search"
            placeholder="Search here ...."
            class="rounded-md shadow-sm w-full dark:border-b-blue-600 border-gray-100 dark:border-slate-700 focus:outline-none text-xs dark:bg-inherit form-input"
        />
    </div>
    <!--on small screen-->
    <div
        class="flex md:hidden items-start justify-end space-x-3 text-xs relative mx-auto"
    >
        <input
            v-show="showSearch"
            type="text"
            v-bind="{ ...$attrs, class: null }"
            @input="$emit('update:modelValue', $event.target.value)"
            :value="modelValue"
            class="border-gray-100 dark:border-slate-700 text-xs focus:outline-none dark:bg-inherit dark:text-slate-300 form-input absolute animate__animated animate__zoomIn animate__faster rounded-md bg-slate-50 z-9 top-7"
            name="search"
            id="search"
            ref="search"
        />
        <button type="button" @click="openSearch">
            <i
                class="fa-solid fa-magnifying-glass pr-2 font-semibold text-lg text-slate-600"
            ></i>
        </button>
    </div>
</template>
<style>
.form-input {
    border-bottom: 1px solid blue;
    outline: none;
}

.form-input:focus {
    border: none;
    outline: none;
}
</style>
