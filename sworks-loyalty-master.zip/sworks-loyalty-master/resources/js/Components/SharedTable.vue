<script setup>
import {
    computedAmount,
    computedTimeDate,
    computedDate,
} from "@/utlis/smartFun";
import { entry } from "@/utlis/perPageList.js";
import { computed, ref, watch, provide } from "vue";
import SearchInput from "./SearchInput.vue";
import { route } from "ziggy-js";
import { Link } from "@inertiajs/vue3";
import { encryptParams } from "@/utlis/EncryptKey";
import TransDetailsModal from "./TransDetailsModal.vue";

const props = defineProps({
    headers: {
        type: Array,
        required: true,
    },
    data: {
        type: Array,
        required: true,
    },
    message: {
        type: String,
        required: true,
    },
    hasAction: {
        type: Boolean,
        default: false,
    },
    ledger: {
        type: String,
        required: false,
    },
    showTotals: {
        type: Boolean,
        default: true,
    },
});

const perPage = ref(100);
const currentPage = ref(1);
const search = ref("");

const firstPage = () => {
    currentPage.value = 1;
};

const changePage = (page) => {
    currentPage.value = page;
    defineEmits(["page-changed", page]);
};

const nextPage = () => {
    if (currentPage.value < totalPages.value) {
        currentPage.value++;
    }
};

const prevPage = () => {
    if (currentPage.value > 1) {
        currentPage.value--;
    }
};

const showModal = ref(false);
const modalPrams = ref({
    docNo: null,
    type: null,
    branch: null,
});

const showDtlsModal = (docNo, type, branch) => {
    showModal.value = true;
    modalPrams.value = {
        docNo,
        type,
        branch,
    };
};

provide("showModal", {
    showTotals: props.showTotals,
    showModal,
    led: props.ledger,
    modalPrams,
});

const filteredData = computed(() => {
    //console.log('search:', search.value)
    const term = search.value?.toLowerCase().trim();
    if (!term) return props.data;
    return props.data.filter((item) => {
        return (
            (item.description &&
                item.description.toLowerCase().includes(term)) ||
            (item.stockcode &&
                item.stockcode.toString().toLowerCase().includes(term)) ||
            (item.doc_no &&
                item.doc_no.toString().toLowerCase().includes(term)) ||
            (item.scancode &&
                item.scancode.toString().toLowerCase().includes(term)) ||
            (item.name && item.name.toLowerCase().includes(term)) ||
            (item.accno && item.accno.toLowerCase().includes(term)) ||
            (item.supplier_name &&
                item.supplier_name.toLowerCase().includes(term)) ||
            (item.receipt_no &&
                item.receipt_no.toString().toLowerCase().includes(term)) ||
            (item.amount &&
                item.amount.toString().toLowerCase().includes(term)) ||
            (item.serial_no &&
                item.serial_no.toString().toLowerCase().includes(term))
        );
    });
});

const totalPages = computed(() => {
    return Math.ceil(filteredData.value.length / perPage.value);
});

const paginatedData = computed(() => {
    const start = (currentPage.value - 1) * perPage.value;
    const end = start + perPage.value;

    return filteredData.value.slice(start, end);
});

watch(
    search,
    () => {
        currentPage.value = 1;
    },
    { immediate: true },
);

//watch(paginatedData, (newVal) => {
//const today = new Date().toISOString().split('T')[0];
//const expiredWarrantyItems = newVal.filter(
//   element => element.warranty === 1 && element.warranty_exp_date < today
//);
//console.log('Expired warranty items:', expiredWarrantyItems);
//}, { immediate: true });
</script>
<template>
    <!--Details Modal-->
    <trans-details-modal v-if="showModal" />
    <!--search section-->
    <div
        class="flex items-center space-x-3 md:space-x-0 md:justify-evenly justify-start px-4 py-2"
    >
        <div class="space-x-2 md:flex md:items-center flex-1 md:justify-start">
            <select-input
                v-model="perPage"
                id="entry"
                class="shadow-md text-xs"
            >
                <option
                    v-for="(list, index) in entry"
                    :key="index"
                    :value="list.value"
                    select-inputed="10"
                >
                    {{ list.name }}
                </option>
            </select-input>
            <label for="entry" class="capitalize hidden md:flex text-xs"
                >Entries per page</label
            >
        </div>
        <search-input class="flex-1" v-model="search" />
    </div>
    <div
        class="w-full overflow-y-auto min-h-60 md:text-xs bg-white dark:bg-inherit dark:text-white max-h-96 scrollbar-thin md:rounded-lg rounded-sm shadow-lg shadow-blue-200 dark:shadow-slate-500"
    >
        <table
            class="table-auto bg-white dark:bg-gray-800 md:rounded-lg rounded-sm w-full md:text-xs"
        >
            <thead
                class="backdrop-blur-sm shadow-md font-normal dark:bg-gray-900 md:text-xs text-xs sticky top-0 bg-white"
            >
                <tr class="text-left">
                    <th
                        class="px-2 py-3.5 text-nowrap border-b border-gray-400 dark:border-gray-700"
                    >
                        #
                    </th>
                    <th
                        v-for="(head, index) in headers"
                        :key="index"
                        :class="{
                            'text-wrap':
                                head.dbName === 'cvalexcl' ||
                                head.dbName === 'cvalinc' ||
                                head.dbName === 'svalexcl' ||
                                head.dbName === 'svalinc',
                        }"
                        class="px-2 py-3.5 text-nowrap font-normal capitalize border-b border-gray-400 dark:border-gray-700"
                    >
                        <span v-if="head.dbName === 'price'">@</span
                        >{{ head.name }}
                        <span v-if="head.dbName === 'disc'">%</span>
                    </th>
                    <th
                        v-if="hasAction"
                        class="px-2 py-3.5 text-nowrap font-normal capitalize border-b border-gray-400 dark:border-gray-700"
                    >
                        Action
                    </th>
                </tr>
            </thead>
            <tbody class="text-xs md:text-xs min-h-full">
                <tr
                    v-if="paginatedData.length > 0"
                    v-for="(item, rowIndex) in paginatedData"
                    :key="rowIndex"
                    class="hover:bg-cyan-200 md:text-xs odd:bg-violet-50 dark:odd:bg-gray-500 bg-white dark:bg-gray-400 font-normal hover:cursor-default text-xs mx-2 dark:hover:bg-gray-700"
                    :class="{
                        'bg-red-600 text-red-500 font-semibold':
                            item.cancelled === 1 ||
                            (item.warranty === 1 &&
                                item.warranty_exp_date &&
                                new Date(item.warranty_exp_date) < new Date()),
                    }"
                >
                    <td
                        class="px-2 py-2 border-b text-nowrap text-xs md:text-xs hover:cursor-pointer border-gray-200 dark:border-gray-700 capitalize"
                    >
                        {{ rowIndex + 1 + (currentPage - 1) * perPage }}
                    </td>
                    <td
                        v-for="(header, colIndex) in headers"
                        :key="colIndex"
                        :class="{
                            'bg-orange-200 border font-medium text-center':
                                header.name === 'in stock' ||
                                header.dbName === 'qtyin' ||
                                header.dbName === 'qtyout' ||
                                header.dbName === 'abalstock' ||
                                header.dbName === 'cvalexcl' ||
                                header.dbName === 'cvalincl' ||
                                header.dbName === 'qty' ||
                                header.dbName === 'unitcostgv' ||
                                header.dbName === 'tqty' ||
                                header.dbName === 'tlngoods' ||
                                header.dbName === 'issue_no' ||
                                header.dbName === 'total_incl' ||
                                header.dbName === 'total_excl' ||
                                header.dbName === 'amount' ||
                                header.dbName === 'pay_amt',
                            'bg-green-300 border font-medium':
                                header.name === 'selling price' ||
                                header.dbName === 'svalexcl' ||
                                header.dbName === 'svalincl' ||
                                header.dbName === 'lngross' ||
                                header.dbName === 'tlntotal' ||
                                header.dbName === 'balance' ||
                                header.dbName === 'bal' ||
                                header.dbName === 'receipt_amt',
                            'bg-cyan-300': header.dbName === 'crn_amount',
                            'bg-yellow-200': header.dbName === 'wtx_amount',
                            'bg-violet-300': header.dbName === 'allocated',
                            'bg-yellow-300 border font-medium':
                                header.dbName === 'margin' ||
                                header.dbName === 'markup' ||
                                header.dbName === 'disc',
                            'select-all':
                                header.dbName === 'stockcode' ||
                                header.dbName === 'doc_no' ||
                                header.dbName === 'serial_no',
                            'bg-red-500': header.dbName === 'cancelled',
                            'bg-cyan-400': header.dbName === 'total_disc',
                        }"
                        class="px-2 py-2 border-b text-nowrap text-xs hover:cursor-pointer border-gray-200 dark:border-gray-700 capitalize"
                    >
                        <span
                            class="text-xs flex items-center justify-end"
                            v-if="
                                header.dbName === 'amount' ||
                                header.dbName === 'balance' ||
                                header.dbName === 'abalstock' ||
                                header.dbName === 'unitcostgv' ||
                                header.dbName === 'unitcostg' ||
                                header.dbName === 'sprice1' ||
                                header.dbName === 'sprice2' ||
                                header.dbName === 'svalexcl' ||
                                header.dbName === 'svalincl' ||
                                header.dbName === 'cvalexcl' ||
                                header.dbName === 'cvalincl' ||
                                header.dbName === 'markup' ||
                                header.dbName === 'packing' ||
                                header.dbName === 'margin' ||
                                header.dbName === 'qty' ||
                                header.dbName === 'qtyin' ||
                                header.dbName === 'qtyout' ||
                                header.dbName === 'lngross' ||
                                header.dbName === 'lngoods' ||
                                header.dbName === 'lnvat' ||
                                header.dbName === 'lntotal' ||
                                header.dbName === 'tqty' ||
                                header.dbName === 'grn_qty' ||
                                header.dbName === 'tlngoods' ||
                                header.dbName === 'tlnvat' ||
                                header.dbName === 'tlntotal' ||
                                header.dbName === 'lntotal' ||
                                header.dbName === 'ordered' ||
                                header.dbName === 'total_issue' ||
                                header.dbName === 'apprv' ||
                                header.dbName === 'lpo_qty' ||
                                header.dbName === 'packs' ||
                                header.dbName === 'qty_apprv' ||
                                header.dbName === 'bal' ||
                                header.dbName === 'receipt_amt' ||
                                header.dbName === 'rjctd' ||
                                header.dbName === 'tqty_issue' ||
                                header.dbName === 'witholding' ||
                                header.dbName === 'wtx_amount' ||
                                header.dbName === 'total_incl' ||
                                header.dbName === 'crn_amount' ||
                                header.dbName === 'total_excl' ||
                                header.dbName === 'total_vat' ||
                                header.dbName === 'price' ||
                                header.dbName === 'listprice' ||
                                header.dbName === 'allocated' ||
                                header.dbName === 'actual_bal' ||
                                header.dbName === 'credit' ||
                                header.dbName === 'debit' ||
                                header.dbName === 'paid' ||
                                header.dbName === 'disc' ||
                                header.dbName === 'total_disc' ||
                                header.dbName === 'pay_amt' ||
                                header.dbName === 'products'
                            "
                        >
                            {{ computedAmount(item[header.dbName]) }}
                        </span>
                        <span
                            v-else-if="
                                header.dbName === 'date' ||
                                header.dbName === 'warranty_exp_date' ||
                                header.dbName === 'start_date' ||
                                header.dbName === 'end_date' ||
                                header.dbName === 'run_date' ||
                                header.dbName === 'expiry' ||
                                header.dbName === 'date_used' ||
                                header.dbName === 'validity' ||
                                header.dbName === 'grn_date' ||
                                header.dbName === 'issue_date' ||
                                header.dbName === 'due_date' ||
                                header.dbName === 'date_paid'
                            "
                            class="text-xs md:text-xs flex items-center justify-start"
                        >
                            {{ computedDate(item[header.dbName]) }}
                        </span>
                        <span
                            v-else-if="
                                header.dbName === 'created_at' ||
                                header.dbName === 'updated_at'
                            "
                            class="text-xs"
                        >
                            {{ computedTimeDate(item[header.dbName]) }}
                        </span>
                        <span
                            v-else-if="
                                header.dbName === 'supplied' ||
                                header.dbName === 'approved' ||
                                header.dbName === 'active' ||
                                header.dbName === 'wtx' ||
                                header.dbName === 'posted' ||
                                header.dbName === 'cancelled' ||
                                header.dbName === 'sent' ||
                                header.dbName === 'used' ||
                                header.dbName === 'auto' ||
                                header.dbName === 'issued' ||
                                header.dbName === 'warranty'
                            "
                            class="text-center flex items-center justify-center"
                        >
                            <input
                                type="checkbox"
                                :name="header.name"
                                :id="header.name"
                                :checked="item[header.dbName]"
                                :class="[
                                    header.dbName === 'approved'
                                        ? 'text-green-500 font-medium'
                                        : 'text-orange-500 dark:text-orange-500',
                                ]"
                                class="w-3.5 h-3.5 text-center bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 focus:ring-2 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-blue-500 dark:focus:ring-2"
                                disabled
                            />
                        </span>
                        <span
                            v-else-if="header.dbName === 'status'"
                            class="rounded-lg text-xs p-1 font-medium italic text-center"
                            :class="[
                                item[header.dbName] === 0
                                    ? 'bg-green-200 text-green-800 border border-green-400'
                                    : 'bg-red-300 text-red-700 border border-red-400',
                            ]"
                        >
                            {{
                                item[header.dbName] === 0 ? "Valid" : "Invalid"
                            }}
                        </span>
                        <!--<Link v-else-if="header.name === 'Reference'"
                            :href="route('trans.listing.details', { led: ledger, doc_no: encryptParams(item.doc_no), type: encryptParams(item.ftype), branch: encryptParams(item.br_code) })"
                            class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-500 text-xs">
                        {{ item[header.dbName] }}
                        </Link>-->

                        <button
                            v-else-if="header.name === 'Reference'"
                            type="button"
                            @click.prevent="
                                showDtlsModal(
                                    item.doc_no,
                                    item.ftype,
                                    item.br_code,
                                )
                            "
                            class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-500 text-xs select-none"
                        >
                            {{ item[header.dbName] }}
                        </button>
                        <span class="text-xs" v-else>{{
                            item[header.dbName]
                        }}</span>
                    </td>
                    <td
                        v-if="hasAction"
                        class="px-2 py-2 border-b text-nowrap text-xs md:text-xs hover:cursor-pointer border-gray-200 dark:border-gray-700 capitalize"
                    >
                        <!--<Link :href="route('trans.listing.details', {
                            led: ledger,
                            doc_no: encryptParams(item.doc_no),
                            ...(item.type ? { type: encryptParams(item.type) } : {}),
                            branch: encryptParams(item.br_code)
                        })" class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-500">
                        <i class="fa-solid fa-eye"></i>
                        Details
                        </Link>-->
                        <button
                            type="button"
                            @click.prevent="
                                showDtlsModal(
                                    item.doc_no,
                                    item.type,
                                    item.br_code,
                                )
                            "
                            class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-500"
                        >
                            <i class="fa-solid fa-eye"></i>
                            Details
                        </button>
                    </td>
                </tr>
                <tr v-else>
                    <td
                        :colspan="headers.length + 1"
                        class="p-14 text-center text-slate-500 dark:text-gray-300"
                    >
                        {{ props.message }}
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <hr />
    <!--pagination-->
    <div
        v-if="paginatedData.length > 0"
        class="flex py-2 items-center justify-between md:px-4 text-xs"
    >
        <div>
            <p class="flex text-xs text-slate-600">
                <span class="hidden md:block">Showing&nbsp;&nbsp;</span>
                {{ currentPage }} of {{ totalPages }} pages
            </p>
        </div>
        <div class="p-2 space-x-3 flex items-center text-xs justify-center">
            <button
                @click="firstPage"
                :disabled="currentPage === 1"
                class="hover:text-blue-600 text-xs"
            >
                First
            </button>
            <button
                @click="prevPage"
                :disabled="currentPage === 1"
                class="hover:text-blue-600 text-xs"
            >
                <i class="fa-solid fa-angles-left"></i>
            </button>

            <span
                v-if="currentPage > 2"
                class="text-blue-600 font-semibold px-1"
                >...</span
            >

            <button
                v-if="currentPage > 1"
                @click="changePage(currentPage - 1)"
                class="text-blue-600 text-xs"
            >
                {{ currentPage - 1 }}
            </button>
            <span
                class="w-6 h-6 flex items-center justify-center text-xs text-white font-medium rounded-full bg-blue-800 border border-violet-500 shadow-lg shadow-violet-400"
            >
                {{ currentPage }}
            </span>
            <button
                v-if="currentPage < totalPages"
                @click="changePage(currentPage + 1)"
                class="text-blue-600 text-xs"
            >
                {{ currentPage + 1 }}
            </button>

            <span
                v-if="currentPage < totalPages - 1"
                class="text-blue-600 font-semibold px-1 text-xs"
                >...</span
            >

            <button
                @click="nextPage"
                :disabled="currentPage === totalPages"
                class="hover:text-blue-600 text-xs"
            >
                <i class="fa-solid fa-angles-right"></i>
            </button>
            <button
                @click="changePage(totalPages)"
                :disabled="currentPage === totalPages"
                class="hover:text-blue-600 text-xs"
            >
                Last
            </button>
        </div>
    </div>
</template>
