<script setup>
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import axios from "axios";

const props = defineProps({
    exportData: {
        type: Array,
        required: false,
    },
    transName: {
        type: String,
        required: true,
    },
});

async function exportToPdf() {
    //create a hidden div to hold our dynamic table
    const div = document.createElement("div");
    div.style.position = "absolute";
    div.style.left = "-9999px";
    div.style.width = "100%";
    div.style.marginTop = "20px";
    div.style.marginBottom = "20px";
    div.style.marginLeft = "20px";
    div.style.marginRight = "20px";
    document.body.appendChild(div);

    //create table
    const table = document.createElement("table");
    table.style.borderCollapse = "collapse";
    table.style.width = "100%";
    table.style.marginTop = "20px";
    table.style.marginBottom = "20px";
    table.style.marginLeft = "20px";
    table.style.marginRight = "20px";
    table.style.paddingRight = "1.25rem";
    table.style.paddingLeft = "1.25rem";
    table.style.paddingTop = "1.25rem";
    table.style.paddingBottom = "1.25rem";
    table.style.tableLayout = "auto";
    table.style.fontSize = "0.4rem";
    table.style.lineHeight = "1rem";

    const thead = document.createElement("thead");
    thead.style.fontWeight = "400";
    thead.style.textTransform = "uppercase";
    thead.style.paddingLeft = "0.125rem";
    thead.style.paddingRight = "0.125rem";
    thead.style.fontSize = "0.4rem";
    thead.style.lineHeight = "1rem";
    thead.style.backgroundColor = "rgb(148 163 184)";

    const tbody = document.createElement("tbody");
    tbody.style.fontSize = "0.35rem";
    tbody.style.lineHeight = "1rem";

    //add table headers
    const headers = Object.keys(props.exportData[0]);
    const tr = document.createElement("tr");
    headers.forEach((header) => {
        const th = document.createElement("th");
        th.style.paddingRight = "0.125rem";
        th.style.paddingLeft = "0.125rem";
        th.style.paddingTop = "0.125rem";
        th.style.paddingBottom = "0.125rem";
        th.style.fontWeight = "400";

        th.textContent = header;
        tr.appendChild(th);
    });
    thead.appendChild(tr);

    //add table rows
    props.exportData.forEach((trans) => {
        const tr = document.createElement("tr");
        tr.style.marginTop = "1rem";
        tr.style.marginBottom = "1rem";
        headers.forEach((header) => {
            const td = document.createElement("td");
            td.style.paddingLeft = "0.01rem";
            td.style.paddingRight = "0.01rem";
            td.style.paddingTop = "0.01rem";
            td.style.paddingBottom = "0.01rem";
            //td.style.borderWidth = '0.1rem'

            td.textContent = trans[header];
            tr.appendChild(td);
        });
        tbody.appendChild(tr);
    });

    table.appendChild(thead);
    table.appendChild(tbody);
    div.appendChild(table);

    //use html2canvas to convert the table to a canvas
    const canvas = await html2canvas(table, { scale: 2 });
    const imgData = canvas.toDataURL("image/png");

    //create PDF from canvas image
    const pdf = new jsPDF();
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, "PNG", 0, 0, pdfWidth, pdfHeight);
    pdf.save(props.transName + ".pdf");

    //clean up div
    document.body.removeChild(div);
}

function exportPdf() {
    axios
        .post(
            "/export-pdf",
            {
                title: props.transName,
                data: props.exportData,
            },
            {
                responseType: "blob",
            },
        )
        .then((response) => {
            //console.log(response)
            const blob = new Blob([response.data], {
                type: "application/pdf",
            });
            const link = document.createElement("a");
            link.href = window.URL.createObjectURL(blob);
            link.download = props.transName + ".pdf";
            link.click();
        })
        .catch((error) => {
            console.log("Error exporting PDF:", error);
        });
}
</script>
<template>
    <button
        type="button"
        @click="exportPdf()"
        :disabled="exportData <= 0"
        :class="{ 'cursor-not-allowed': exportData.length <= 0 }"
        class="border text-xs border-red-600 bg-red-600 text-red-100 rounded-md p-2 hover:text-slate-50 hover:bg-red-500"
    >
        <i class="fa-regular fa-file-pdf"></i>
        PDF
    </button>
</template>
