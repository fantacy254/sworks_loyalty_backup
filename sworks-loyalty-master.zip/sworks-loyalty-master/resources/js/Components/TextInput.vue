<script setup>
import { v4 as uuid } from "uuid";
import { computed } from "vue";
import { ref } from "vue";

//inheritAttrs: false,
const props = defineProps({
    id: {
        type: String,
        default() {
            return `text-input-${uuid()}`;
        },
    },
    type: {
        type: String,
        default: "text",
    },
    error: String,
    label: String,
    modelValue: { String, Number },
    placeholder: String,
    must: Boolean,
    disabled: Boolean,
});

defineEmits(["update:modelValue"]);

const showPassword = ref(false);
const inputType = computed(() => {
    if (props.type === "password") {
        return showPassword.value ? "text" : "password";
    }

    return props.type;
});
</script>
<template>
    <div class="space-y-1" :class="$attrs.class">
        <label v-if="label" class="text-xs md:text-sm font-medium" :for="id"
            >{{ label }}:<i v-if="must" class="text-red-500 font-semibold"
                >*</i
            ></label
        >
        <div
            class="relative rounded-md w-full shadow-sm select-none bg-white dark:bg-black/80 border border-gray-300 border-b-2 border-b-blue-500"
        >
            <input
                :id="id"
                class="focus:outline-none focus:border-none focus:ring-0 border-none outline-none w-full text-xs bg-inherit rounded-md p-2"
                :class="{
                    'text-red-500 border-red-500 border-b-red-500 caret-red-500':
                        error,
                }"
                :type="inputType"
                :value="modelValue"
                :placeholder="placeholder"
                :required="must"
                :disabled="disabled"
                @input="$emit('update:modelValue', $event.target.value)"
            />
            <button
                v-if="type === 'password'"
                type="button"
                @click="showPassword = !showPassword"
                class="absolute right-2 top-1/2 -translate-y-1/2 cursor-pointer focus:outline-none focus:border-none focus:ring-0 rounded-md"
            >
                <i
                    v-if="showPassword"
                    class="fa-regular fa-eye-slash text-sm"
                ></i>
                <i v-else class="fa-regular fa-eye text-sm"></i>
            </button>
        </div>
        <p v-if="error" class="font-normal text-xs text-red-500">
            {{ error }}
        </p>
    </div>
</template>
