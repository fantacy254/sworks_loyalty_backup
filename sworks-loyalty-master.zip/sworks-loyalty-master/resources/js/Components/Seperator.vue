<script setup>
defineProps({
    label: {
        type: String,
        default: "OR",
    },
});
</script>
<template>
    <!--or breaker-->
    <div class="flex items-center justify-center text-xs">
        <hr class="grow border-t border-gray-300 dark:border-gray-400" />
        <span class="mx-4 text-gray-400">OR</span>
        <hr class="grow border-t border-gray-300 dark:border-gray-400" />
    </div>
</template>
