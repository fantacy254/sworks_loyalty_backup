<script setup>


    const placeholders = [
        { name: '{auth_code}', description: 'Authorization code for user login.' },
        { name: '{user_name}', description: 'Name of the user.' },
        { name: '{user_email}', description: 'Email of the user.' },
        { name: '{user_password}', description: 'Initial password for the user.' },
        { name: '{cust_name}', description: 'Name of the customer.' },
        { name: '{points}', description: 'Smart loyalty Points.' },
        { name: '{voucher}', description: 'Redeem Voucher number.' },
        { name: '{expiry}', description: 'Expiry date of the voucher.' },
        { name: '\\n', description: 'New line character.' },
    ]

</script>
<template>
    <div class="p-2 space-y-1">
        <h1 class="text-xl text-gray-400 font-semibold">Placeholders</h1>
        <ul
            class="list-disc list-inside grid md:grid-cols-3 grid-cols-1 gap-2 text-xs text-gray-500 dark:text-slate-50 font-normal border dark:border-gray-400 rounded-md bg-gray-50 dark:bg-inherit p-1">
            <li v-for="placeholder in placeholders" :key="placeholder.name" class="">
                <strong>{{ placeholder.name }}</strong> - {{ placeholder.description }}
            </li>
        </ul>
    </div>
</template>