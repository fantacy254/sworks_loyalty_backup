<script setup>
import { computed } from "vue";
import BulkTemplate from "./BulkTemplate.vue";
import SmartTable from "./SmartTable.vue";

const props = defineProps({
    temps: Object,
    trans: Object,
});

const headers = computed(() => {
    const keys = ["id", "sender", "sms_temp", "updated_at", "company_id"];
    return Object.keys(props.trans[0] || {})
        .filter((key) => !keys.includes(key))
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});
</script>
<template>
    <div class="flex flex-col md:flex-row items-start space-x-3 mt-1">
        <!--send bulk-->
        <BulkTemplate :temps="temps" />
        <!--message transactions-->
        <div class="border rounded-md p-2 shadow-md w-full">
            <h1 class="p-2 text-center font-medium text-md">
                Today's Messages
            </h1>
            <hr />
            <smart-table
                :data="trans"
                :headers="headers"
                message="No records found"
            />
        </div>
    </div>
</template>
