<script setup>
import axios from "axios";
import { onBeforeUnmount, onMounted, onUnmounted, ref } from "vue";
import MyTransition from "@/Components/MyTransition.vue";
import { inject } from "vue";

const showModal = inject("showModal");
const searchId = inject("searchId");

const isActive = ref(false);
const users = ref([]);
const searchItem = ref("");

async function getUsers() {
    await axios
        .get("/user/company-users")
        .then((res) => {
            //console.log(res)
            users.value = res.data;
        })
        .catch((err) => {
            //console.log('User search modal error', err)
            page.props.flash.error = err;
        });
}

function closeModal() {
    showModal.value = false;
}

function handleKeyPress(event) {
    if (event.key === "Escape" || event.key === "ESC") {
        this.closeModal();
    }
}

function setId(id) {
    showModal.value = false;
    searchId.value = id;
}

onMounted(() => {
    isActive.value = true;
    window.addEventListener("keypress", handleKeyPress);
    getUsers();
});

onUnmounted(() => {
    users.value.splice(0, users.value.length);
});

onBeforeUnmount(() => {
    isActive.value = false;
    users.value.splice(0, users.value.length);
    window.removeEventListener("keypress", handleKeyPress);
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showModal"
            @click.self="closeModal()"
            @keydown="handleKeyPress"
            class="w-full backdrop-blur-sm mx-auto absolute z-9999 pt-20 inset-0 bg-black/40 min-h-screen px-2 md:px-0"
        >
            <my-transition>
                <div
                    @click.stop
                    class="md:mx-auto md:w-2/4 w-full bg-white dark:bg-gray-800 rounded-md md:px-3 px-1 py-1 space-y-1"
                >
                    <!---search section-->
                    <div class="flex items-center justify-start px-2">
                        <i
                            class="fa-solid fa-magnifying-glass text-lg text-slate-500"
                        ></i>
                        <input
                            ref="search"
                            v-model="searchItem"
                            type="text"
                            name="search"
                            id="search"
                            class="border-none ring-0 focus:ring-0 text-sm dark:bg-inherit dark:text-slate-300 focus:border-none text-left w-full"
                            placeholder="Search user"
                            autofocus
                        />
                        <span
                            class="bg-slate-200 dark:bg-gray-600 rounded-lg p-2 text-xs"
                        >
                            ESC
                        </span>
                    </div>
                    <hr />
                    <!--table section-->
                    <div
                        ref="tableContainer"
                        class="overflow-auto scrollbar-thin w-full h-80 rounded-t-sm md:rounded-t-md dark:text-slate-300"
                    >
                        <table
                            class="table-auto w-full border-collapse dark:bg-inherit"
                        >
                            <thead class="sticky top-0 border">
                                <tr class="text-left">
                                    <th
                                        class="w-auto font-medium border text-sm px-1 py-1"
                                    >
                                        Id
                                    </th>
                                    <th
                                        class="w-auto font-medium border text-sm px-1 py-1"
                                    >
                                        Name
                                    </th>
                                    <th
                                        class="w-auto font-medium border text-sm px-1 py-1"
                                    >
                                        Username
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-sm">
                                <tr
                                    v-for="(item, index) in users"
                                    :key="index"
                                    @click="setId(item.id)"
                                    class="text-sm even:bg-slate-100 dark:even:bg-gray-700 hover:bg-cyan-300 hover:cursor-pointer"
                                >
                                    <td
                                        class="w-auto py-2 px-2 text-xs border-b border-gray-200 dark:border-gray-600"
                                    >
                                        {{ index + 1 }}
                                    </td>
                                    <td
                                        class="w-auto py-2 px-2 text-xs border-b border-gray-200 dark:border-gray-600"
                                    >
                                        {{ item.username }}
                                    </td>
                                    <td
                                        class="w-auto py-2 px-2 text-xs border-b border-gray-200 dark:border-gray-600"
                                    >
                                        {{ item.name }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr />
                    <!--footer section-->
                    <div class="p-2 flex items-center justify-end text-xs">
                        <p class="text-slate-300 dark:text-slate-500">
                            powered by
                            <i
                                class="text-slate-500 dark:text-slate-400 font-semibold"
                                >smartSearch</i
                            >
                        </p>
                    </div>
                </div>
            </my-transition>
        </div>
    </teleport>
</template>
