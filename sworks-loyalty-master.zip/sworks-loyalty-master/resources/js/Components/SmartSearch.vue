<script setup>
import {
    inject,
    ref,
    computed,
    onMounted,
    onBeforeUnmount,
    onUnmounted,
} from "vue";
import axios from "axios";
    import MyTransition from "@/Components/MyTransition.vue";
    import { computedAmount } from "@/utlis/smartFun";

const showModal = inject("showModal");
const { custId, getCustomer, getStatement } = inject("custId");

const custList = ref([]);
const searchItem = ref("");
const isActive = ref(false);

async function getCusts() {
    if (isActive.value) {
        await axios
            .get("/search-cust")
            .then((res) => {
                custList.value = res.data;
            })
            .catch((error) => {
                console.log(error);
            });
    }
}

const filteredData = computed(() => {
    return custList.value.filter((item) => {
        return (
            (item.name &&
                item.name
                    .toLowerCase()
                    .indexOf(searchItem.value.toLowerCase())) !== -1 ||
            (item.accno &&
                item.accno
                    .toString()
                    .toLowerCase()
                    .includes(searchItem.value.toLowerCase())) ||
            (item.code && item.code.toString().includes(searchItem.value))
        );
    });
});

function closeModal() {
    showModal.value = false;
}

function handleKeyPress(event) {
    if (event.key === "Escape" || event.key === "ESC") {
        closeModal();
    }
}

function setId(id) {
    showModal.value = false;
    custId.value = id;
    getCustomer(id);
    if (typeof getStatement === "function") {
        getStatement(id);
    }
}

onMounted(() => {
    isActive.value = true;
    window.addEventListener("keypress", handleKeyPress);
    getCusts();
});

onUnmounted(() => {
    custList.value.splice(0, custList.value.length);
});

onBeforeUnmount(() => {
    isActive.value = false;
    custList.value.splice(0, custList.value.length);
    window.removeEventListener("keypress", handleKeyPress);
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showModal"
            @click.self="closeModal()"
            @keydown="handleKeyPress"
            class="w-full backdrop-blur-sm mx-auto absolute z-9999 pt-20 inset-0 bg-black/40 min-h-screen"
        >
            <my-transition>
                <div
                    @click.stop
                    class="md:mx-auto mx-2 md:w-2/4 w-auto bg-white dark:bg-gray-800 rounded-md md:px-3 py-1 space-y-1"
                >
                    <!---search section-->
                    <div class="flex items-center justify-start space-x-1">
                        <div class="flex items-center justify-start px-2 flex-1 border rounded-md border-gray-200">
                            <i class="fa-solid fa-magnifying-glass text-sm text-slate-500 dark:text-slate-300"></i>
                            <input ref="search" v-model="searchItem" type="text" name="search" id="search"
                                class="border-none text-xs ring-0 focus:ring-0 focus:border-none text-left w-full bg-inherit dark:text-slate-300"
                                placeholder="Search customer" autofocus />

                        </div>
                        <button type="button"
                            class="bg-slate-200 dark:bg-inherit dark:text-slate-400 rounded-lg p-2 text-xs">
                            ESC
                        </button>
                    </div>
                    <hr />
                    <!--table section-->
                    <div
                        ref="tableContainer"
                        class="overflow-auto scrollbar-thin w-full h-80 mx-0 px-2 md:mx-auto rounded-t-md"
                    >
                        <table
                            class="table-auto w-full mx-auto border-collapse dark:bg-inherit dark:text-slate-300"
                        >
                            <thead
                                class="shadow-sm sticky top-0 border text-xs backdrop-blur-sm bg-white/50 dark:bg-gray-800/50 dark:text-slate-300">
                                <tr class="text-left border">
                                    <th
                                        class="w-auto border border-gray-200 font-medium text-xs px-2 py-2 text-nowrap"
                                    >
                                        A/C No.
                                    </th>
                                    <th
                                        class="w-auto border border-gray-200 font-medium text-xs px-2 py-2 text-nowrap"
                                    >
                                        ID No.
                                    </th>
                                    <th
                                        class="w-auto border border-gray-200 font-medium text-xs px-2 py-2 text-nowrap"
                                    >
                                        Name
                                    </th>
                                    <th
                                        class="w-auto border border-gray-200 font-medium text-xs px-2 py-2 text-nowrap"
                                    >
                                        Points Balance
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-sm">
                                <tr
                                    v-for="(item, index) in filteredData"
                                    :key="index"
                                    @click="setId(item.code)"
                                    class="text-sm odd:bg-slate-100 hover:bg-cyan-300 hover:cursor-pointer dark:odd:bg-gray-800 dark:hover:bg-gray-700"
                                >
                                    <td
                                        class="w-auto py-2 px-2 text-nowrap text-xs border-b border-gray-200 dark:border-gray-500"
                                    >
                                        {{ item.accno }}
                                    </td>
                                    <td
                                        class="w-auto py-2 px-2 text-nowrap text-xs border-b border-gray-200 dark:border-gray-500"
                                    >
                                        {{ item.code }}
                                    </td>
                                    <td
                                        class="w-auto py-2 px-2 text-nowrap text-xs border-b border-gray-200 dark:border-gray-500"
                                    >
                                        {{ item.name }}
                                    </td>
                                    <td
                                        class="w-auto py-2 px-2 text-nowrap text-xs border-b text-right border-gray-200 dark:border-gray-500"
                                    >
                                        {{ computedAmount(item.actual_bal) }}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr />
                    <!--footer section-->
                    <div class="p-2 flex items-center text-xs justify-end">
                        <p class="text-slate-400 text-xs">
                            powered by
                            <i
                                class="text-slate-700 dark:text-slate-500 font-semibold text-xs"
                                >smartSearch</i
                            >
                        </p>
                    </div>
                </div>
            </my-transition>
        </div>
    </teleport>
</template>
