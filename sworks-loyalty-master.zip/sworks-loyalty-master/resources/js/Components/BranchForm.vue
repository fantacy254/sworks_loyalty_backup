<script setup>
import { Form } from "@inertiajs/vue3";

defineProps({
    companies: {
        type: Array,
        required: true,
        default: () => [],
    },
});
</script>
<template>
    <h1 class="text-center font-medium p-1 text-gray-400">Branch Form</h1>
    <p class="text-xs text-gray-400 p-2">Fill branch details below:</p>
    <Form
        method="post"
        action="/branch"
        v-slot="{ errors, reset, processing }"
        :disableWhileProcessing="true"
        :reset-on-success="true"
        class="w-auto p-2 space-y-2"
    >
        <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
            <select-input
                label="Company"
                name="company"
                :error="errors.company_id"
                placeholder="Select Company"
                autofocus
                must
            >
                <option value="" disabled selected>Select Company</option>
                <option
                    v-for="company in companies"
                    :key="company.id"
                    :value="company.id"
                >
                    {{ company.name }}
                </option>
            </select-input>
            <text-input
                type="text"
                label="Name"
                name="name"
                :error="errors.name"
                placeholder="name"
                must
            />
            <text-input
                type="text"
                label="Address"
                name="address"
                :error="errors.address"
                placeholder="address"
            />
            <text-input
                type="email"
                label="Email"
                name="email"
                :error="errors.email"
                placeholder="email"
            />
            <text-input
                type="tel"
                label="Phone"
                name="phone"
                :error="errors.phone"
                placeholder="phone"
            />
        </div>
        <!--button-->
        <div>
            <PrimaryButton
                type="submit"
                :loading="processing"
                class="text-xs border rounded-md p-2 mt-2"
                icon="fas fa-save"
                name="Save"
            />
            <SecondaryButton
                type="reset"
                @click="reset"
                class="text-xs border rounded-md p-2 mt-2 ml-2"
                icon="fas fa-xmark"
                name="Cancel"
            />
        </div>
    </Form>
</template>
