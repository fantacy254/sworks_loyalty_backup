<script setup>
import { provide, ref, computed } from "vue";
import _ from "lodash";
import PrintVoucher from "@/Components/PrintVoucher.vue";
import {
    computedDate,
    computedAmount,
    computedTimeDate,
} from "@/utlis/smartFun";

// Props
const props = defineProps({
    data: {
        type: Array,
        required: true,
    },
    header: {
        type: Array,
        required: true,
    },
    loading: {
        type: Boolean,
        required: true,
    },
});

// Modal logic
const showPrintModal = ref(false);
const voucherDoc = ref(null);

const openPrintModal = (index) => {
    voucherDoc.value = index;
    showPrintModal.value = true;
};

provide("showPrintModal", showPrintModal);
provide("voucherDoc", voucherDoc);

const perPage = ref(15);
const currentPage = ref(1);
const sortKey = ref("run_date");
const sortAsc = ref(true);

// Methods
function filterData() {
    currentPage.value = 1;
}
function sortBy(key) {
    if (sortKey.value === key) {
        sortAsc.value = !sortAsc.value;
    } else {
        sortKey.value = key;
        sortAsc.value = true;
    }
}
function changePage(page) {
    currentPage.value = page;
}
function nextPage() {
    // You may want to define totalPages as a computed property
    if (currentPage.value < totalPages.value) {
        currentPage.value++;
    }
}
function prevPage() {
    if (currentPage.value > 1) {
        currentPage.value--;
    }
}

// Example computed property for totalPages (adjust as needed)
const totalPages = computed(() => {
    return Math.ceil(props.data.length / perPage.value);
});
</script>
<template>
    <!--loalty voucher modal-->
    <print-voucher v-if="showPrintModal" />

    <div
        class="w-full min-h-48 max-h-96 overflow-auto scrollbar-thin scrollbar-thumb-current scrollbar-gutter-auto border border-gray-100 dark:border-gray-500 rounded-md scroll-auto  dark:bg-inherit">
        <table class="table-auto w-full rounded-sm">
            <thead class="backdrop-blur-sm shadow-sm text-xs md:text-sm sticky top-0 z-1 ">
                <tr class="text-left">
                    <th @click="sortBy(head.name)" v-for="(head, index) in header" :key="index"
                        class="p-3 font-medium text-nowrap capitalize border border-gray-200 dark:border-gray-700"
                        :class="{ 'cursor-pointer': head.sort }">
                        {{ head.name }}
                        <i v-if="head.sort" class="fa-solid fa-sort ml-5 text-slate-500"></i>
                    </th>
                </tr>
            </thead>
            <tbody class="text-xs  min-h-full transition-all ease-in-out transform delay-150 duration-300">
                <tr v-if="data.length > 0" v-for="(item, index) in data" :key="index"
                    class="hover:bg-slate-200 font-normal dark:bg-black/85 capitalize hover:cursor-default text-xs mx-2 dark:hover:bg-gray-700 transition-all ease-in-out transform delay-150 duration-300">
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ computedDate(item.run_date) }}
                    </td>
                    <td
                        class="px-2 py-2 border text-nowrap border-gray-100 dark:border-gray-700 text-xs w-auto uppercase">
                        {{ item.type }}
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ item.doc_no }}
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ computedAmount(item.amount) }}
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ computedAmount(item.points_in) }}
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ computedAmount(item.points_out) }}
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize font-semibold">
                        {{ computedAmount(item.running_balance) }}
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        <button v-if="item.type === 'RED'" type="button" @click="openPrintModal(item.reference)"
                            class="text-blue-500">
                            {{ item.reference }}
                        </button>
                        <span v-else>{{ item.reference }}</span>
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ item.input_by }}
                    </td>
                    <td
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ computedTimeDate(item.created_at) }}
                    </td>
                </tr>
                <tr v-else>
                    <td :colspan="headers?.length + 1" class="p-14 text-center text-slate-500 dark:text-gray-300">
                        No records found
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</template>
