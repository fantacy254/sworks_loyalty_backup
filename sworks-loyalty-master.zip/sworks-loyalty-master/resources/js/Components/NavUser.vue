<script setup>
import { usePage } from "@inertiajs/vue3";
import { useLayoutManager } from "@/composable/layoutManager";

const page = usePage();
const { menuCollapsed } = useLayoutManager();
</script>
<template>
    <div class="flex items-center gap-1">
        <img
            :src="page.props.auth.user.avatar ?? `/storage/Images/man.png`"
            alt="Avatar"
            :class="[menuCollapsed ? 'w-6 h-6' : 'w-8 h-8']"
        />
        <div v-if="!menuCollapsed">
            <p
class="text-sm text-start w-32 truncate text-ellipsis font-medium"
            >
                {{ page.props.auth.user.name }}
            </p>
            <p
class="text-xs text-start w-32 truncate text-ellipsis"
            >
                {{ page.props.auth.user.email }}
            </p>
        </div>
    </div>
</template>
