<script setup>
import {
    computedAmount,
    computedTimeDate,
    computedDate,
} from "@/utlis/smartFun";
import { entry } from "@/utlis/perPageList";
import { computed, ref, watch, inject } from "vue";
import SearchInput from "@/Components/SearchInput.vue";
import { useEncryption } from "@/composable/useEncryption";
import { router } from "@inertiajs/vue3";

const props = defineProps({
    headers: {
        type: Array,
        required: true,
    },
    data: {
        type: Array,
        required: true,
    },
    message: {
        type: String,
        default: "No data found",
    },
    hasAction: {
        type: Boolean,
        default: false,
    },
    ledger: {
        type: String,
        required: false,
    },
    hasPaging: {
        type: Boolean,
        default: true,
    },
    colored: {
        type: Boolean,
        default: false,
    },
    branches: {
        type: Array,
        required: false,
        default: () => [],
    },
});

const emit = defineEmits(["page-changed"]);
const { encryptedRoute } = useEncryption()

const perPage = ref(100);
const currentPage = ref(1);
const search = ref("");
const branch = ref(0);

const firstPage = () => {
    currentPage.value = 1;
};

const changePage = (page) => {
    currentPage.value = page;
    emit("page-changed", page);
};

const nextPage = () => {
    if (currentPage.value < totalPages.value) {
        currentPage.value++;
    }
};

const prevPage = () => {
    if (currentPage.value > 1) {
        currentPage.value--;
    }
};

const modalContext = inject("showMasterModal", { showModal: null, qCd: null });
const { showModal, qCd } = modalContext;

const showDtlsModal = (index) => {
    showModal.value = true;
    qCd.value = index;
};

const filteredData = computed(() => {
    const term = search.value?.toLowerCase().trim();

    if (!term && !branch.value) return props.data;

    return props.data.filter((item) => {
        const matchesSearch =
            !term ||
            (item.doc_no && item.doc_no.toLowerCase().includes(term)) ||
            (item.accno && item.accno.toLowerCase().includes(term)) ||
            (item.name && item.name.toLowerCase().includes(term)) ||
            (item.description &&
                item.description.toLowerCase().includes(term)) ||
            (item.customer && item.customer.toLowerCase().includes(term)) ||
            (item.code && item.code.toString().toLowerCase().includes(term)) ||
            (item.type && item.type.toString().toLowerCase().includes(term)) ||
            (item.pin_no &&
                item.pin_no.toString().toLowerCase().includes(term)) ||
            (item.reference &&
                item.reference.toString().toLowerCase().includes(term)) ||
            (item.notes &&
                item.notes.toString().toLowerCase().includes(term)) ||
            (item.phone && item.phone.toString().toLowerCase().includes(term)) ||
            (item.message && item.message.toString().toLowerCase().includes(term)) ||
            (item.initiator && item.initiator.toString().toLowerCase().includes(term));

        const matchesBranch =
            !branch.value ||
            parseFloat(item.branch_id) === parseFloat(branch.value);

        return matchesSearch && matchesBranch;
    });
});

const totalPages = computed(() => {
    return Math.ceil(filteredData.value.length / perPage.value);
});

const paginatedData = computed(() => {
    const start = (currentPage.value - 1) * perPage.value;
    const end = start + perPage.value;

    return filteredData.value.slice(start, end);
});

async function buildSecureLink(baseRoute, params) {
    const url = params ? await encryptedRoute(baseRoute, params) : route(baseRoute)

    router.visit(url)
}

watch(
    search,
    () => {
        currentPage.value = 1;
    },
    { immediate: true },
);
</script>
<template>
    <!--search section-->
    <div v-if="hasPaging"
        class="flex items-center space-x-3 md:space-x-0 md:justify-between justify-evenly md:px-4 py-2">
        <select-input v-model="perPage" id="entry" class="text-xs w-20 md:w-14">
            <option v-for="(list, index) in entry" :key="index" :value="list.value" select-inputed="10">
                {{ list.name }}
            </option>
        </select-input>
        <select-input v-if="branches.length > 0" v-model="branch" id="branches"
            class="text-xs w-full md:max-w-sm capitalize">
            <option :value="0" selected disabled>Select Branch</option>
            <option v-for="(br, index) in branches" :key="br.id" :value="br.id" select-inputed="10">
                {{ br.name.toLowerCase() }}
            </option>
        </select-input>
        <search-input v-model="search" class="md:w-max-sm" />
    </div>
    <!--table section-->
    <div
        class="w-full min-h-48 max-h-96 overflow-auto scrollbar-thin scrollbar-thumb-current scrollbar-gutter-auto border border-gray-100 dark:border-gray-500 rounded-md scroll-auto  dark:bg-inherit">
        <table class="table-auto rounded-sm w-full">
            <thead class="backdrop-blur-sm shadow-sm text-xs md:text-sm sticky top-0 z-1 ">
                <tr class="text-left">
                    <th v-if="headers?.length > 0"
                        class="p-3 font-medium text-nowrap border border-gray-200 dark:border-gray-700">
                        #
                    </th>
                    <th v-for="(head, index) in headers" :key="index" :class="{
                        'text-wrap truncate text-ellipsis':
                            head.dbName === 'desc' || head.dbName === 'message',
                    }" class="p-3 font-medium text-nowrap capitalize border border-gray-200 dark:border-gray-700">
                        {{ head.name }}
                    </th>
                    <th v-if="hasAction && paginatedData.length > 0"
                        class="p-2 font-medium text-nowrap capitalize border border-gray-200 dark:border-gray-700">
                        Action
                    </th>
                </tr>
            </thead>
            <tbody class="text-xs  min-h-full transition-all ease-in-out transform delay-150 duration-300">
                <tr v-if="paginatedData.length > 0" v-for="(item, rowIndex) in paginatedData" :key="rowIndex" :class="{
                    'even:bg-gray-50 dark:odd:bg-black/85': !colored,
                }"
                    class="hover:bg-slate-200 font-normal dark:bg-black/85 capitalize hover:cursor-default text-xs mx-2 dark:hover:bg-gray-700 transition-all ease-in-out transform delay-150 duration-300">
                    <td v-if="headers?.length > 0"
                        class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        {{ rowIndex + 1 + (currentPage - 1) * perPage }}
                    </td>
                    <td v-for="(header, colIndex) in headers" :key="colIndex" :class="{
                        'text-right bg-amber-200 dark:bg-amber-900':
                            header.dbName === 'amount' ||
                            header.dbName === 'total' ||
                            header.dbName === 'actual_bal' ||
                            header.dbName === 'points',
                        'text-right text-white bg-blue-950 font-semibold dark:bg-amber-900':
                            header.dbName === 'points' || header.dbName === 'acc_bal',
                        'select-all':
                            header.dbName === 'code' ||
                            header.dbName === 'accno' ||
                            header.dbName === 'reference',
                        'text-wrap truncate text-ellipsis':
                            header.dbName === 'desc' || header.dbName === 'message',
                    }"
                        class="p-3 text-nowrap font-normal text-xs hover:cursor-pointer border-b border-b-gray-200 dark:border-gray-700 capitalize">
                        <span class="text-xs text-right font-semibold" v-if="
                            header.dbName === 'amount' ||
                            header.dbName === 'amt' ||
                            header.dbName === 'actual_bal' ||
                            header.dbName === 'points' || header.dbName === 'acc_bal'
                        ">
                            {{ computedAmount(item[header.dbName]) }}
                        </span>
                        <span v-else-if="
                            header.dbName === 'date' ||
                            header.dbName === 'run_date' || header.dbName === 'trans_date'
                        " class="text-xs flex items-center justify-start">
                            {{ computedDate(item[header.dbName]) }}
                        </span>
                        <span v-else-if="header.dbName === '2FA'" :class="{
                            'text-green-600 bg-green-200':
                                item[header.dbName] === 'enabled',
                            'text-red-600 bg-red-200':
                                item[header.dbName] === 'inactive',
                        }" class="text-xs border rounded-xl p-1">
                            {{ item[header.dbName] }}
                        </span>
                        <span v-else-if="
                            header.dbName === 'created_at' ||
                            header.dbName === 'updated_at' ||
                            header.dbName === 'sent_at' ||
                            header.dbName === 'check_in_time' ||
                            header.dbName === 'check_out_time'
                        " class="text-xs">
                            {{ computedTimeDate(item[header.dbName]) }}
                        </span>
                        <input v-else-if="
                            header.dbName === 'status' ||
                            header.dbName === 'sent' ||
                            header.dbName === 'active'
                        " type="checkbox" :checked="item[header.dbName]"
                            class="h-3.5 w-3.5 text-xs rounded-full text-teal-600 accent-teal-600" disabled />
                        <img v-else-if="
                            header.dbName === 'image' ||
                            header.dbName === 'pic'
                        " :src="`/storage/${item[header.dbName]}`" alt="Image" class="rounded-md" heigh="40"
                            width="40" />
                        <span v-else-if="header.dbName === 'email'" class="text-xs lowercase">
                            {{ item[header.dbName]
                            }}<i v-if="item[header.dbName]" class="fa-solid fa-circle-check text-green-600"></i>
                        </span>
                        <span class="text-xs" v-else>{{
                            item[header.dbName] ?? ""
                            }}</span>
                    </td>
                    <td v-if="hasAction"
                        class="px-2 py-2 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                        <button type="button" @click="buildSecureLink('loyalty.edit', { id: item.code })">
                            <i class="fa-regular fa-pen-to-square"></i>
                        </button>
                    </td>
                </tr>
                <tr v-else>
                    <td :colspan="headers?.length + 1" class="p-14 text-center text-slate-500 dark:text-gray-300">
                        {{ props.message }}
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <hr v-if="paginatedData.length > 0" class="text-gray-300 dark:text-gray-500" />
    <!--pagination-->
    <div v-if="paginatedData.length > 0" class="flex items-center justify-between md:px-4 text-xs">
        <div class="flex items-center flex-col md:flex-row md:space-x-3">
            <p class="font-normal text-start md:leading-loose text-xs md:text-sm">
                Totals
                <strong class="text-xs sm:text-xs md:text-lg">{{
                    filteredData.length
                    }}</strong>
            </p>
            <p class="flex text-xs">
                <span class="hidden sm:hidden md:block">Showing&nbsp;&nbsp;</span>
                {{ currentPage }} of {{ totalPages }} pages
            </p>
        </div>
        <div v-if="totalPages > 1" class="p-1 space-x-3 flex items-center text-xs justify-center">
            <button @click="firstPage" :disabled="currentPage === 1" class="hover:text-blue-600 text-xs">
                First
            </button>
            <button @click="prevPage" :disabled="currentPage === 1" class="hover:text-blue-600 text-xs">
                <i class="fa-solid fa-angles-left"></i>
            </button>

            <span v-if="currentPage > 2" class="text-blue-600 font-semibold px-1">...</span>

            <button v-if="currentPage > 1" @click="changePage(currentPage - 1)" class="text-blue-600 text-xs">
                {{ currentPage - 1 }}
            </button>
            <span
                class="w-6 h-6 flex items-center justify-center text-xs text-white font-medium rounded-full bg-blue-800 border border-violet-500 shadow-none shadow-violet-400">
                {{ currentPage }}
            </span>
            <button v-if="currentPage < totalPages" @click="changePage(currentPage + 1)" class="text-blue-600 text-xs">
                {{ currentPage + 1 }}
            </button>

            <span v-if="currentPage < totalPages - 1" class="text-blue-600 font-semibold px-1 text-xs">...</span>

            <button @click="nextPage" :disabled="currentPage === totalPages" class="hover:text-blue-600 text-xs">
                <i class="fa-solid fa-angles-right"></i>
            </button>
            <button @click="changePage(totalPages)" :disabled="currentPage === totalPages"
                class="hover:text-blue-600 text-xs">
                Last
            </button>
        </div>
    </div>
</template>
