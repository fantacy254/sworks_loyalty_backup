<script setup>
import axios from "axios";
import { computed, inject, onMounted, onBeforeUnmount, ref } from "vue";
import MyTransition from "@/Components/MyTransition.vue";
import { computedAmount } from "@/utlis/smartFun";
import { usePage } from "@inertiajs/vue3";

//page
const page = usePage();

const showModal = inject("showModal");
const { stockcode, getItem, getStockDtls, cnd } = inject("modalFn");

const stockList = ref([]);
const searchItem = ref("");
const headers = ref();
const loading = ref(false);

const filteredData = computed(() => {
    return stockList.value.filter((item) => {
        return (
            (item.stockcode &&
                item.stockcode
                    .toString()
                    .includes(searchItem.value.toLowerCase())) ||
            (item.description &&
                item.description
                    .toString()
                    .toLowerCase()
                    .includes(searchItem.value.toLowerCase()))
        );
    });
});

const showStocks = async () => {
    loading.value = true;
    await axios
        .get("/inventory/searchStockList", {
            params: {
                cnd: cnd,
            },
        })
        .then((res) => {
            //console.log(res.data)
            if (res.data.length <= 0) {
                stockList.value.splice(0, stockList.value.length);
                return;
            }
            headers.value = Object.keys(res.data[0]).map((key) => ({
                name: key,
                headerName: key
                    .split("_")
                    .map(
                        (word) =>
                            word.charAt(0).toLocaleUpperCase() + word.slice(1),
                    )
                    .join(" "),
            }));
            stockList.value = res.data;
        })
        .catch((err) => {
            console.log(err);
            page.props.flash.error = err;
        })
        .finally(() => {
            loading.value = false;
        });
};

const stockSelectHandler = (id) => {
    //console.log(id)
    closeModal();
    stockcode.value = id;
    getItem();
    getStockDtls();
};

const closeModal = () => {
    showModal.value = false;
};
const handleKeyPress = (event) => {
    if (event.key === "Escape" || event.key === "ESC") {
        closeModal();
    }
};

onMounted(() => {
    window.addEventListener("keypress", handleKeyPress);
    showStocks();
});
onBeforeUnmount(() => {
    stockList.value.splice(0, stockList.value.length);
    window.removeEventListener("keydown", handleKeyPress);
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showModal"
            @click.self="closeModal()"
            @keydown="handleKeyPress"
            class="w-full backdrop-blur-sm mx-auto absolute z-9999 pt-20 inset-0 bg-black/40 min-h-screen"
        >
            <my-transition>
                <div
                    @click.stop
                    class="md:mx-auto mx-2 md:w-2/4 w-auto bg-white dark:bg-gray-800 rounded-md md:px-3 py-1 space-y-1"
                >
                    <!---search section-->
                    <div class="flex items-center justify-start px-2">
                        <i
                            class="fa-solid fa-magnifying-glass text-lg text-slate-300 dark:text-slate-300"
                        ></i>
                        <input
                            ref="search"
                            v-model="searchItem"
                            type="text"
                            name="search"
                            id="search"
                            class="border-none text-xs md:text-sm ring-0 focus:ring-0 focus:border-none text-left w-full bg-inherit dark:text-slate-300"
                            placeholder="Search customer"
                            autofocus
                        />
                        <span
                            class="bg-slate-100 dark:bg-inherit dark:text-slate-400 rounded-lg p-2 text-xs"
                        >
                            ESC
                        </span>
                    </div>
                    <hr />
                    <!--table section-->
                    <div
                        ref="tableContainer"
                        class="overflow-auto scrollbar-thin w-full h-80 md:mx-auto rounded-t-md"
                    >
                        <table
                            class="table-auto w-full mx-auto border-collapse dark:bg-inherit dark:text-slate-300"
                        >
                            <thead
                                class="sticky top-0 bg-slate-200 dark:bg-gray-900 text-xs"
                            >
                                <tr
                                    v-if="filteredData.length > 0"
                                    class="text-left"
                                >
                                    <th
                                        v-for="(head, index) in headers"
                                        :key="index"
                                        class="px-2 py-3 text-nowrap font-normal border border-slate-300 dark:border-gray-600"
                                    >
                                        {{ head.headerName }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-sm">
                                <tr
                                    v-if="filteredData.length > 0 && !loading"
                                    v-for="(item, rowIndex) in filteredData"
                                    :key="rowIndex"
                                    @click="stockSelectHandler(item.stockcode)"
                                    class="text-sm odd:bg-slate-100 hover:bg-orange-100 hover:cursor-pointer dark:odd:bg-gray-800 dark:hover:bg-gray-700"
                                >
                                    <td
                                        v-for="(header, colIndex) in headers"
                                        :key="colIndex"
                                        class="px-2 py-2 border text-nowrap border-gray-100 dark:border-gray-700 text-xs uppercase"
                                    >
                                        <span
                                            v-if="
                                                header.name === 's_price' ||
                                                header.name === 'qty'
                                            "
                                        >
                                            {{
                                                computedAmount(
                                                    item[header.name],
                                                )
                                            }}
                                        </span>
                                        <span v-else>{{
                                            item[header.name]
                                        }}</span>
                                    </td>
                                </tr>
                                <tr
                                    v-else-if="
                                        filteredData.length === 0 && !loading
                                    "
                                    class=""
                                >
                                    <td colspan="10" class="p-14 text-center">
                                        No Records found
                                    </td>
                                </tr>
                                <tr
                                    v-else-if="
                                        filteredData.length === 0 && loading
                                    "
                                    class=""
                                >
                                    <td colspan="10" class="p-14 text-center">
                                        Loading records...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr />
                    <!--footer section-->
                    <div class="p-2 flex items-center text-xs justify-envenly">
                        <div class="flex items-center justify-start w-full">
                            <span class="text-slate-400">
                                Total Records:
                                <span class="text-slate-600">{{
                                    filteredData.length
                                }}</span>
                            </span>
                        </div>
                        <div class="flex items-center justify-end w-full">
                            <p class="text-slate-400 text-xs">
                                powered by
                                <i
                                    class="text-slate-700 dark:text-slate-500 font-semibold text-xs"
                                    >smartSearch</i
                                >
                            </p>
                        </div>
                    </div>
                </div>
            </my-transition>
        </div>
    </teleport>
</template>
