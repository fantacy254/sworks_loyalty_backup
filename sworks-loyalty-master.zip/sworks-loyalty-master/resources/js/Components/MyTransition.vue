<script></script>
<template>
    <Transition
        appear
        type="animation"
        name="custom-classes"
        enter-active-class="animate__animated animate__bounceInDown"
        leave-active-class="animate__animated animate__bounceOutUp"
        leave-from-class="animate__animated"
        leave-to-class="animate__bounceOutUp"
    >
        <slot />
    </Transition>
</template>
