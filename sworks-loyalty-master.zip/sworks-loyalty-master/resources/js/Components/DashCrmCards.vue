<script setup>
import { computed } from "vue";
import CrmCard from "./CrmCard.vue";
import { usePage } from "@inertiajs/vue3";
import { computedAmount } from "@/utlis/smartFun.js";

const props = defineProps({
    texts: Object,
    temps: Object,
});

const page = usePage();

const computedSmsType = computed(() => {
    return Object.entries(
        props.texts.reduce((acc, record) => {
            const temp = record.sms_temp || "unspecified";
            acc[temp] = (acc[temp] || 0) + 1;
            return acc;
        }, {}),
    )
        .map(([template, count]) => ({ template, count }))
        .sort((a, b) => a.template - b.template);
});

const smsTypeName = (type) => {
    const tp = props.temps.find((ts) => type.toLowerCase() === ts.temp_id);
    if (!tp) return;

    return tp.name;
};

const tlUsage = computed(() => {
    return page.props.auth.company.sms_rate * props.texts.length;
});
</script>
<template>
    <div class="grid grid-cols-2 gap-4 md:grid-cols-6 p-2">
        <!--Sum card-->
        <CrmCard
            :count="texts.length"
            template="Total Messages"
            cardClass="secondary"
            :value="computedAmount(tlUsage)"
        />
        <!--cards-->
        <CrmCard
            v-for="(tmp, index) in computedSmsType"
            :key="index"
            :count="tmp.count"
            :template="smsTypeName(tmp.template) ?? `${tmp.template} Messages`"
        />
    </div>
</template>
