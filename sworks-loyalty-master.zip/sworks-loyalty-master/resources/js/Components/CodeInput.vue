<script setup>
import { computed, inject, onMounted, ref, watch } from "vue";
import { useAuthManager } from "@/composable/authManager";

const { submit } = inject("auth-code");
const auth = useAuthManager()

const length = 6;
const code = ref(Array(length).fill(""));
const inputs = ref([]);

const onInput = (event, index) => {
    const value = event.target.value.replace(/[^0-9]/g, "");
    code.value[index] = value;
    if (value && index < length - 1) {
        inputs.value[index + 1].focus();
    }
};

const onBackspace = (event, index) => {
    if (!code.value[index] && index > 0) {
        inputs.value[index - 1].focus();
    }
};

const getCode = computed(() => {
    return code.value.join('');
});

watch(getCode, (val) => {
    if (val.length === 6) {
        auth.authCode = getCode.value;
        submit();
    }
});

onMounted(() => {
    if (inputs.value[0]) {
        inputs.value[0].focus()
    }
})

</script>
<template>
    <div class="grid grid-cols-6 gap-2 md:p-4 w-full">
        <input v-for="(digit, index) in code" :key="index" type="text" maxlength="1" v-model="code[index]"
            @input="onInput($event, index)" @keydown.backspace="onBackspace($event, index)"
            :ref="el => inputs[index] = el" class="text-3xl font-bold p-2 rounded-2xl text-center bg-inherit" />
    </div>
</template>
