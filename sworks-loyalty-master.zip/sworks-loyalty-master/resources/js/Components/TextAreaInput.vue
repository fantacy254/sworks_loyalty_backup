<template>
    <div :class="$attrs.class" class="space-y-1">
        <label
            v-if="label"
class="text-sm text-slate-700 dark:text-slate-50 capitalize font-medium"
            :for="id"
            >{{ label }}:<i v-if="must" class="text-red-500 font-semibold"
                >*</i
            ></label
        >
        <textarea
            :id="id"
            ref="input"
            v-bind="{ ...$attrs, class: null }"
            class="rounded-md scrollbar-none w-full dark:border-b-blue-600 border-gray-100 dark:border-slate-700 focus:outline-none text-sm dark:bg-inherit dark:text-slate-50 form-input"
            cols="30"
            rows="5"
            :class="{ error: error }"
            :value="modelValue"
            @input="$emit('update:modelValue', $event.target.value)"
:required="must"
        />
        <div v-if="error" class="font-thin text-red-500">{{ error }}</div>
    </div>
</template>
<style>
.form-input {
    border-bottom: 1px solid blue;
    outline: none;
}

.form-input:focus {
    border: none;
    outline: none;
}
</style>
<script>
import { v4 as uuid } from "uuid";

export default {
    inheritAttrs: false,
    props: {
        id: {
            type: String,
            default() {
                return `textarea-input-${uuid()}`;
            },
        },
        error: String,
        label: String,
        modelValue: String,
        must: Boolean,
    },
    emits: ["update:modelValue"],
    methods: {
        focus() {
            this.$refs.input.focus();
        },
        select() {
            this.$refs.input.select();
        },
    },
};
</script>
