<script>
import { useForm } from "@inertiajs/vue3";
import MyTransition from "@/Components/MyTransition.vue";

export default {
    inject: ["showUserModal"],
    props: {
        data: {
            type: Object,
            required: true,
        },
    },
    components: {
        MyTransition,
    },
    data() {
        return {
            form: useForm({
                id: this.data.id,
                username: this.data.username,
                name: this.data.name,
                phone_no: this.data.phone_no,
                email: this.data.email,
            }),
        };
    },
    methods: {
        closeUserModal() {
            this.showUserModal = false;
        },
        updateUser() {
            return this.form.post(`/user/profile/${this.data.id}/update`, {
                onSuccess: () => this.closeUserModal(),
                onError: () => (this.showUserModal = true),
            });
        },
    },
};
</script>
<template>
    <teleport to="body">
        <div
            v-show="showUserModal"
            @click.self="closeUserModal"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/25 flex md:items-center justify-center dark:text-slate-300 px-4 md:px-0"
        >
            <MyTransition>
                <form
                    @submit.prevent="updateUser()"
                    @click.stop
                    class="bg-white dark:bg-gray-900 rounded-md h-fit mt-8 space-y-3 md:w-2/5 w-full"
                >
                    <div class="p-3 flex items-center justify-center">
                        <h1 class="font-semibold">Edit your profile details</h1>
                    </div>
                    <hr />
                    <!--user details-->
                    <div class="px-4 py-3 space-y-4 text-sm">
                        <h1 class="font-semibold">Personal Information</h1>
                        <text-input
                            label="Username"
                            type="text"
                            v-model="form.username"
                            id="username"
                            disabled
                            :error="form.errors.username"
                        />
                        <text-input
                            label="Full Name"
                            type="text"
                            v-model="form.name"
                            id="name"
                            :error="form.errors.name"
                        />
                        <text-input
                            label="Phone"
                            type="text"
                            v-model="form.phone_no"
                            id="phone_no"
                            :error="form.errors.phone_no"
                        />
                        <text-input
                            label="Email"
                            type="email"
                            v-model="form.email"
                            id="email"
                            :error="form.errors.email"
                        />
                    </div>
                    <hr />
                    <!--buttons section-->
                    <div class="p-3 space-x-2 flex items-center justify-end">
                        <primary-button name="Update" type="submit" />
                        <secondary-button
                            name="Cancel"
                            type="button"
                            @click="closeUserModal"
                        />
                    </div>
                </form>
            </MyTransition>
        </div>
    </teleport>
</template>
