<script setup>
import MyTransition from "@/Components/MyTransition.vue";
import axios from "axios";
import { inject, onBeforeMount, onUnmounted, ref } from "vue";
import {
    computedAmount,
    computedDate,
    computedTimeDate,
} from "@/utlis/smartFun.js";

const { showLoanDetailsModal, receiptId, req_type } = inject(
    "receiptDetailsModal",
);

const loanReceipts = ref([]);
const headers = [
    "Date",
    "Ref No",
    "Name",
    "Amount",
    "Allocated",
    "Balance",
    "Status",
    "Created At",
];
const paymentModes = ref([]);

const closePaymentsModal = () => {
    showLoanDetailsModal.value = false;
};

const getPaymentsDetails = async () => {
    //console.log('getting receipts details', req_type.value)
    try {
        if (req_type.value === "loans") {
            //console.log('getting loan receipts details');
            await axios
                .get("/loan/show", {
                    params: {
                        receipt_id: receiptId.value,
                    },
                })
                .then((res) => {
                    //console.log('loans', res.data);
                    loanReceipts.value.push({
                        date: computedDate(res.data.payment_date),
                        ref_no: res.data.ref_no.toUpperCase(),
                        amount: computedAmount(res.data.amount),
                        mode:
                            paymentModes.value.find(
                                (mode) => mode.id === res.data.pay_type_id,
                            )?.long_desc || "Unknown",
                        our_ref: res.data.ref,
                        created_at: computedTimeDate(res.data.created_at),
                        details: res.data.loans.map((loan) => ({
                            date: loan.date,
                            ref_no: loan.ref_no.toUpperCase(),
                            name: loan.agent_name,
                            amount: computedAmount(loan.amount),
                            allocated: computedAmount(loan.pivot.amount),
                            balance: computedAmount(loan.balance),
                            status: loan.status === "paid" ? "paid" : "Pending",
                            created_at: computedTimeDate(loan.created_at),
                        })),
                    });
                })
                .catch((err) => {
                    //console.log(err);
                });
        } else if (req_type.value === "floats") {
            await axios
                .get("/float/show", {
                    params: {
                        receipt_id: receiptId.value,
                    },
                })
                .then((res) => {
                    //console.log('floats', res.data);
                    loanReceipts.value.push({
                        date: computedDate(res.data.receipt_date),
                        ref_no: res.data.ref_no.toUpperCase(),
                        amount: computedAmount(res.data.amount),
                        mode:
                            paymentModes.value.find(
                                (mode) => mode.id === res.data.pay_type_id,
                            )?.long_desc || "Unknown",
                        our_ref: res.data.ref,
                        created_at: computedTimeDate(res.data.created_at),
                        details: res.data.floats.map((float) => ({
                            date: float.date,
                            ref_no: float.ref_no.toUpperCase(),
                            name: float.agent_name,
                            amount: computedAmount(float.amount),
                            allocated: computedAmount(float.pivot.amount),
                            balance: computedAmount(float.balance),
                            status:
                                float.status === "paid" ? "paid" : "Pending",
                            created_at: computedTimeDate(float.created_at),
                        })),
                    });
                })
                .catch((err) => {
                    //console.log(err);
                });
        }
    } catch (error) {
        //console.log(error);
    }
};

const getPaymentModes = async () => {
    await axios
        .get("/types")
        .then((res) => {
            paymentModes.value = res.data;
        })
        .catch((err) => {
            //console.log(err);
        });
};

onBeforeMount(() => {
    getPaymentModes();
    getPaymentsDetails();
});

onUnmounted(() => {
    getPaymentModes();
    getPaymentsDetails();
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showLoanDetailsModal"
            @click.self="closePaymentsModal"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex md:pt-8 md:items-start justify-center dark:text-slate-300 px-4 md:px-0"
        >
            <MyTransition>
                <div
                    class="bg-white dark:bg-gray-900 rounded-md h-fit mt-8 md:w-4/6 w-full"
                >
                    <div
                        class="w-full border-b-gray-300 border-b shadow-sm rounded-t-md bg-indigo-800/30 flex items-center justify-center"
                    >
                        <h1
                            class="font-medium text-sm text-slate-700 p-4 capitalize"
                        >
                            Receipt allocation details {{ req_type }}
                        </h1>
                    </div>
                    <!--table section-->
                    <div
                        class="w-full overflow-auto px-1 min-h-60 bg-white max-h-96 scrollbar-thin md:rounded-lg rounded-sm"
                    >
                        <table
                            class="table-auto w-full bg-white dark:bg-gray-800 md:rounded-lg rounded-sm"
                        >
                            <thead
                                class="bg-slate-200 dark:bg-gray-900 font-light text-xs sticky top-0"
                            >
                                <tr class="text-left">
                                    <th
                                        class="px-2 py-3 text-nowrap font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        #
                                    </th>
                                    <th
                                        v-for="(head, index) in headers"
                                        :key="index"
                                        class="px-2 py-3 text-nowrap font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ head }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-xs">
                                <tr
                                    v-if="loanReceipts.length > 0"
                                    v-for="(receipt, index) in loanReceipts[0]
                                        .details"
                                    :key="index"
                                    :class="
                                        receipt.status === 'paid'
                                            ? 'bg-green-500/30 border-green-200'
                                            : 'bg-orange-500/30 border-orange-100'
                                    "
                                    class="text-xs border-b"
                                >
                                    <td
                                        class="px-2 py-2 text-nowrap text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ index + 1 }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.date }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.ref_no }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.name }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.amount }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.allocated }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.balance }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap capitalize text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.status }}
                                    </td>
                                    <td
                                        class="px-2 py-2 text-nowrap uppercase text-xs font-normal border dark:border-gray-700"
                                    >
                                        {{ receipt.created_at }}
                                    </td>
                                </tr>
                                <tr v-else>
                                    <td
                                        colspan="9"
                                        class="p-14 text-center text-slate-500 dark:text-gray-300 animate-pulse"
                                    >
                                        Loading receipts details ...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr />
                    <p class="px-2 text-xs text-slate-400">Receipt Details</p>
                    <div
                        v-if="loanReceipts.length > 0"
                        class="text-xs flex justify-between p-2 space-x-1"
                    >
                        <text-input
                            v-model="loanReceipts[0].date"
                            label="Date"
                            disabled
                        />
                        <text-input
                            v-model="loanReceipts[0].ref_no"
                            label="Ref No"
                            disabled
                        />
                        <text-input
                            v-model="loanReceipts[0].amount"
                            label="Amount"
                            disabled
                        />
                        <text-input
                            v-model="loanReceipts[0].mode"
                            label="Mode"
                            disabled
                        />
                        <text-input
                            v-model="loanReceipts[0].our_ref"
                            label="Your Ref"
                            disabled
                        />
                        <text-input
                            v-model="loanReceipts[0].created_at"
                            label="Created At"
                            disabled
                        />
                    </div>
                    <div v-else class="p-2 flex items-center justify-center">
                        <p class="animate-pulse text-xs text-slate-400">
                            Loading receipt details...
                        </p>
                    </div>
                    <hr />
                    <!--Buttons section-->
                    <div class="p-2 text-xs flex items-center justify-end">
                        <secondary-button
                            type="reset"
                            name="Cancel"
                            @click="closePaymentsModal()"
                        />
                    </div>
                </div>
            </MyTransition>
        </div>
    </teleport>
</template>
