<script setup>
import { useForm } from "@inertiajs/vue3";
import axios from "axios";
import { onMounted, ref, watch } from "vue";

defineProps({
    companies: {
        type: Array,
        required: true,
        default: () => [],
    },
});

const form = useForm({
    adminState: 0,
    company: 0,
    user_id: 0,
    branch: null,
    name: null,
    username: null,
    email: null,
    phone: null,
    access_level: 2,
});

const branches = ref([]);
const brMsg = ref("Select Branch");
const usrMsg = ref("Select User");

const getBranches = async () => {
    branches.value = [];

    const res = await axios
        .get("/branch/show", {
            params: {
                company: form.company,
            },
        })
        .catch((e) => console.log(e.message));

    if (!res || res.data.length === 0) {
        brMsg.value = "No branches found";
        return;
    }

    branches.value = res.data;
    brMsg.value = "Select Branch";
};

const levels = ref([]);
const getLevels = async () => {
    const res = await axios
        .get("/access/show")
        .catch((e) => console.log(e.message));

    if (!res || res.data.length === 0) return;

    levels.value = res.data;
};
const users = ref([]);
const getAdminUsers = async () => {
    users.value = [];

    const res = await axios
        .get("/company/admin/show", {
            params: {
                company: form.company,
            },
        })
        .catch((e) => console.log(e.message));

    if (!res || res.data.length === 0) {
        form.reset(
            "user_id",
            "branch",
            "name",
            "email",
            "phone",
            "username",
            "access_level",
        );
        usrMsg.value = "No users found";
        return;
    }

    users.value = res.data;
    usrMsg.value = "Select User";
};

onMounted(() => {
    getLevels();
});

const formCompanyHandler = async () => {
    await getBranches();
    await getAdminUsers();
};

const setFormUser = () => {
    if (!form.user_id) return;

    const user = users.value.find((u) => u.id === form.user_id);
    if (!user) return;

    form.branch = user.branch_id;
    form.name = user.name;
    form.email = user.email;
    form.phone = user.phone;
    form.username = user.username;
    form.access_level = user.access_level_id;
};

const submit = () => {
    form.post("/company/admin", {
        onSuccess: () => {
            form.reset(
                "adminState",
                "company",
                "user_id",
                "branch",
                "name",
                "email",
                "phone",
                "username",
                "access_level",
            );
        },
    });
};

watch(
    () => form.adminState,
    () => {
        form.reset(
            "user_id",
            "branch",
            "name",
            "email",
            "phone",
            "username",
            "access_level",
        );
    },
    { immediate: true },
);
</script>
<template>
    <h1 class="text-center font-medium p-1 text-gray-400">Admin Form</h1>
    <p class="text-xs text-gray-400 p-2">Fill admin details below:</p>
    <form @submit.prevent="submit()" class="w-auto p-2 space-y-2">
        <div
            class="grid grid-cols-1 md:grid-cols-4 gap-2 ease-linear duration-300"
        >
            <div>
                <select-input
                    @change="formCompanyHandler()"
                    label="Company"
                    v-model="form.company"
                    name="company"
                    :error="form.errors.company"
                    placeholder="Select Company"
                    autofocus
                    must
                >
                    <option :value="0" disabled selected>Select Company</option>
                    <option
                        v-for="company in companies"
                        :key="company.id"
                        :value="company.id"
                    >
                        {{ company.name }}
                    </option>
                </select-input>
                <!--admin set selection-->
                <div
                    v-if="form.company"
                    class="grid grid-cols-2 md:grid-cols-1 gap-1 mt-3"
                >
                    <!--select existing user-->
                    <div>
                        <input
                            type="radio"
                            v-model="form.adminState"
                            :value="0"
                            name="admin-state"
                            id="select-admin"
                            class="hidden peer"
                            checked
                        />
                        <label
                            for="select-admin"
                            class="text-xs border rounded-md p-2 md:w-48 w-auto block text-center cursor-pointer peer-checked:bg-blue-600 peer-checked:text-white"
                        >
                            <i class="fas fa-user"></i>
                            <span class="ml-1">Select Existing User</span>
                        </label>
                    </div>
                    <!--create new user-->
                    <div>
                        <input
                            type="radio"
                            v-model="form.adminState"
                            :value="1"
                            name="admin-state"
                            id="new-admin"
                            class="hidden peer"
                        />
                        <label
                            for="new-admin"
                            class="text-xs border rounded-md p-2 md:w-48 w-auto block text-center cursor-pointer peer-checked:bg-blue-600 peer-checked:text-white"
                        >
                            <i class="fas fa-user-plus"></i>
                            <span class="ml-1">Create New User</span>
                        </label>
                    </div>
                </div>
            </div>
            <div v-if="form.company" class="col-span-2 md:px-4">
                <select-input
                    @change="setFormUser()"
                    v-if="form.adminState === 0"
                    label="Admin"
                    v-model="form.user_id"
                    name="user"
                    :error="form.errors.user_id"
                    autofocus
                >
                    <option :value="0" disabled selected>{{ usrMsg }}</option>
                    <option
                        v-for="(user, index) in users"
                        :key="index"
                        :value="user.id"
                    >
                        {{ user.name }}
                    </option>
                </select-input>
                <select-input
                    :disabled="form.adminState === 0"
                    v-model="form.branch"
                    label="Branch"
                    name="branch"
                    :error="form.errors.branch_id"
                    autofocus
                    must
                >
                    <option value="" disabled selected>{{ brMsg }}</option>
                    <option
                        v-for="(branch, index) in branches"
                        :key="index"
                        :value="branch.id"
                    >
                        {{ branch.name }}
                    </option>
                </select-input>
                <text-input
                    :disabled="form.adminState === 0"
                    v-if="form.adminState === 1"
                    v-model="form.name"
                    type="text"
                    label="Name"
                    name="name"
                    :error="form.errors.name"
                    placeholder="name"
                    must
                />
                <text-input
                    :disabled="form.adminState === 0"
                    v-model="form.username"
                    type="text"
                    label="Username"
                    name="username"
                    :error="form.errors.username"
                    placeholder="username"
                />
                <text-input
                    :disabled="form.adminState === 0"
                    v-model="form.email"
                    type="email"
                    label="Email"
                    name="email"
                    :error="form.errors.email"
                    placeholder="Enter a valid email"
                />
                <text-input
                    :disabled="form.adminState === 0"
                    v-model="form.phone"
                    type="tel"
                    label="Phone"
                    name="phone"
                    :error="form.errors.phone"
                    placeholder="phone"
                />
                <select-input
                    :disabled="form.adminState === 0"
                    v-model="form.access_level"
                    label="Access Level"
                    name="access_level"
                    :error="form.errors.access_level"
                    placeholder="Select Access level"
                    autofocus
                    must
                    class=""
                >
                    <option value="" disabled selected>
                        Select Access level
                    </option>
                    <option
                        v-for="(level, index) in levels"
                        :key="index"
                        :value="level.id"
                        class="capitalize"
                    >
                        {{ level.name.toUpperCase() }}
                    </option>
                </select-input>
            </div>
        </div>
        <!--button-->
        <div v-if="form.company">
            <PrimaryButton
                type="submit"
                :loading="form.processing"
                class="text-xs border rounded-md p-2 mt-2"
                icon="fas fa-save"
                name="Save"
            />
            <SecondaryButton
                type="button"
                @click="resetForm"
                class="text-xs border rounded-md p-2 mt-2 ml-2"
                icon="fas fa-xmark"
                name="Cancel"
            />
        </div>
    </form>
</template>
