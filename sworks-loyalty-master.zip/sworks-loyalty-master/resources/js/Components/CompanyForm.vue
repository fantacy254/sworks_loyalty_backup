<script setup>
import { Form } from "@inertiajs/vue3";
</script>
<template>
    <h1 class="text-center p-1 font-medium text-gray-400">Company Form</h1>
    <p class="text-xs text-gray-400 p-2">Fill company details below:</p>
    <Form
        method="post"
        action="/company"
        v-slot="{ errors, reset, processing }"
        :disableWhileProcessing="true"
        :reset-on-success="true"
        class="w-auto p-2 space-y-2"
    >
        <div class="grid grid-cols-1 md:grid-cols-3 gap-2">
            <text-input
                type="text"
                label="Name"
                name="name"
                :error="errors.name"
                placeholder="name"
                autofocus
                must
            />
            <text-input
                type="text"
                label="Address"
                name="address"
                :error="errors.address"
                placeholder="address"
                must
            />
            <text-input
                type="email"
                label="Email"
                name="email"
                :error="errors.email"
                placeholder="email"
                must
            />
            <text-input
                type="tel"
                label="Phone"
                name="phone"
                :error="errors.phone"
                placeholder="phone"
                must
            />
            <text-input
                type="text"
                label="Pin No"
                name="pin_no"
                :error="errors.pin_no"
                placeholder="pin_no"
                must
            />
        </div>
        <!--button-->
        <div>
            <PrimaryButton
                type="submit"
                :loading="processing"
                class="text-xs border rounded-md p-2 mt-2"
                icon="fas fa-save"
                name="Save"
            />
            <SecondaryButton
                type="reset"
                @click="reset"
                class="text-xs border rounded-md p-2 mt-2 ml-2"
                icon="fas fa-xmark"
                name="Cancel"
            />
        </div>
    </Form>
</template>
