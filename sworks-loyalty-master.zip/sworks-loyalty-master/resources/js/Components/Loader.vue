<template>
    <div
        v-show="show"
        class="fixed inset-0 flex items-center justify-center bg-gray-200/30 z-999999"
    >
        <div class="loader"></div>
    </div>
</template>

<script setup>
defineProps({
    show: {
        type: Boolean,
        default: false,
    },
});
</script>

<style>
/* HTML: <div class="loader"></div> */
.loader {
    width: 45px;
    aspect-ratio: 1;
    border-radius: 50%;
    border: 5px solid #0000;
    border-right-color: #ffa50097;
    position: relative;
    animation: l24 1s infinite linear;
}

.loader:before,
.loader:after {
    content: "";
    position: absolute;
    inset: -4px;
    border-radius: 50%;
    border: inherit;
    animation: inherit;
    animation-duration: 2s;
}

.loader:after {
    animation-duration: 4s;
}

@keyframes l24 {
    100% {
        transform: rotate(1turn);
    }
}
</style>
