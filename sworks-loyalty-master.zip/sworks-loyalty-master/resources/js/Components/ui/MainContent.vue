<script setup>
import ContentHeader from "./ContentHeader.vue";
import ContentFooter from "@/Components/ui/ContentFooter.vue";
import { useLayoutManager } from "@/composable/layoutManager.js";

const { showFooterNavUser } = useLayoutManager();
</script>
<template>
    <main
        @click="showFooterNavUser = false"
        class="md:p-2 grid grid-cols-1 w-full h-screen"
    >
        <div
            class="rounded-lg h-full md:shadow-md dark:bg-black/80 bg-white overflow-y-auto scroll-smooth scrollbar-none"
        >
            <ContentHeader />
            <main class="md:p-2 p-1 min-h-screen">
                <slot />
            </main>
            <ContentFooter />
        </div>
    </main>
</template>
