<script setup>
import { usePage } from "@inertiajs/vue3";
import { useLayoutManager } from "@/composable/layoutManager";

defineProps({
    navItems: {
        type: Array,
        default: () => [],
    },
});

const page = usePage();
const {
    isMobile,
    isMobileMenuOpen,
    menuCollapsed,
    menuToggles,
    toggleNavMenu,
    toggleSubMenu,
    subToggles,
    showFooterNavUser,
} = useLayoutManager();
</script>
<template>
    <div
        @click="showFooterNavUser = false"
        class="p-2 w-full overflow-y-auto scroll-smooth ease-in-out transition-all scrollbar-none duration-300"
        :class="[isMobile ? 'h-[80%]' : 'h-[73%]']"
    >
        <ul class="space-y-2 p-1 text-sm w-full">
            <li
                v-for="(item, index) in navItems"
                :key="index"
                :class="{
                    'bg-gray-200 border border-gray-300 dark:border-gray-500 dark:bg-inherit rounded-md text-blue-600':
                        page.url === item.url,
                }"
                class=""
            >
                <Link
                    @click="isMobileMenuOpen = false"
                    v-show="item.show"
                    v-if="!item.dropmenu"
                    :href="item.url"
                    class="flex items-center px-3 py-3 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-500"
                >
                    <i :class="`${item.icon} mr-1`"></i>
                    <p
                        v-if="!menuCollapsed"
                        class="ease-in-out transition-all duration-300 text-nowrap"
                    >
                        {{ item.label }}
                    </p>
                </Link>
                <button
                    type="button"
                    v-else
                    @click="toggleNavMenu(index)"
                    class="inline-flex items-center justify-start w-full px-3 py-3 text-sm border border-gray-200 dark:border-gray-500 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                >
                    <div class="flex items-center justify-start flex-1">
                        <i :class="`${item.icon} mr-1`"></i>
                        <p
                            v-if="!menuCollapsed"
                            class="ease-in-out transition-all duration-300"
                        >
                            {{ item.label }}
                        </p>
                    </div>
                    <i
                        class="fas fa-chevron-right text-xs"
                        :class="{
                            'ml-2': !menuCollapsed,
                            ' rotate-90': menuToggles.includes(index),
                        }"
                    ></i>
                </button>
                <ul
                    v-if="item.dropmenu && menuToggles.includes(index)"
                    class="space-y-1 p-1"
                >
                    <li
                        v-for="(sub, subIndex) in item.subNavItems"
                        :key="subIndex"
                        :class="{
                            'bg-gray-200 border border-gray-300 dark:border-gray-500 dark:bg-inherit rounded-md text-blue-600':
                                page.url === sub.suburl,
                        }"
                        class=""
                    >
                        <Link
                            @click="isMobileMenuOpen = false"
                            v-show="sub.show"
                            v-if="!sub.dropmenu"
                            :href="sub.suburl"
                            class="flex items-center px-3 py-3 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-500"
                        >
                            <i :class="`${sub.subicon} mr-1`"></i>
                            <p
                                v-if="!menuCollapsed"
                                class="ease-in-out transition-all duration-300 text-nowrap"
                            >
                                {{ sub.sublabel }}
                            </p>
                        </Link>
                        <button
                            type="button"
                            v-else
                            @click="toggleSubMenu(subIndex)"
                            class="inline-flex items-center justify-start w-full px-3 py-3 text-sm border border-gray-200 dark:border-gray-500 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700"
                        >
                            <div class="flex items-center justify-start flex-1">
                                <i :class="`${sub.subicon} mr-1 text-sm`"></i>
                                <p
                                    v-if="!menuCollapsed"
                                    class="ease-in-out transition-all duration-300 text-nowrap"
                                >
                                    {{ sub.sublabel }}
                                </p>
                            </div>
                            <i
                                class="fas fa-chevron-right text-xs"
                                :class="{
                                    'ml-2': !menuCollapsed,
                                    ' rotate-90': subToggles.includes(subIndex),
                                }"
                            ></i>
                        </button>
                        <ul
                            v-if="sub.dropmenu && subToggles.includes(subIndex)"
                            class="space-y-1 p-1"
                        >
                            <li
                                v-for="(min, minIndex) in sub.minimenu"
                                :key="minIndex"
                                :class="{
                                    'bg-gray-200 border border-gray-300 dark:bg-gray-700 rounded-lg text-blue-600':
                                        page.url === min.miniurl,
                                }"
                                class=""
                            >
                                <Link
                                    @click="isMobileMenuOpen = false"
                                    v-show="min.show"
                                    :href="min.miniurl"
                                    class="flex items-center px-3 py-3 rounded-md hover:bg-gray-200 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-500"
                                    :class="[
                                        menuCollapsed ? 'text-lg' : 'text-sm',
                                    ]"
                                >
                                    <i :class="`${min.minicon} mr-1`"></i>
                                    <p
                                        v-if="!menuCollapsed"
                                        class="ease-in-out transition-all duration-300 text-nowrap"
                                    >
                                        {{ min.minilabel }}
                                    </p>
                                </Link>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</template>
