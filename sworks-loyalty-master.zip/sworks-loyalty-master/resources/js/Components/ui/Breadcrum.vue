<script setup>
    import { usePage } from '@inertiajs/vue3';



    defineProps({ breadcrums: { type: Object, required: true, default: [] } })
    const page = usePage()
</script>
<template>
    <div class="p-2">
        <ul class="inline-flex items-end space-x-2">
            <i class="fa-solid fa-arrow-left"></i>
            <li v-for="(bread, index) in breadcrums" :key="index" class="inline-flex items-end space-x-1">
                <Link :href="bread.to" class="text-xs font-medium" :class="{ 'font-normal': page.url === bread.to }">
                {{ bread.title }}</Link>
                <i v-if="index + 1 < breadcrums.length" class="fa-solid fa-chevron-right text-xs"></i>
            </li>
        </ul>
    </div>
</template>