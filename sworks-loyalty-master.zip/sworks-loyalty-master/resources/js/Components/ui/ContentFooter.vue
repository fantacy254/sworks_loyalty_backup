<script setup></script>
<template>
    <footer>
        <!--copy right section-->
        <div class="flex items-center justify-center p-3 bottom-0">
            <h2 class="text-xs text-slate-400">
                Copyright&nbsp;&#169;&nbsp; {{ new Date().getFullYear() }}
                <span class="text-slate-500">Smartworks Trading Co. Ltd</span>.
                All rights reserved.
            </h2>
        </div>
    </footer>
</template>
