<script setup>

defineOptions({
    name: "AppShell",
});
</script>
<template>
    <div
        class="flex items-start justify-start w-full select-none overflow-hidden no-scrollbar dark:bg-black/90 dark:text-slate-50 bg-gray-100 transition-all duration-300 ease-in-out"
    >
        <slot />
    </div>
</template>
