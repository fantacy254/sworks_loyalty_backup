<script setup>
import { usePage } from "@inertiajs/vue3";
import { computed } from "vue";
import { useLayoutManager } from "@/composable/layoutManager";

const page = usePage();
const { sidebarToggle } = useLayoutManager();

const title = computed(() => {
    return `${page.props?.auth?.company?.name ?? "Loyalty"} ~ ${page.props?.auth?.branch?.name ?? "branch"}`;
});
</script>
<template>
    <div
        class="md:h-12 h-16 border-b border-b-gray-100 dark:border-b-gray-500 backdrop-blur-xl bg-black/90 w-full grid md:grid-cols-2 px-4 md:px-2 sticky top-0 z-999"
    >
        <!--sidebar button-->
        <div class="flex items-center gap-2 md:pl-4 w-full">
            <button
                @click="sidebarToggle()"
                class="focus:outline-none text-2xl md:text-lg"
            >
                <i class="fas fa-bars"></i>
            </button>
            <h1
                class="text-sm text-center truncate text-ellipsis w-4/5 md:w-full flex text-nowrap font-semibold ml-1 md:ml-6"
            >
                {{ title }}
            </h1>
        </div>
    </div>
</template>
