<script setup>
import { useLayoutManager } from "@/composable/layoutManager";

const { isMobile, isMobileMenuOpen, closeMobileMenu, menuCollapsed } =
    useLayoutManager();
</script>
<template>
    <div
        :class="[
            isMobile && isMobileMenuOpen
                ? 'duration-500 absolute top-0 left-0 z-9999 w-3/4 border-r border-r-gray-100 dark:border-r-gray-500'
                : [
                      menuCollapsed
                          ? 'hidden md:block md:w-16 duration-300'
                          : 'hidden md:block md:w-72 duration-300',
                  ],
        ]"
        class="h-screen grid grid-cols-1 border-r border-r-gray-100 dark:border-r-gray-500 transition-all ease-in-out"
    >
        <slot />
        <button
            type="button"
            class="focus:outline-none text-3xl absolute top-4 -right-12 md:hidden"
            @click="closeMobileMenu()"
        >
            <i class="fas fa-times"></i>
        </button>
    </div>
</template>
