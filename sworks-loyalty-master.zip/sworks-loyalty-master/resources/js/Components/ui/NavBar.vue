<script setup>
import NavHeader from "@/Components/ui/NavHeader.vue";
import NavFooter from "@/Components/ui/NavFooter.vue";
</script>
<template>
    <div class="h-dvh bg-gray-100 dark:bg-black/80 dark:text-inherit">
        <NavHeader />
        <slot />
        <NavFooter />
    </div>
</template>
