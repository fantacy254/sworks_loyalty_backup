<script setup>
import { usePage } from "@inertiajs/vue3";
import { ref } from "vue";
import NavUser from "@/Components/NavUser.vue";
import { useLayoutManager } from "@/composable/layoutManager";

const page = usePage();
const { isMobileMenuOpen, menuCollapsed, showFooterNavUser } =
    useLayoutManager();

const footItems = [
    {
        name: "Profile",
        href: "/user/profile",
        icon: "fas fa-chalkboard-user",
        show: true,
    },
    {
        name: "Settings",
        href: "/settings",
        icon: "fas fa-gear",
        show: page.props.auth.company.id,
    },
    {
        name: "Sign Out",
        href: "/signout",
        icon: "fas fa-power-off",
        show: page.props.auth.user.multi_access,
    },
    {
        name: "Logout",
        href: "/logout",
        icon: "fas fa-sign-out-alt",
        show: true,
    },
];

const resetFooter = () => {
    isMobileMenuOpen.value = false;
    showFooter.value = false;
};
</script>
<template>
    <div
        class="rounded-t-lg border-t-2 border-gray-200 dark:border-gray-500 relative bottom-0 left-0 flex items-center justify-center z-10 ease-in-out transition-all duration-200 delay-150"
        style="height: 10%"
    >
        <button
            type="button"
            @click="showFooterNavUser = !showFooterNavUser"
            class="p-2 flex items-center justify-center"
        >
            <NavUser />
            <i
                class="fas fa-chevron-down text-xs ml-2"
                :class="{ 'rotate-180': showFooterNavUser }"
            ></i>
        </button>
        <div
            v-show="showFooterNavUser"
            class="bg-white dark:bg-black/70 absolute z-999 transition-all -top-1 font-normal space-y-2 translate-x-6 -translate-y-full rounded-lg shadow-md w-full p-2 border dark:border-gray-500"
        >
            <NavUser />
            <hr />
            <ul class="space-y-1">
                <li
                    v-show="itm.show"
                    v-for="(itm, index) in footItems"
                    :key="index"
                    class="p-1 border-b border-gray-200 dark:border-gray-500"
                >
                    <Link
                        @click="resetFooter()"
                        :href="itm.href"
                        class="text-xs font-medium"
                    >
                        <i :class="`${itm.icon} text-sm mr-1`"></i>
                        <span v-if="!menuCollapsed">{{ itm.name }}</span>
                    </Link>
                </li>
            </ul>
        </div>
    </div>
</template>
