<script setup>
import SmartCloud from "@/Components/SmartCloud.vue";
import { useLayoutManager } from "@/composable/layoutManager";

const { isMobile } = useLayoutManager();
</script>
<template>
    <div
        class="flex items-center justify-center p-2 border-b dark:border-b-gray-500"
        :class="[isMobile ? 'h-[10%]' : 'h-[15%]']"
    >
        <SmartCloud />
    </div>
</template>
