<script>
export default {
    inheritAttrs: true,
    props: {
        name: {
            type: String,
            required: true,
        },
        type: {
            type: String,
            required: true,
            default: 'button'
        },
        loading: {
            type: Boolean,
            default: false,
        },
        icon: {
            type: String,
            default: "",
        },
    },
};
</script>
<template>
    <button
        :type="type"
        :class="$attrs.class"
        :disabled="loading"
        class="text-nowrap cursor-pointer py-3 px-4 md:px-5 dark:bg-transparent font-medium bg-linear-to-tr text-xs shadow-md shadow-gray-400 dark:shadow-none text-white from-orange-400 via-orange-500 to-orange-400 rounded-xl hover:from-orange-500 hover:to-orange-600"
    >
        <i :class="icon"></i>
        <span class="mx-1">{{ name }}</span>
        <i v-show="loading" class="fa-solid fa-spinner animate-spin"></i>
    </button>
</template>
