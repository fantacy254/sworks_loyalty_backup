<script setup>
import { inject } from "vue";

const showModal = inject("showModal");

const openSearchModal = () => {
    showModal.value = true;
};
</script>
<template>
    <button type="button" @click="openSearchModal()" class="opacity-50">
        <i class="fa-brands fa-searchengin text-xl"></i>
    </button>
</template>
