<script setup>
    import { router, useForm } from '@inertiajs/vue3';
    import { ref } from 'vue';

    const props = defineProps({
        groups: Object
    })

    const form = useForm({
        name: ''
    })
    const editId = ref(null)

    const allowEdit = (id) => {
        if (!id) return

        const itm = props.groups.find((lc) => lc.id && id === lc.id)

        if (!itm) return

        editId.value = id
        form.name = itm.name
    }

    const resetFrom = () => {
        editId.value = null
        form.reset()
    }

    const btnHandler = () => {
        return editId.value ? updateGroup() : saveGroup()
    }

    const updateGroup = () => {
        form.patch(`/loyalty/masters/${editId.value}/group`, {
            onSuccess: () => {
                editId.value = null
                form.reset()
            }
        })
    }

    const saveGroup = () => {
        form.post('/loyalty/masters/group', {
            onSuccess: () => form.reset()
        })
    }

    function deletGroup(id) {
        if (confirm('Are you sure you want delete this record')) {
            router.delete(`/loyalty/masters/${id}/group`)
        }
    }

</script>
<template>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!--form-->
        <div class="border rounded-md shadow-sm">
            <!--header-->
            <button type="button" @click="resetFrom()"
                class="text-sm p-3 flex items-center justify-start font-normal hover:bg-gray-50 w-full rounded-2xl">
                <i class="fa-solid fa-plus"></i>&nbsp;
                Add group
            </button>
            <hr>
            <!--body-->
            <form @submit.prevent="btnHandler()" class="p-2 space-y-3">
                <TextInput v-model="form.name" type="text" label="Name" must />
                <PrimaryButton type="submit" :name="editId ? 'Save changes' : 'Save'" :loading="form.processing"
                    class="w-full" />
            </form>
        </div>
        <!--listing-->
        <div class="border rounded-md shadow-sm">
            <!--header-->
            <h1 class="text-md p-3 font-normal">
                <i class="fa-solid fa-people-group"></i>&nbsp;
                groups ({{ groups.length }})
            </h1>
            <hr>
            <div class="p-4 space-y-2">
                <div v-for="gp in groups" :key="gp.id"
                    class="flex items-center border border-gray-200 rounded-lg text-sm p-2">
                    <h1 class="flex-1">{{ gp.name }}</h1>
                    <div class="flex items-center gap-1">
                        <button type="button" class="rounded-md hover:shadow-sm cursor-pointer text-blue-600"
                            @click="allowEdit(gp.id)">
                            <i class="fa-regular fa-pen-to-square"></i>
                        </button>
                        <button type="button" class="rounded-md hover:shadow-sm cursor-pointer text-red-600"
                            @click="deletGroup(gp.id)">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>