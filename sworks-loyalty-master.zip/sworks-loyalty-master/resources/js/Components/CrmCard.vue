<script setup>

defineProps({
    count: String,
    template: String,
    cardClass: {
        type: String,
        default: 'primary'
    },
    value: String
})

const cardClasses = {
    'primary': 'bg-blue-50 border-blue-300 text-blue-900 dark:bg-inherit dark:border-blue-900 dark:text-blue-50',
    'secondary': 'bg-orange-50 border-orange-300 text-orange-900 dark:bg-inherit dark:border-orange-900 dark:text-orange-50',
    'ghost': 'bg-gray-50 border-gray-300 text-gray-900 dark:bg-inherit dark:border-gray-900 dark:text-gray-50'
}


</script>
<template>
    <div class="border relative rounded-xl p-3 shadow-md hover:scale-[1.03]" :class="cardClasses[cardClass]">
        <!--card value-->
        <h1 class="font-caveat font-bold text-2xl text-center ">{{ count }}</h1>
        <!--card name-->
        <p class="text-start text-xs text-gray-500 dark:text-gray-300 text-nowrap capitalize">
            {{ template }}
        </p>
        <!--value-->
        <h1 v-if="value" class="font-bold text-sm text-end text-black">Ksh.{{ value }}</h1>
        <!--card icon-->
        <i class="fa-regular fa-envelope absolute top-2 text-2xl text-blue-300 dark:text-blue-900"></i>
    </div>
</template>