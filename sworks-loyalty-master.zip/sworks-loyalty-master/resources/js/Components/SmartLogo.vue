<script></script>
<template>
    <div class="text-white">
        <div class="flex items-center justify-center">
            <img :src="`/storage/Images/logo_img.jpeg`" alt="smart-logo" />
        </div>
        <h1
            class="uppercase text-2xl leading-loose tracking-widest flex items-center justify-center"
        >
            smartworks
        </h1>
    </div>
</template>
