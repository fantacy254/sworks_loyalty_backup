<script>
export default {
    props: {
        name: {
            type: String,
            required: true,
        },
        type: {
            type: String,
            required: true,
            default: 'button'
        },
    },
};
</script>
<template>
    <button
        :type="type"
        class="shadow-md border-gray-300 text-black bg-gray-100 hover:bg-gray-400 border text-sm dark:text-slate-300 py-2.5 px-4 md:px-5 rounded-xl hover:border-gray-400 hover:text-white font-medium"
    >
        {{ name }}
    </button>
</template>
