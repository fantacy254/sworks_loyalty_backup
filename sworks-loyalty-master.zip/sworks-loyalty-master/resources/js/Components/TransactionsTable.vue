<script>
import { ref } from "vue";
import _ from "lodash";
import SearchInput from "@/Components/SearchInput.vue";

export default {
    inject: ["openPrintModal", "transType"],
    props: {
        data: {
            type: Array,
            required: true,
        },
        header: {
            type: Array,
            required: true,
        },
        loading: {
            type: Boolean,
            required: true,
        },
    },
    components: {
        SearchInput,
    },
    data() {
        return {
            entry: [
                { name: "5", value: 5 },
                { name: "15", value: 15 },
                { name: "25", value: 25 },
                { name: "50", value: 50 },
                { name: "100", value: 100 },
            ],
            search: ref(""),
            perPage: 15,
            currentPage: 1,
            sortKey: "",
            sortAsc: ref(true),
        };
    },
    computed: {
        filterTypeData() {
            if (this.transType === "all") {
                return this.data;
            } else {
                return this.data.filter((item) => {
                    return (
                        item.type &&
                        item.type.toString().includes(this.transType)
                    );
                });
            }
        },
        filteredData() {
            return this.filterTypeData.filter((item) => {
                return (
                    (item.name &&
                        item.name
                            .toLowerCase()
                            .indexOf(this.search.toLowerCase())) !== -1 ||
                    (item.accno &&
                        item.accno.toString().includes(this.search)) ||
                    (item.doc_no &&
                        item.doc_no.toString().includes(this.search))
                );
            });
        },
        sortedData() {
            if (this.sortKey) {
                return _.orderBy(
                    this.filteredData,
                    this.sortKey,
                    this.sortAsc ? "asc" : "desc",
                );
            }
            return this.filteredData;
        },
        paginatedData() {
            const start = (this.currentPage - 1) * this.perPage;
            const end = start + this.perPage;

            return this.sortedData.slice(start, end);
        },
        totalPages() {
            return Math.ceil(this.sortedData.length / this.perPage);
        },
        computedTotals() {
            return this.filterTypeData.reduce(
                (sum, row) => sum + (row.points || 0.0),
                0.0,
            );
        },
        numberFormat() {
            if (!this.computedTotals) return 0.0;

            //check whether value is a number
            const numberValue = parseFloat(this.computedTotals);
            if (isNaN(numberValue)) return this.computedTotals;

            return new Intl.NumberFormat("en-Us", {
                style: "decimal",
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
            }).format(numberValue);
        },
    },
    methods: {
        filterData() {
            this.currentPage = 1;
        },
        sortBy(key) {
            if (this.sortKey === key) {
                this.sortAsc = !this.sortAsc;
            } else {
                this.sortKey = key;
                this.sortAsc = true;
            }
        },
        changePage(page) {
            this.currentPage = page;
        },
        nextPage() {
            if (this.currentPage < this.totalPages) {
                this.currentPage++;
            }
        },
        prevPage() {
            if (this.currentPage > 1) {
                this.currentPage--;
            }
        },
    },
};
</script>
<template>
    <div class="px-0 py-0 space-y-2">
        <div class="flex items-center justify-between">
            <div class="space-x-2 text-xs md:text-sm flex items-center">
                <select-input v-model="perPage" id="entry">
                    <option
                        v-for="(list, index) in entry"
                        :key="index"
                        :value="list.value"
                        selected="10"
                    >
                        {{ list.name }}
                    </option>
                </select-input>
                <label for="entry" class="capitalize text-xs md:text-sm"
                    >Entries per page</label
                >
            </div>
            <div>
                <search-input v-model="search" />
            </div>
        </div>
        <div
            class="w-full overflow-auto max-h-96 scrollbar-thin md:rounded-lg rounded-sm shadow-lg shadow-blue-200 dark:shadow-slate-500"
        >
            <table class="table-auto w-full bg-white dark:bg-gray-800">
                <thead
                    class="bg-slate-300 dark:bg-gray-900 sticky top-0 text-xs md:text-sm dark:text-slate-300"
                >
                    <tr class="text-left text-xs md:text-sm">
                        <th
                            :disabled="head.sort"
                            @click="sortBy(head.sort_key)"
                            v-for="(head, index) in header"
                            :key="index"
                            class="px-2 py-3 text-nowrap font-normal border border-gray-400 dark:border-gray-600 text-xs md:text-sm"
                            :class="{ 'cursor-pointer': head.sort }"
                        >
                            {{ head.name }}
                            <i
                                v-if="head.sort"
                                class="fa-solid fa-sort md:ml-5 text-slate-400 text-xs md:text-sm"
                            ></i>
                        </th>
                    </tr>
                </thead>
                <tbody
                    class="text-sm text-slate-600 dark:text-slate-300 space-y-4"
                >
                    <tr v-if="paginatedData.length === 0 && !loading" class="">
                        <td
                            colspan="10"
                            class="p-14 text-xs md:text-sm text-center"
                        >
                            No Records found
                        </td>
                    </tr>
                    <tr
                        v-else-if="loading && paginatedData.length === 0"
                        class=""
                    >
                        <td
                            colspan="10"
                            class="p-14 text-xs md:text-sm text-center"
                        >
                            Loading...
                        </td>
                    </tr>
                    <tr
                        v-else-if="loading && paginatedData.length > 0"
                        class=""
                    >
                        <td
                            colspan="10"
                            class="p-14 text-xs md:text-sm text-center"
                        >
                            Loading...
                        </td>
                    </tr>
                    <tr
                        v-else
                        v-for="(item, index) in paginatedData"
                        :key="index"
                        class="hover:bg-cyan-200 hover:cursor-pointer text-xs md:text-sm even:bg-slate-100 dark:even:bg-gray-700 dark:hover:bg-gray-900"
                    >
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs"
                        >
                            {{ (currentPage - 1) * perPage + index + 1 }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs"
                        >
                            {{ item.doc_no }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs uppercase"
                        >
                            {{ item.type }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs"
                        >
                            {{ item.run_date }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs font-medium text-right"
                        >
                            {{ item.amount ? item.amount : 0 }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs font-semibold text-black dark:text-slate-200 text-right"
                        >
                            {{ item.points ? item.points : 0 }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs uppercase"
                        >
                            {{ item.accno }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs uppercase"
                        >
                            {{ item.name }}
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs uppercase"
                        >
                            <button
                                type="button"
                                v-if="item.type === 'RED'"
                                @click="openPrintModal(item.reference)"
                                class="text-blue-500"
                            >
                                {{ item.reference }}
                            </button>
                            <!--:href="`/voucher/print/${item.reference}`"-->
                            <span v-else>{{ item.reference }}</span>
                        </td>
                        <td
                            class="px-2 py-2 text-nowrap border border-gray-200 dark:border-gray-700 text-xs uppercase"
                        >
                            {{ item.branch }}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div
            v-if="paginatedData.length > 0 && !loading"
            class="flex items-center justify-between md:px-4 text-xs md:text-sm"
        >
            <div>
                <p>Showing {{ currentPage }} of {{ totalPages }} pages</p>
            </div>
            <div
                class="p-2 space-x-3 flex items-center justify-center text-xs md:text-sm"
            >
                <button
                    @click="firstPage"
                    :disabled="currentPage === 1"
                    class="hover:text-blue-600 text-xs md:text-sm"
                >
                    First
                </button>
                <button
                    @click="prevPage"
                    :disabled="currentPage === 1"
                    class="hover:text-blue-600 text-xs md:text-sm"
                >
                    <i class="fa-solid fa-angles-left text-xs md:text-sm"></i>
                </button>

                <span
                    v-if="currentPage > 2"
                    class="text-blue-600 font-semibold md:px-1"
                    >...</span
                >

                <button
                    v-if="currentPage > 1"
                    @click="changePage(currentPage - 1)"
                    class="text-blue-600"
                >
                    {{ currentPage - 1 }}
                </button>
                <button
                    class="md:text-lg text-xs text-white font-medium border rounded-full bg-blue-800 border-violet-500 p-1 shadow-lg shadow-violet-400"
                >
                    {{ currentPage }}
                </button>
                <button
                    v-if="currentPage < totalPages"
                    @click="changePage(currentPage + 1)"
                    class="text-blue-600"
                >
                    {{ currentPage + 1 }}
                </button>

                <span
                    v-if="currentPage < totalPages - 1"
                    class="text-blue-600 font-semibold md:px-1"
                    >...</span
                >

                <button
                    @click="nextPage"
                    :disabled="currentPage === totalPages"
                    class="hover:text-blue-600"
                >
                    <i class="fa-solid fa-angles-right"></i>
                </button>
                <button
                    @click="changePage(totalPages)"
                    :disabled="currentPage === totalPages"
                    class="hover:text-blue-600 text-xs md:text-sm"
                >
                    Last
                </button>
            </div>
        </div>
    </div>
    <hr />
    <!--totals section-->
    <div
        class="flex items-center justify-start space-x-12 mt-3 text-xs md:text-sm"
    >
        <div
            class="text-xs md:text-sm flex items-center justify-start space-x-1"
        >
            <p class="font-normal text-xs md:text-sm text-nowrap">
                Totals:
                <span v-if="!loading" class="font-semibold">{{
                    filterTypeData.length
                }}</span>
            </p>
        </div>
        <div class="text-nowrap flex-1">
            <text-input
                label="Point Value"
                v-model="numberFormat"
                type="text"
                id="tlAmt"
                class="w-28"
                disabled
            />
        </div>
    </div>
</template>
