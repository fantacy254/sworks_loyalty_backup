<script setup>
import { inject, ref, onMounted, onUnmounted } from "vue";
import axios from "axios";
import MyTransition from "@/Components/MyTransition.vue";
import JsBarcode from "jsbarcode";
import { usePage } from "@inertiajs/vue3";
import { computedDate, computedAmount } from "@/utlis/smartFun";

const page = usePage();

const showPrintModal = inject("showPrintModal");
const voucherDoc = inject("voucherDoc");
const printData = ref([]);
const printSection = ref(null);
const barcode = ref(null);

function printPage() {
    const printContents = printSection.value.innerHTML;

    // Create a hidden iframe
    const iframe = document.createElement("iframe");
    iframe.style.position = "absolute";
    iframe.style.width = "0";
    iframe.style.height = "0";
    iframe.style.border = "none";

    document.body.appendChild(iframe);

    const doc = iframe.contentWindow.document;
    doc.open();
    doc.write(`
        <html>
        <head>
        <title>Print</title>
        <style>
            /* Add any custom styles for printing here */
        </style>
        </head>
        <body>
        ${printContents}
        </body>
        </html>
    `);
    doc.close();

    // Trigger the print dialog
    iframe.contentWindow.focus();
    iframe.contentWindow.print();

    // Remove the iframe after printing
    iframe.contentWindow.onafterprint = () => {
        document.body.removeChild(iframe);
    };
}

function closePrintModal() {
    showPrintModal.value = false;
}

async function getVoucher() {
    await axios
        .get(`/voucher/print/${voucherDoc.value}`)
        .then((res) => {
            printData.value = res.data;
            generateCode(res.data[0].doc_no);
        })
        .catch((err) => {
            err.status === 406
                ? setTimeout(() => {
                      page.props.flash.info = err.response.data;
                  }, 1000)
                : (page.props.flash.error = err);
            showPrintModal.value = false;
        });
}

function generateCode(voucher) {
    if (printData.value[0]?.doc_no) {
        JsBarcode(barcode.value, printData.value[0].doc_no, {
            format: "CODE128",
            lineColor: "#000",
            height: 100,
            width: 4,
            displayValue: false,
        });
    }
}

onMounted(() => {
    getVoucher();
});

onUnmounted(() => {
    if (Array.isArray(printData.value)) {
        printData.value.splice(0, printData.value.length);
    }
});
</script>
<template>
    <Teleport to="body">
        <main
            v-show="showPrintModal"
            @click.self="closePrintModal()"
            class="absolute inset-0 z-9999 top-0 w-full min-h-screen bg-black/50 space-y-3 dark:text-slate-200"
        >
            <!--heade section-->
            <div
                @click.stop
                class="w-full bg-black/50 text-white flex items-center justify-end md:px-16 md:space-x-2 md:mr-10"
            >
                <button type="button" class="p-3 rounded-md">
                    <i class="fa-solid fa-download"></i>
                </button>
                <button type="button" @click="printPage" class="p-3 rounded-md">
                    <i class="fa-solid fa-print"></i>
                </button>
                <button
                    type="button"
                    @click="closePrintModal()"
                    class="p-3 rounded-md hover:text-white text-lg"
                >
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                </button>
            </div>
            <!--voucher section-->
            <section
                class="flex items-center justify-center px-5 md:px-0"
                @click.self="closePrintModal()"
            >
                <MyTransition>
                    <div
                        @click.stop
                        ref="printSection"
                        class="bg-white dark:bg-gray-800 rounded-md md:w-1/3 w-full shadow-lg text-xs md:text-sm md:px-2 py-3 space-y-2"
                    >
                        <!--header section-->
                        <div class="">
                            <h1
                                class="flex items-center text-xs md:text-sm justify-center font-medium"
                            >
                                {{ $page.props.auth.company.name }},({{
                                    $page.props.auth.branch.name
                                }})
                            </h1>
                            <p
                                class="flex items-center text-xs justify-center font-medium"
                            >
                                {{ $page.props.auth.company.address }}
                            </p>
                            <p
                                class="flex items-center justify-center font-medium text-xs"
                            >
                                {{ $page.props.auth.company.pin_no }}
                            </p>
                            <p
                                class="flex items-center justify-center font-medium text-xs"
                            >
                                {{ $page.props.auth.company.phone }}
                            </p>
                            <h1
                                class="text-xs md:text-sm flex items-center justify-center font-semibold p-1"
                            >
                                <span v-if="printData.length !== 0">{{
                                    printData[0].branch
                                }}</span>
                                <span v-else>Loading...</span>
                            </h1>
                        </div>
                        <div
                            class="flex items-center justify-center w-full h-12 p-0"
                        >
                            <svg ref="barcode" class="h-full w-full"></svg>
                        </div>
                        <hr />
                        <hr />
                        <h1
                            class="flex underline underline-offset-1 md:underline-offset-8 decoration-2 items-center justify-center font-bold text-sm md:text-lg p-2"
                        >
                            LOYALTY VOUCHER
                        </h1>
                        <div class="flex items-center justify-evenly px-2">
                            <p class="flex items-center justify-start w-full">
                                Date: &nbsp;<span
                                    v-if="printData.length !== 0"
                                    class="text-xs md:text-sm"
                                    >{{ computedDate(printData[0].date) }}</span
                                >
                                <span
                                    v-else
                                    class="animate-pulse text-xs md:text-sm"
                                    >Loading...</span
                                >
                            </p>
                            <p class="flex items-center justify-end w-full">
                                Issue_By: &nbsp;<span
                                    v-if="printData.length !== 0"
                                    class="text-xs md:text-sm"
                                    >{{ printData[0].input_by }}</span
                                >
                                <span
                                    v-else
                                    class="animate-pulse text-xs md:text-sm"
                                    >Loading...</span
                                >
                            </p>
                        </div>
                        <hr />
                        <p
                            class="flex items-center justify-center italic text-slate-400 text-xs md:text-sm"
                        >
                            Account details
                        </p>
                        <!--details section-->
                        <div class="p-1 py-1 space-y-2 px-2">
                            <div class="flex items-center justify-evenly">
                                <div class="flex items-center justify-start">
                                    A/C Name: &nbsp;
                                </div>
                                <div
                                    class="flex items-center justify-end flex-1"
                                >
                                    <span v-if="printData.length !== 0">{{
                                        printData[0].cust_accno
                                    }}</span>
                                    <span
                                        v-else
                                        class="animate-pulse text-xs md:text-sm"
                                        >Loading...</span
                                    >, &nbsp;
                                    <span
                                        v-if="printData.length !== 0"
                                        class="uppercase font-medium"
                                        >{{ printData[0].cust_name }}</span
                                    >
                                    <span
                                        v-else
                                        class="animate-pulse text-xs md:text-sm"
                                        >Loading...</span
                                    >
                                </div>
                            </div>
                            <div class="flex items-center justify-evenly">
                                <div class="flex items-center justify-start">
                                    Card No: &nbsp;
                                </div>
                                <div
                                    class="flex items-center justify-end flex-1"
                                >
                                    <span v-if="printData.length !== 0">{{
                                        printData[0].card
                                    }}</span>
                                    <span
                                        v-else
                                        class="animate-pulse text-xs md:text-sm"
                                        >Loading...</span
                                    >
                                </div>
                            </div>
                            <div class="flex items-center justify-evenly">
                                <div class="flex items-center justify-start">
                                    Voucher No: &nbsp;
                                </div>
                                <div
                                    class="flex items-center justify-center flex-1"
                                >
                                    <span
                                        v-if="printData.length !== 0"
                                        class="md:text-xl text-sm font-semibold flex items-center justify-center"
                                    >
                                        {{ printData[0].doc_no }}
                                    </span>
                                    <span
                                        v-else
                                        class="animate-pulse text-xs md:text-sm font-medium flex items-center justify-center"
                                        >Loading...</span
                                    >
                                </div>
                            </div>
                            <div class="flex items-center justify-evenly">
                                <div class="flex items-center justify-start">
                                    Amount: &nbsp;
                                </div>
                                <div
                                    class="flex items-center justify-end flex-1"
                                >
                                    <span
                                        v-if="printData.length !== 0"
                                        class="font-medium"
                                        >{{
                                            computedAmount(printData[0].amount)
                                        }}</span
                                    >
                                    <span
                                        v-else
                                        class="animate-pulse text-xs md:text-sm"
                                        >Loading...</span
                                    >
                                </div>
                            </div>
                            <div class="flex items-center justify-evenly">
                                <div class="flex items-center justify-start">
                                    Expiry: &nbsp;
                                </div>
                                <div
                                    class="flex items-center justify-end flex-1"
                                >
                                    <span v-if="printData.length !== 0">{{
                                        computedDate(printData[0].expiry)
                                    }}</span>
                                    <span
                                        v-else
                                        class="animate-pulse text-xs md:text-sm"
                                        >Loading...</span
                                    >
                                </div>
                            </div>
                        </div>
                        <hr />
                        <!--footer-->
                        <span class="md:p-3 p-1 text-slate-500 text-xs"
                            >Printed by: {{ $page.props.auth.user.name }}</span
                        >
                    </div>
                </MyTransition>
            </section>
        </main>
    </Teleport>
</template>
