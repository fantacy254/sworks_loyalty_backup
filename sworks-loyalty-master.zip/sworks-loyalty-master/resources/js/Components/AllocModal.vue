<script setup>
import MyTransition from "@/Components/MyTransition.vue";
import { usePage } from "@inertiajs/vue3";
import axios from "axios";
import { computed, inject, onBeforeMount, ref, watch } from "vue";
import { computedAmount } from "@/utlis/smartFun.js";

const page = usePage();

const updateLoans = inject("updateLoans");
const showModal = inject("showAllocModal");
const { agentsId, t_amt, receiptType } = inject("agents_id");
const header = [
    { name: "Date", db_name: "disbursement_date" },
    { name: "Referecne", db_name: "ref_no" },
    { name: "Amount", db_name: "amount" },
    { name: "Balance", db_name: "balance" },
];
const loans = ref([]);
const allocations = ref({});
const tlAlloc = ref(false);

const selectedloans = ref([]);

const getLoans = async () => {
    if (receiptType.value === "loans") {
        await axios
            .get("/loan/agent-loans", {
                params: {
                    agentId: agentsId.value,
                },
            })
            .then((res) => {
                loans.value = res.data;
            })
            .catch((th) => {
                page.props.flash.error = th.response.data;
            });
    } else {
        await axios
            .get("/float/agent-floats", {
                params: {
                    agentId: agentsId.value,
                },
            })
            .then((res) => {
                console.log("res", res.data);
                loans.value = res.data;
            })
            .catch((th) => {
                console.log("th", th.response.data);
                page.props.flash.error = th.response.data;
            });
    }
};

const closeAllocModal = () => {
    showModal.value = false;
};

const validateAllocation = (loanId, loanBal) => {
    if (allocations.value[loanId] > loanBal) {
        allocations.value[loanId] = loanBal;
    } else if (
        allocations.value[loanId] < loanBal &&
        totalAllocated.value > t_amt.value
    ) {
        //allocations.value[loanId] = balanceAllocated.value
        delete allocations.value[loanId];
    }
};

const saveAllocation = () => {
    if (totalAllocated.value > t_amt.value || balanceAllocated.value < 0) {
        tlAlloc.value = false;
        alert("Total allocated amount exceeds the total amount");
        return;
    }
    if (totalAllocated.value < t_amt.value) {
        tlAlloc.value = false;
        alert("You have to allocate all the amount");
        return;
    }

    const allocatedData = selectedloans.value.map((id) => ({
        loan_id: id,
        loan_date: loans.value.find((loan) => loan.id === id).disbursement_date,
        ref_no: loans.value.find((loan) => loan.id === id).ref_no,
        loan_amt: parseFloat(
            loans.value.find((loan) => loan.id === id).balance,
        ),
        allocated: parseFloat(allocations.value[id]),
        bal:
            parseFloat(loans.value.find((loan) => loan.id === id).balance) -
            parseFloat(allocations.value[id]),
    }));
    updateLoans(allocatedData);
    //console.log('loans', allocatedData)
    closeAllocModal();
};

const totalAllocated = computed(() => {
    return Object.values(allocations.value).reduce((sum, val) => {
        const num = parseFloat(val);
        return sum + (isNaN(num) ? 0 : num); // add only if it is a number
    }, 0);
});

const balanceAllocated = computed(() => {
    return t_amt.value - totalAllocated.value;
});

onBeforeMount(() => {
    getLoans();
});

watch(
    selectedloans,
    (newVal) => {
        Object.keys(allocations.value).forEach((loanId) => {
            if (!newVal.includes(Number(loanId))) {
                delete allocations.value[loanId];
            }
        });
    },
    { deep: true },
);

// watch(allocations, (newVal) => {
//       console.log('Allocations:', newVal)
//}, { deep: true })

watch(totalAllocated, (newVal) => {
    if (newVal > t_amt.value) {
        tlAlloc.value = true;
    } else {
        tlAlloc.value = false;
    }
});

watch(
    balanceAllocated,
    (newVal) => {
        if (newVal <= 0) {
            tlAlloc.value = true;
        } else {
            tlAlloc.value = false;
        }
    },
    { deep: true },
);
</script>
<template>
    <teleport to="body">
        <div
            v-show="showModal"
            @click.self="closeAllocModal"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex md:pt-8 md:items-start justify-center dark:text-slate-300 px-4 md:px-0"
        >
            <MyTransition>
                <div
                    class="bg-white dark:bg-gray-900 rounded-md h-fit mt-8 md:w-2/5 w-full"
                >
                    <div
                        class="w-full border-b-gray-300 border-b shadow-sm rounded-t-md bg-indigo-800/30 flex items-center justify-center"
                    >
                        <h1 class="font-medium text-sm text-slate-700 p-4">
                            Repayment allocation
                        </h1>
                    </div>
                    <!--table section-->
                    <div
                        class="pb-2 px-1 max-h-60 overflow-y-auto scrollbar-thin"
                    >
                        <table
                            class="table-auto w-full bg-white dark:bg-gray-800"
                        >
                            <thead
                                class="bg-slate-200 dark:bg-gray-900 text-xs sticky top-0"
                            >
                                <tr
                                    class="text-left border border-gray-300 space-x-1"
                                >
                                    <th
                                        scope="col"
                                        class="flex items-center justify-center space-y-1 text-xs px-0 py-3 w-auto font-normal border-r border-gray-300"
                                    >
                                        <input
                                            type="checkbox"
                                            name="all"
                                            id="all"
                                            class="cursor-pointer w-3 h-3 text-xs text-orange-400 bg-gray-100 border-gray-300 rounded-sm focus:ring-orange-500 dark:focus:ring-orange-600 dark:ring-offset-gray-800 focus:ring-1 dark:bg-gray-700 dark:border-gray-600 appearance-none accent-violet-400 shadow hover:shadow-md transition-all"
                                        />
                                    </th>
                                    <th
                                        scope="col"
                                        v-for="(head, colIndex) in header"
                                        :key="colIndex"
                                        class="px-2 py-3 w-auto text-nowrap font-normal border-r border-gray-300"
                                    >
                                        {{ head.name }}
                                    </th>
                                    <th
                                        scope="col"
                                        class="text-nowrap text-center px-2 py-3 w-auto font-normal"
                                    >
                                        Allocated
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr
                                    v-if="loans.length > 0"
                                    v-for="(item, rowIndex) in loans"
                                    :key="rowIndex"
                                    class="text-sm odd:bg-slate-50 hover:bg-slate-50 hover:cursor-pointer dark:odd:bg-gray-800 dark:hover:bg-gray-700"
                                >
                                    <td
                                        class="flex items-center justify-center space-y-1 text-xs px-0 py-2 w-auto font-norma"
                                    >
                                        <input
                                            type="checkbox"
                                            name="all"
                                            id="lnchk"
                                            :value="item.id"
                                            v-model="selectedloans"
                                            :disabled="tlAlloc"
                                            class="cursor-pointer text-xs w-3 h-3 text-orange-400 bg-gray-100 border-gray-300 rounded-sm focus:ring-orange-500 dark:focus:ring-orange-600 dark:ring-offset-gray-800 focus:ring-1 dark:bg-gray-700 dark:border-gray-600 appearance-none accent-violet-400 outline-orange-400 shadow hover:shadow-md transition-all"
                                        />
                                    </td>
                                    <td
                                        v-for="(head, colIndex) in header"
                                        :key="colIndex"
                                        class="px-2 py-1 border text-nowrap border-gray-100 dark:border-gray-700 text-xs uppercase"
                                    >
                                        <span
                                            v-if="
                                                head.db_name === 'amount' ||
                                                head.db_name === 'balance'
                                            "
                                        >
                                            {{
                                                computedAmount(
                                                    item[head.db_name],
                                                )
                                            }}
                                        </span>
                                        <span v-else>{{
                                            item[head.db_name]
                                        }}</span>
                                    </td>
                                    <td
                                        class="flex items-center justify-center text-right border border-gray-100 dark:border-gray-700 text-xs uppercase"
                                    >
                                        <input
                                            type="number"
                                            name="alloc"
                                            id="alloc"
                                            v-model="allocations[item.id]"
                                            min="0"
                                            :max="item.balance"
                                            @keydoen.enter="
                                                validateAllocation(
                                                    item.id,
                                                    item.balance,
                                                )
                                            "
                                            @input="
                                                validateAllocation(
                                                    item.id,
                                                    item.balance,
                                                )
                                            "
                                            class="w-20 bg-green-100 focus:outline-none focus:ring-0 font-medium flex-1 text-xs text-center rounded-md border-none focus:border-none"
                                            placeholder="0.00"
                                            :disabled="
                                                !selectedloans.includes(item.id)
                                            "
                                        />
                                    </td>
                                </tr>
                                <tr
                                    v-else
                                    class="text-sm odd:bg-slate-50 hover:bg-slate-50 hover:cursor-pointer dark:odd:bg-gray-800 dark:hover:bg-gray-700"
                                >
                                    <td
                                        colspan="6"
                                        class="text-center text-xs capitalize text-slate-400 py-10"
                                    >
                                        No {{ receiptType }} available
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!--total section-->
                    <div
                        class="flex items-center justify-between px-2 py-1 space-x-2 shadow-sm border-t border-gray-300"
                    >
                        <text-input
                            type="number"
                            label="Total amount"
                            class="text-xs capitalize"
                            disabled
                            placeholder="0.00"
                            v-model="t_amt"
                        />
                        <text-input
                            type="number"
                            label="Total allocated"
                            class="text-xs capitalize"
                            disabled
                            placeholder="0.00"
                            v-model="totalAllocated"
                        />
                        <text-input
                            type="number"
                            label="balance"
                            class="text-xs capitalize"
                            disabled
                            placeholder="0.00"
                            v-model="balanceAllocated"
                        />
                    </div>
                    <hr />
                    <!--save buttons-->
                    <!--Buttons section-->
                    <div
                        class="p-4 flex items-center justify-end md:space-x-3 space-x-2"
                    >
                        <primary-button
                            type="submit"
                            name="Allocate"
                            @click.prevent="saveAllocation()"
                        />
                        <secondary-button
                            type="reset"
                            name="Cancel"
                            @click="closeAllocModal()"
                        />
                    </div>
                </div>
            </MyTransition>
        </div>
    </teleport>
</template>
