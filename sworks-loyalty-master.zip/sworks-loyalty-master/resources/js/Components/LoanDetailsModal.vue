<script setup>
import MyTransition from "@/Components/MyTransition.vue";
import axios from "axios";
import { inject, onBeforeMount, onUnmounted, ref, watch } from "vue";
import {
    computedAmount,
    computedDate,
    computedTimeDate,
} from "@/utlis/smartFun.js";

const { showDetailsModal, loanId, req_type } = inject("loanDetailsModal");

const loanPayments = ref([]);
const headers = [
    "#",
    "Payment Date",
    "Ref No",
    "Paid Amount",
    "Allocated",
    "Payment Mode",
    "Our Ref",
    "Created At",
];
const paymentModes = ref([]);

const closePaymentsModal = () => {
    showDetailsModal.value = false;
};

const getPaymentModes = async () => {
    await axios
        .get("/types")
        .then((res) => {
            //console.log(res.data);
            paymentModes.value = res.data;
        })
        .catch((err) => {
            //console.log(err);
        });
};

const getLoanPayments = async () => {
    try {
        await axios
            .get("/pay/show", {
                params: {
                    loan_id: loanId.value,
                    req_type: req_type.value,
                },
            })
            .then((res) => {
                if (req_type.value === "loans") {
                    loanPayments.value.push({
                        date: computedDate(res.data.disbursement_date),
                        ref_no: res.data.ref_no.toUpperCase(),
                        amount: computedAmount(res.data.amount),
                        balance: computedAmount(res.data.balance),
                        created_at: computedTimeDate(res.data.created_at),
                        details: res.data.repayments.map((repayment) => ({
                            payment_date: repayment.payment_date,
                            ref_no: repayment.ref_no,
                            amount: repayment.amount,
                            allocated: repayment.pivot.amount,
                            mode:
                                paymentModes.value.find(
                                    (mode) => mode.id === repayment.pay_type_id,
                                )?.long_desc || "Unknown",
                            our_ref: repayment.ref,
                            created_at: repayment.created_at,
                        })),
                    });
                } else if (req_type.value === "floats") {
                    loanPayments.value.push({
                        date: computedDate(res.data.issue_date),
                        ref_no: res.data.ref_no.toUpperCase(),
                        amount: computedAmount(res.data.amount),
                        balance: computedAmount(res.data.balance),
                        created_at: computedTimeDate(res.data.created_at),
                        details: res.data.receipts.map((receipts) => ({
                            payment_date: receipts.receipt_date,
                            ref_no: receipts.ref_no,
                            amount: receipts.amount,
                            allocated: receipts.pivot.amount,
                            mode:
                                paymentModes.value.find(
                                    (mode) => mode.id === receipts.pay_type_id,
                                )?.long_desc || "Unknown",
                            our_ref: receipts.ref,
                            created_at: receipts.created_at,
                        })),
                    });
                }
                console.log("computed Loans", loanPayments.value);
            })
            .catch((err) => {
                //console.log(err);
            });
    } catch (error) {
        //console.log(error);
    }
};

onBeforeMount(async () => {
    await getPaymentModes();

    if (paymentModes.value.length > 0) {
        await getLoanPayments();
    } else {
        console.error("Payment modes not loaded. Cannot fetch loan payments.");
    }
});

onUnmounted(() => {
    getPaymentModes();
    getLoanPayments();
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showDetailsModal"
            @click.self="closePaymentsModal"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex md:pt-8 md:items-start justify-center dark:text-slate-300 px-4 md:px-0"
        >
            <MyTransition>
                <div
                    class="bg-white dark:bg-gray-900 rounded-md h-fit mt-8 md:w-4/6 w-full"
                >
                    <div
                        class="w-full border-b-gray-300 border-b shadow-sm rounded-t-md bg-indigo-800/30 flex items-center justify-center"
                    >
                        <h1
                            class="font-medium text-sm text-slate-700 p-4 capitalize"
                        >
                            {{ req_type }} payments details
                        </h1>
                    </div>
                    <!--table section-->
                    <div
                        class="w-full overflow-auto px-1 min-h-60 bg-white max-h-96 scrollbar-thin md:rounded-lg rounded-sm"
                    >
                        <table
                            class="table-auto w-full bg-white dark:bg-gray-800 md:rounded-lg rounded-sm"
                        >
                            <thead
                                class="bg-slate-200 dark:bg-gray-900 font-light text-xs sticky top-0"
                            >
                                <tr class="text-left text-xs">
                                    <th
                                        v-for="(head, index) in headers"
                                        :key="index"
                                        class="px-2 py-3 text-xs text-nowrap font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ head }}
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="text-xs">
                                <tr
                                    v-if="loanPayments.length > 0"
                                    v-for="(item, index) in loanPayments[0]
                                        .details"
                                    :key="index"
                                    class="text-xs border-b border-gray-100 dark:border-gray-700 odd:bg-violet-50"
                                >
                                    <td
                                        class="px-1 py-2 text-nowrap text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ index + 1 }}
                                    </td>
                                    <td
                                        class="px-1 py-2 text-nowrap text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ computedDate(item.payment_date) }}
                                    </td>
                                    <td
                                        class="px-1 py-2 text-nowrap uppercase text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ item.ref_no }}
                                    </td>
                                    <td
                                        class="px-1 py-2 text-nowrap text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ computedAmount(item.amount) }}
                                    </td>
                                    <td
                                        class="px-1 py-2 text-nowrap text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ computedAmount(item.allocated) }}
                                    </td>
                                    <td
                                        class="px-1 py-2 text-nowrap text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ item.mode }}
                                    </td>
                                    <td
                                        class="px-1 py-2 text-nowrap text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ item.our_ref }}
                                    </td>
                                    <td
                                        class="px-1 py-2 text-nowrap text-xs font-normal border border-gray-100 dark:border-gray-700"
                                    >
                                        {{ computedTimeDate(item.created_at) }}
                                    </td>
                                </tr>
                                <tr v-else>
                                    <td
                                        colspan="8"
                                        class="p-14 text-center text-slate-500 dark:text-gray-300 animate-pulse"
                                    >
                                        Loading {{ req_type }} details ...
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr />
                    <p class="px-2 text-xs text-slate-400 capitalize">
                        {{ req_type }} Details
                    </p>
                    <div
                        v-if="loanPayments.length > 0"
                        class="text-xs flex justify-between p-2 space-x-1"
                    >
                        <text-input
                            v-model="loanPayments[0].date"
                            label="Date"
                            disabled
                        />
                        <text-input
                            v-model="loanPayments[0].ref_no"
                            label="Ref No"
                            disabled
                        />
                        <text-input
                            v-model="loanPayments[0].amount"
                            label="Amount"
                            disabled
                        />
                        <text-input
                            v-model="loanPayments[0].balance"
                            label="Balance"
                            disabled
                        />
                        <text-input
                            v-model="loanPayments[0].created_at"
                            label="Created At"
                            disabled
                        />
                    </div>
                    <hr />
                    <!--Buttons section-->
                    <div class="p-2 text-xs flex items-center justify-end">
                        <secondary-button
                            type="reset"
                            name="Cancel"
                            @click="closePaymentsModal()"
                        />
                    </div>
                </div>
            </MyTransition>
        </div>
    </teleport>
</template>
