<script setup>
import { ref } from "vue";

defineProps({
    message: String,
    variant: {
        type: String,
        default: "default",
    },
});

const variantClass = {
    default: "text-gray-600 bg-white border-gray-300",
    primary: "text-green-900 bg-green-50 border-green-300",
};

const show = ref(true);
const closeAlert = () => {
    show.value = false;
};
</script>
<template>
    <div
        v-if="show && message"
        :class="variantClass[variant]"
        class="rounded-lg border mt-2 w-full p-5 flex items-center"
    >
        <p class="leading-loose text-sm flex-1">{{ message }}</p>
        <button type="button" @click="closeAlert()">
            <i class="fa-regular fa-circle-xmark"></i>
        </button>
    </div>
</template>
