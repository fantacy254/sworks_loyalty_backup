<script setup>
import { inject, onMounted, ref, computed } from "vue";
import MyTransition from "@/Components/MyTransition.vue";
import { usePage } from "@inertiajs/vue3";
import {
    computedAmount,
    computedDate,
    computedTimeDate,
} from "@/utlis/smartFun";
import SharedTable from "@/Components/SharedTable.vue";

//page
const page = usePage();

const { showTotals, showModal, led, modalPrams } = inject("showModal");

const transTypeName = ref("Loading...");
const transDate = ref("Loading...");
const transAccNo = ref("Loading...");
const transAccName = ref("Loading...");
const transPostAt = ref("Loading...");
const transPostBy = ref("Loading...");
const transDocNo = modalPrams.value.docNo;

const getTrans = async () => {
    await axios
        .get(`/${led}/trans/show`, {
            params: {
                doc_no: modalPrams.value.docNo,
                type: modalPrams.value.type,
                branch: modalPrams.value.branch,
            },
        })
        .then((res) => {
            transTypeName.value = res.data[0].type ?? led;
            transDate.value = computedDate(res.data[0].date);
            transAccNo.value = res.data[0].accno ?? res.data[0].acc_no;
            transAccName.value = res.data[0].name ?? res.data[0].supplier_name;
            transPostAt.value = computedTimeDate(res.data[0].created_at);
            transPostBy.value = res.data[0].input_by;
        })
        .catch((err) => {
            console.log(err);
            page.props.flash.error = err;
        });
};

const headers = ref([]);

const transData = ref([]);
const message = ref("No records found");

const getTransDtls = async () => {
    message.value = "Loading...";
    await axios
        .get(`/${led}/trans/show/details`, {
            params: {
                doc_no: modalPrams.value.docNo,
                type: modalPrams.value.type,
                branch: modalPrams.value.branch,
            },
        })
        .then((res) => {
            //console.log(res)

            if (res.data.length === 0) {
                message.value = "No records found";
                page.props.flash.info =
                    "No details found for this transaction.";
                return;
            }

            headers.value = Object.keys(res.data[0])
                .filter(
                    (key) =>
                        key !== "br_code" &&
                        key !== "det_no" &&
                        key !== "no" &&
                        key !== "lineno" &&
                        key !== "lngoods" &&
                        key !== "lnvat",
                )
                .map((key) => ({
                    dbName: key,
                    name: key
                        .split("_")
                        .map(
                            (word) =>
                                word.charAt(0).toLocaleUpperCase() +
                                word.slice(1),
                        )
                        .join(" "),
                }));

            transData.value = res.data;
        })
        .catch((err) => {
            console.log(err);
            page.props.flash.error = err;
        });
};

const tlQty = computed(() => {
    return computedAmount(
        transData.value
            .reduce((acc, item) => {
                let qty = item.qty;
                let apprvQty = item.apprv;
                if (
                    qty !== undefined &&
                    qty !== null &&
                    !isNaN(parseFloat(qty))
                ) {
                    return acc + parseFloat(qty);
                } else if (
                    apprvQty !== undefined &&
                    apprvQty !== null &&
                    !isNaN(parseFloat(apprvQty))
                ) {
                    return acc + parseFloat(apprvQty);
                } else {
                    return acc;
                }
            }, 0)
            .toFixed(2),
    );
});

const tlGoods = computed(() => {
    return computedAmount(
        transData.value
            .reduce((acc, item) => acc + parseFloat(item.lngoods), 0)
            .toFixed(2),
    );
});
const tlVat = computed(() => {
    return computedAmount(
        transData.value
            .reduce((acc, item) => acc + parseFloat(item.lnvat), 0)
            .toFixed(2),
    );
});
const tlTotal = computed(() => {
    return computedAmount(
        transData.value
            .reduce((acc, item) => acc + parseFloat(item.lntotal), 0)
            .toFixed(2),
    );
});

const closeDtlsModal = () => {
    showModal.value = false;
};

onMounted(() => {
    getTrans();
    getTransDtls();
});
</script>
<template>
    <teleport to="body">
        <div
            v-show="showModal"
            @click.self="closeDtlsModal()"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex md:pt-4 md:items-start justify-center dark:text-slate-300 px-4 md:px-0"
        >
            <MyTransition>
                <div
                    class="bg-white dark:bg-gray-900 rounded-md h-fit md:w-4/6 w-full md:min-h-96 shadow-xl"
                >
                    <!--header section-->
                    <div
                        class="w-full border-b-gray-300 border-b shadow-sm rounded-t-md bg-slate-300 flex items-center justify-center"
                    >
                        <h1
                            class="font-semibold text-lg text-slate-500 p-2 capitalize flex"
                        >
                            {{ transTypeName }} Listing details
                        </h1>
                    </div>
                    <!--summary section-->
                    <div class="flex items-center justify-center p-1 w-full">
                        <div
                            class="flex flex-1 items-center justify-evenly space-x-2 px-2 py-1 w-full"
                        >
                            <text-input
                                type="text"
                                id="docNo"
                                class="w-24 md:w-60"
                                v-model="transDocNo"
                                label="Doc No."
                                disabled
                            />
                            <text-input
                                type="text"
                                id="date"
                                class="w-24 md:w-56"
                                v-model="transDate"
                                label="Trans Date"
                                disabled
                            />
                            <text-input
                                type="text"
                                id="accNo"
                                class="w-24 md:w-48"
                                v-model="transAccNo"
                                label="A/c No."
                                disabled
                            />
                            <text-input
                                type="text"
                                id="accName"
                                class="w-24 md:w-full"
                                v-model="transAccName"
                                label="A/c Name"
                                disabled
                            />
                            <text-input
                                type="text"
                                id="postAt"
                                class="w-24 md:w-96"
                                v-model="transPostAt"
                                label="Post At"
                                disabled
                            />
                            <text-input
                                type="text"
                                id="postBy"
                                class="w-24 md:w-60"
                                v-model="transPostBy"
                                label="Post By"
                                disabled
                            />
                        </div>
                    </div>
                    <hr />
                    <!--table section-->
                    <main v-if="transData.length > 0" class="p-2">
                        <div
                            class="w-full overflow-y-auto min-h-64 max-h-64 md:text-xs scrollbar-thin md:rounded-lg rounded-sm"
                        >
                            <table
                                class="table-auto bg-white dark:bg-gray-800 md:rounded-lg rounded-sm w-full md:text-xs"
                            >
                                <thead
                                    class="backdrop-blur-sm shadow-md font-normal dark:bg-gray-900 md:text-xs text-xs sticky top-0 bg-white"
                                >
                                    <tr class="text-left">
                                        <th
                                            class="px-2 py-3.5 text-nowrap border-b border-gray-400 dark:border-gray-700"
                                        >
                                            #
                                        </th>
                                        <th
                                            v-for="(head, index) in headers"
                                            :key="index"
                                            :class="{
                                                'text-wrap':
                                                    head.dbName ===
                                                        'cvalexcl' ||
                                                    head.dbName === 'cvalinc' ||
                                                    head.dbName ===
                                                        'svalexcl' ||
                                                    head.dbName === 'svalinc',
                                            }"
                                            class="px-2 py-3.5 text-nowrap font-normal capitalize border-b border-gray-400 dark:border-gray-700"
                                        >
                                            <span v-if="head.dbName === 'price'"
                                                >@</span
                                            >{{ head.name }}
                                            <span v-if="head.dbName === 'disc'"
                                                >%</span
                                            >
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="text-xs md:text-xs min-h-full">
                                    <tr
                                        v-if="transData.length > 0"
                                        v-for="(item, rowIndex) in transData"
                                        :key="rowIndex"
                                        class="hover:bg-cyan-200 md:text-xs odd:bg-violet-50 dark:odd:bg-gray-500 bg-white dark:bg-gray-400 font-normal hover:cursor-default text-xs mx-2 dark:hover:bg-gray-700"
                                        :class="{
                                            'bg-red-600 text-red-500 font-semibold':
                                                item.cancelled === 1 ||
                                                (item.warranty === 1 &&
                                                    item.warranty_exp_date &&
                                                    new Date(
                                                        item.warranty_exp_date,
                                                    ) < new Date()),
                                        }"
                                    >
                                        <td
                                            class="px-2 py-2 border-b text-nowrap text-xs md:text-xs hover:cursor-pointer border-gray-200 dark:border-gray-700 capitalize"
                                        >
                                            {{ rowIndex + 1 }}
                                        </td>
                                        <td
                                            v-for="(
                                                header, colIndex
                                            ) in headers"
                                            :key="colIndex"
                                            :class="{
                                                'bg-orange-200 border font-medium text-center':
                                                    header.name ===
                                                        'in stock' ||
                                                    header.dbName === 'qtyin' ||
                                                    header.dbName ===
                                                        'qtyout' ||
                                                    header.dbName ===
                                                        'abalstock' ||
                                                    header.dbName === 'bal' ||
                                                    header.dbName ===
                                                        'cvalexcl' ||
                                                    header.dbName ===
                                                        'cvalincl' ||
                                                    header.dbName === 'qty' ||
                                                    header.dbName ===
                                                        'unitcostgv' ||
                                                    header.dbName === 'tqty' ||
                                                    header.dbName ===
                                                        'tlngoods' ||
                                                    header.dbName ===
                                                        'issue_no' ||
                                                    header.dbName ===
                                                        'total_incl' ||
                                                    header.dbName ===
                                                        'total_excl' ||
                                                    header.dbName ===
                                                        'allocated' ||
                                                    header.dbName ===
                                                        'amount' ||
                                                    header.dbName === 'pay_amt',
                                                'bg-green-300 border font-medium':
                                                    header.name ===
                                                        'selling price' ||
                                                    header.dbName ===
                                                        'svalexcl' ||
                                                    header.dbName ===
                                                        'svalincl' ||
                                                    header.dbName ===
                                                        'lngross' ||
                                                    header.dbName ===
                                                        'tlntotal' ||
                                                    header.dbName ===
                                                        'balance' ||
                                                    header.dbName ===
                                                        'receipt_amt',
                                                'bg-yellow-300 border font-medium':
                                                    header.dbName ===
                                                        'margin' ||
                                                    header.dbName ===
                                                        'markup' ||
                                                    header.dbName === 'disc',
                                                'select-all':
                                                    header.dbName ===
                                                        'stockcode' ||
                                                    header.dbName === 'doc_no',
                                                'bg-red-500':
                                                    header.dbName ===
                                                    'cancelled',
                                                'bg-cyan-400':
                                                    header.dbName ===
                                                    'total_disc',
                                            }"
                                            class="px-2 py-2 border-b text-nowrap text-xs hover:cursor-pointer border-gray-200 dark:border-gray-700 capitalize"
                                        >
                                            <span
                                                class="text-xs flex items-center justify-end"
                                                v-if="
                                                    header.dbName ===
                                                        'amount' ||
                                                    header.dbName ===
                                                        'balance' ||
                                                    header.dbName ===
                                                        'abalstock' ||
                                                    header.dbName ===
                                                        'unitcostgv' ||
                                                    header.dbName ===
                                                        'unitcostg' ||
                                                    header.dbName ===
                                                        'sprice1' ||
                                                    header.dbName ===
                                                        'sprice2' ||
                                                    header.dbName ===
                                                        'svalexcl' ||
                                                    header.dbName ===
                                                        'svalincl' ||
                                                    header.dbName ===
                                                        'cvalexcl' ||
                                                    header.dbName ===
                                                        'cvalincl' ||
                                                    header.dbName ===
                                                        'markup' ||
                                                    header.dbName ===
                                                        'packing' ||
                                                    header.dbName ===
                                                        'margin' ||
                                                    header.dbName === 'qty' ||
                                                    header.dbName === 'qtyin' ||
                                                    header.dbName ===
                                                        'qtyout' ||
                                                    header.dbName ===
                                                        'lngross' ||
                                                    header.dbName ===
                                                        'lngoods' ||
                                                    header.dbName === 'lnvat' ||
                                                    header.dbName ===
                                                        'lntotal' ||
                                                    header.dbName === 'tqty' ||
                                                    header.dbName ===
                                                        'grn_qty' ||
                                                    header.dbName ===
                                                        'tlngoods' ||
                                                    header.dbName ===
                                                        'tlnvat' ||
                                                    header.dbName ===
                                                        'tlntotal' ||
                                                    header.dbName ===
                                                        'lntotal' ||
                                                    header.dbName ===
                                                        'ordered' ||
                                                    header.dbName ===
                                                        'total_issue' ||
                                                    header.dbName === 'apprv' ||
                                                    header.dbName ===
                                                        'lpo_qty' ||
                                                    header.dbName === 'packs' ||
                                                    header.dbName ===
                                                        'qty_apprv' ||
                                                    header.dbName === 'rjctd' ||
                                                    header.dbName ===
                                                        'tqty_issue' ||
                                                    header.dbName ===
                                                        'total_incl' ||
                                                    header.dbName ===
                                                        'total_excl' ||
                                                    header.dbName ===
                                                        'total_vat' ||
                                                    header.dbName === 'price' ||
                                                    header.dbName ===
                                                        'listprice' ||
                                                    header.dbName ===
                                                        'allocated' ||
                                                    header.dbName ===
                                                        'credit' ||
                                                    header.dbName === 'debit' ||
                                                    header.dbName === 'paid' ||
                                                    header.dbName === 'disc' ||
                                                    header.dbName ===
                                                        'total_disc' ||
                                                    header.dbName ===
                                                        'pay_amt' ||
                                                    header.dbName ===
                                                        'receipt_amt' ||
                                                    header.dbName ===
                                                        'old_cost' ||
                                                    header.dbName ===
                                                        'old_price' ||
                                                    header.dbName ===
                                                        'old_mrg' ||
                                                    header.dbName ===
                                                        'new_price' ||
                                                    header.dbName ===
                                                        'promo_qty' ||
                                                    header.dbName ===
                                                        'total_sale' ||
                                                    header.dbName ===
                                                        'compesation'
                                                "
                                            >
                                                {{
                                                    computedAmount(
                                                        item[header.dbName],
                                                    )
                                                }}
                                            </span>
                                            <span
                                                v-else-if="
                                                    header.dbName === 'date' ||
                                                    header.dbName ===
                                                        'warranty_exp_date' ||
                                                    header.dbName ===
                                                        'start_date' ||
                                                    header.dbName ===
                                                        'end_date' ||
                                                    header.dbName ===
                                                        'run_date' ||
                                                    header.dbName ===
                                                        'expiry' ||
                                                    header.dbName ===
                                                        'date_used' ||
                                                    header.dbName ===
                                                        'validity' ||
                                                    header.dbName ===
                                                        'grn_date' ||
                                                    header.dbName ===
                                                        'issue_date' ||
                                                    header.dbName ===
                                                        'due_date' ||
                                                    header.dbName ===
                                                        'date_paid'
                                                "
                                                class="text-xs md:text-xs flex items-center justify-start"
                                            >
                                                {{
                                                    computedDate(
                                                        item[header.dbName],
                                                    )
                                                }}
                                            </span>
                                            <span
                                                v-else-if="
                                                    header.dbName ===
                                                        'created_at' ||
                                                    header.dbName ===
                                                        'updated_at'
                                                "
                                                class="text-xs"
                                            >
                                                {{
                                                    computedTimeDate(
                                                        item[header.dbName],
                                                    )
                                                }}
                                            </span>
                                            <span
                                                v-else-if="
                                                    header.dbName ===
                                                        'supplied' ||
                                                    header.dbName ===
                                                        'approved' ||
                                                    header.dbName ===
                                                        'posted' ||
                                                    header.dbName ===
                                                        'cancelled' ||
                                                    header.dbName === 'sent' ||
                                                    header.dbName === 'used' ||
                                                    header.dbName === 'auto' ||
                                                    header.dbName ===
                                                        'issued' ||
                                                    header.dbName === 'warranty'
                                                "
                                                class="text-center flex items-center justify-center"
                                            >
                                                <input
                                                    type="checkbox"
                                                    :name="header.name"
                                                    :id="header.name"
                                                    :checked="
                                                        item[header.dbName]
                                                    "
                                                    :class="[
                                                        header.dbName ===
                                                        'approved'
                                                            ? 'text-green-500 font-medium'
                                                            : 'text-orange-500 dark:text-orange-500',
                                                    ]"
                                                    class="w-3.5 h-3.5 text-center bg-gray-100 border-gray-300 rounded-sm focus:ring-blue-500 focus:ring-2 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-blue-500 dark:focus:ring-2"
                                                    disabled
                                                />
                                            </span>
                                            <span
                                                v-else-if="
                                                    header.dbName === 'status'
                                                "
                                                class="rounded-lg text-xs p-1 font-medium italic text-center"
                                                :class="[
                                                    item[header.dbName] === 0
                                                        ? 'bg-green-200 text-green-800 border border-green-400'
                                                        : 'bg-red-300 text-red-700 border border-red-400',
                                                ]"
                                            >
                                                {{
                                                    item[header.dbName] === 0
                                                        ? "Valid"
                                                        : "Invalid"
                                                }}
                                            </span>
                                            <Link
                                                v-else-if="
                                                    header.name === 'Reference'
                                                "
                                                :href="
                                                    route(
                                                        'trans.listing.details',
                                                        {
                                                            led: ledger,
                                                            doc_no: encryptParams(
                                                                item.doc_no,
                                                            ),
                                                            type: encryptParams(
                                                                item.ftype,
                                                            ),
                                                            branch: encryptParams(
                                                                item.br_code,
                                                            ),
                                                        },
                                                    )
                                                "
                                                class="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-500 text-xs"
                                            >
                                                {{ item[header.dbName] }}
                                            </Link>
                                            <span class="text-xs" v-else>{{
                                                item[header.dbName]
                                            }}</span>
                                        </td>
                                    </tr>
                                    <tr v-else>
                                        <td
                                            :colspan="headers.length + 1"
                                            class="p-14 text-center text-slate-500 dark:text-gray-300"
                                        >
                                            {{ message }}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <hr />
                        <div
                            class="p-2 md:mx-4 mx-auto w-full md:w-auto flex md:items-center md:justify-start space-x-1 md:space-x-4"
                        >
                            <div
                                class="flex flex-1 items-center justify-start space-x-10"
                            >
                                <h1 class="font-semibold w-auto">Totals:</h1>
                                <h1>
                                    <span class="text-slate-400 text-xs"
                                        >Records:&nbsp;&nbsp;</span
                                    >{{ transData.length }}
                                </h1>
                            </div>
                            <div
                                v-if="showTotals"
                                class="flex flex-1 items-center justify-start space-x-2"
                            >
                                <text-input
                                    type="text"
                                    id="tlQty"
                                    class="w-24 md:w-32"
                                    v-model="tlQty"
                                    label="T. Qty"
                                    disabled
                                />
                                <text-input
                                    type="text"
                                    id="tlGoods"
                                    class="w-24 md:w-32"
                                    label="Goods Value"
                                    v-model="tlGoods"
                                    disabled
                                />
                                <text-input
                                    type="text"
                                    id="tlVat"
                                    class="w-24 md:w-32"
                                    label="T. VAT"
                                    v-model="tlVat"
                                    disabled
                                />
                                <text-input
                                    type="text"
                                    id="tlTotal"
                                    class="w-24 md:w-32"
                                    label="T. Value"
                                    v-model="tlTotal"
                                    disabled
                                />
                            </div>
                        </div>
                    </main>
                    <!--No records section-->
                    <main
                        v-else
                        class="flex items-center justify-center w-full min-h-48"
                    >
                        <h1
                            class="text-slate-600 font-semibold font-mono animate-pulse"
                        >
                            {{ message }}
                        </h1>
                    </main>
                </div>
            </MyTransition>
        </div>
    </teleport>
</template>
