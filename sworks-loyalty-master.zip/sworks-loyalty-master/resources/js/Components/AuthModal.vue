<script setup>
import MyTransition from './MyTransition.vue';
import { useAuthManager } from '@/composable/authManager';
import CodeInput from './CodeInput.vue';
import { computed, onMounted, provide, ref, watch } from 'vue';
import { usePage } from '@inertiajs/vue3';

const page = usePage()
const auth = useAuthManager()

const admin = ref([])
const defaultCount = 2 * 60;
const maxCount = ref(defaultCount);
const message = ref('There are no admin records associated with this account. Kindly contact system administrator for assistance.')
const sent = ref(false)

const getAdmin = async () => {
    await axios.get('/user/sys-admin')
        .then((res) => {
            admin.value = res.data
        })
        .catch((e) => {
            console.log(e.message)
            page.props.flash.error = e.message
        })
}

const formatCount = (seconds) => {
    seconds = Math.max(0, Number(seconds) || 0);

    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    return `${minutes}min ${remainingSeconds}sec`;
};

async function requestAuth() {
    const res = await axios.post('/trans/auth/reqcode', {
        transType: auth.trans
    }).catch((e) => {
        sent.value = false
        message.value = e.response?.data?.msg
        page.props.flash.error = e.response?.data?.msg
    })

    if (res?.data?.cd !== 0) {
        page.props.flash.error = res.data?.msg
    }

    sent.value = true
    page.props.flash.success = res.data.mg
    startResendTimer()
}

function startResendTimer() {
    maxCount.value = defaultCount;
    const interval = setInterval(() => {
        maxCount.value--
        if (maxCount.value === 0) clearInterval(interval)
    }, 1000);
}


provide('auth-code', {
    submit: () => auth.authenticate(),
})

watch(() => auth.errMsg, () => {
    setTimeout(() => {
        auth.errMsg = ''
    }, 3000);
})

onMounted(() => {
    requestAuth()
    getAdmin()
})

</script>
<template>
    <teleport to="body">
        <div v-show="auth.showAuth" @click.self="auth.closeAuthModal()" @keydown.ESC="auth.closeAuthModal()"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex items-center justify-center dark:text-slate-300 px-4 md:px-0">
            <MyTransition>
                <div class="bg-white rounded-md border mx-auto md:max-w-lg w-full p-4 space-y-1">
                    <h1 class="text-center text-3xl font-semibold p-2">
                        Authentication
                    </h1>
                    <hr>
                    <p class="text-sm">This operations requires authentication.</p>
                    <p v-if="Object.keys(admin).length > 0" class="text-sm">An authentication code will be sent to
                        the
                        admin on {{ admin.masked_phone }}</p>
                    <div v-if="sent">
                        <div class="max-w-sm mx-auto">
                            <code-input />
                        </div>
                        <div class="text-sm">
                            Didn't receive code?
                            <button v-if="maxCount === 0" type="button" @click="requestAuth()"
                                class="font-medium text-indigo-500 dark:text-inherit hover:text-indigo-600 cursor-pointer">
                                Resend
                            </button>
                            <span v-else class="text-black dark:text-inherit">Expires in
                                <strong>{{ formatCount(maxCount) }}</strong></span>
                        </div>
                    </div>
                    <p v-else class="text-sm p-8 text-center font-medium">{{ message }}</p>
                    <p v-if="auth.errMsg" class="text-sm font-medium text-red-600">{{ auth.errMsg }}</p>
                    <!--submit buttons-->
                    <div class="flex items-center justify-end gap-2">
                        <secondary-button type="reset" name="Cancel" @click="auth.closeAuthModal()" />
                        <primary-button @click="auth.authenticate()" type="button" name="Validate"
                            :loading="auth.loading" icon="fa-solid fa-shield-halved" />
                    </div>
                </div>
            </MyTransition>
        </div>
    </teleport>
</template>