<script setup>
import { useLayoutManager } from "@/composable/layoutManager";
const { menuCollapsed, isMobile } = useLayoutManager();
</script>
<template>
    <!--<div :class="`w-auto bg-inherit ${$attrs.class}`">
        <img
            :src="`/storage/Images/logo_img.png`"
            alt="logo"
            :class="[menuCollapsed ? 'h-12' : 'h-20', { 'h-12': isMobile }]"
        />
    </div>-->
    <div :class="`inline-flex items-center justify-center w-full bg-inherit ${$attrs.class}`">
        <img :src="`/storage/Images/logo_img.png`" alt="SmartLoyalty" class="object-cover"
            :class="[menuCollapsed ? 'h-12' : 'h-16', { 'h-12': isMobile }]" />

        <div v-if="!menuCollapsed || isMobile" class="text-center">
            <h1 class="font-black text-2xl leading-none">
                <span class="text-blue-950 dark:text-inherit">Smart</span><span
                    class="text-orange-500 font-caveat">Loyalty</span>
            </h1>

            <p class="mt-0 normal-case text-blue-950 dark:text-inherit font-semibold text-[10px]">
                Shop
                <span class="text-orange-500 mx-auto">•</span>
                Earn
                <span class="text-orange-500 mx-auto">•</span>
                Redeem
            </p>
        </div>
    </div>
</template>
