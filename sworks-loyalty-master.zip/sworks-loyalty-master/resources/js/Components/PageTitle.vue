<script setup>
defineProps({
    title: {
        type: String,
        required: true,
    },
    description: String,
});
</script>
<template>
    <div class="md:p-2">
        <h1 class="md:text-xl text-sm text-gray-600 dark:text-inherit font-medium">
            {{ title }}
        </h1>
        <p v-if="description" class="md:text-sm text-xs text-gray-500 font-normal">
            {{ description }}
        </p>
    </div>
</template>
