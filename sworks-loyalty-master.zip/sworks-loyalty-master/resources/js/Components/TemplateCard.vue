<script setup>
    import { ref } from 'vue';
    import PrimaryButton from './PrimaryButton.vue';
    import { useForm } from '@inertiajs/vue3';


    const props = defineProps({
        temp: { type: Object, required: true },
        isDefault: { type: Boolean, default: false }
    })

    const maxCount = 160
    const canEdit = ref(false)
    const allowEdit = () => {
        canEdit.value = true
    }

    const form = useForm({
        temp_id: props.temp.temp_id,
        title: props.temp.name,
        level: props.temp.level,
        description: props.temp.description ?? '',
        isDefault: props.isDefault,
    })

    function submit() {
        form.post('/crm/masters', {
            onSuccess: () => {
                canEdit.value = false
            }
        })
    }


</script>
<template>
    <form @submit.prevent="submit()"
        class="group border relative rounded-lg border-gray-300 p-2 shadow-md hover:scale-[1.03] transition-transform duration-300 ease-in-out cursor-pointer">
        <!--card badge-->
        <span v-if="isDefault"
            class="absolute top-0 left-0 bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded-br-md rounded-tl-lg">Default</span>
        <!--card header-->
        <div class="p-2">
            <h1 class="text-sm font-semibold text-center">{{ temp.name }}</h1>
            <!--card level-->
            <p class="flex items-center gap-1 text-xs text-gray-400 font-normal">
                <i class="fa-regular fa-bell"></i>
                <span class="capitalize text-xs">{{ temp.level }}</span>
            </p>
        </div>
        <!--card description-->
        <div class="relative group">
            <input type="text" name="temp_id" :id="temp.temp_id" v-model="form.temp_id" class="hidden">
            <input type="text" name="title" :id="temp.name" v-model="form.name" class="hidden">
            <input type="text" name="level" :id="temp.level" v-model="form.level" class="hidden">
            <input type="checkbox" name="isDefault" :id="isDefault" v-model="form.isDefault" class="hidden">
           <TextAreaInput label="Description" name="description" :id="temp.temp_id" v-model="form.description"
                :class="{ 'select-none cursor-not-allowed': !canEdit, 'focus:ring-2 focus:ring-blue-500 text-gray-600': canEdit }"
               rows="6" :readonly="!canEdit" :disabled="!canEdit" :autofocus="canEdit" must />
            <button v-if="!canEdit" @click="allowEdit()" type="button" title="Edit message body"
                class="text-xs cursor-pointer opacity-0 group-hover:opacity-100 font-medium text-blue-600 hover:bg-blue-700 hover:text-white border border-blue-300 bg-blue-50 rounded-md py-1 px-2 absolute top-1/2 right-1/2 focus:text-blue-700 transition-colors duration-300 ease-in-out">
                <i class="fa-solid fa-pen-fancy"></i>
                Edit
            </button>
        </div>
        <!--character count-->
        <div class="flex justify-between items-center">
            <span class="text-xs text-gray-400 font-normal">{{ form.description.length }}/{{ maxCount }} count</span>
        </div>
        <!--card actions-->
        <div class="h-fit">
            <PrimaryButton type="submit" :title="isDefault ? 'Use this template' : 'Save changes'"
                class="opacity-0 group-hover:opacity-100 w-full mt-1"
                :name="isDefault ? 'Use this template' : 'Save changes'"
                :icon="isDefault ? 'fa-solid fa-check' : 'fa-solid fa-floppy-disk'" />
        </div>
    </form>
</template>