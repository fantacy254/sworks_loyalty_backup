<template>
    <div class="space-y-2" :class="$attrs.class">
        <label v-if="label" class="text-xs md:text-sm dark:text-slate-300 font-medium" :for="id">{{ label }}:<i
                v-if="must" class="text-red-500 font-semibold">*</i></label>
        <select :id="id" ref="input" v-model="selected" v-bind="{ ...$attrs, class: null }"
            class="rounded-md appearance-none p-2 mx-auto bg-white text-xs border-b-2 dark:border-b-blue-700 border-gray-100 dark:border-slate-700 focus:outline-none focus:border-none dark:bg-black/80 w-full form-input"
            :class="{
                [$attrs.class]: true,
                'border-red-600 text-red-500': error,
            }" :placeholder="placeholder" :required="must">
            <slot />
        </select>
        <p v-if="error" class="font-normal text-xs text-red-500">{{ error }}</p>
    </div>
</template>
<style>
.form-input {
    border-bottom: 3px solid blue;
    outline: none;
}

.form-input:focus {
    border: none;
    outline: none;
}
</style>
<script setup>
import { ref, watch } from "vue";
import { v4 as uuid } from "uuid";

const props = defineProps({
    id: {
        type: String,
        default: () => `select-input-${uuid()}`,
    },
    error: String,
    label: String,
    modelValue: [String, Number, Boolean],
    must: Boolean,
    placeholder: {
        type: String,
        required: false,
    },
});

const emit = defineEmits(["update:modelValue"]);
const input = ref(null);
const selected = ref(props.modelValue);

watch(
    () => props.modelValue,
    (value) => {
        selected.value = value;
    },
);

watch(selected, (value) => {
    emit("update:modelValue", value);
});

const focus = () => {
    input.value?.focus();
};

const select = () => {
    input.value?.select();
};
</script>
