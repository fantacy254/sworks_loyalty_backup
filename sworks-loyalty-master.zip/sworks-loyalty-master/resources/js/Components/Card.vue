<script setup>
defineProps({
    theme: String,
    amount: String,
    trend: String,
    icon: String,
    name: String,
    link: String,
    hasValue: {
        type: Boolean,
        default: false
    },
});

const cardTheme = {
    'blue': 'border-l-blue-500 dark:border-l-blue-500 border-blue-100 dark:shadow-blue-800 shadow-blue-300 dark:border-blue-900',
    'red': 'border-l-red-500 dark:border-l-red-500 border-red-100 dark:shadow-red-800 shadow-red-300 dark:border-red-900',
    'green': 'border-l-green-500 dark:border-l-green-500 border-green-100 dark:shadow-green-800 shadow-green-300 dark:border-green-900',
    'amber': 'border-l-amber-500 dark:border-l-amber-500 border-amber-100 dark:shadow-amber-800 shadow-amber-300 dark:border-amber-900',
    'violet': 'border-l-violet-500 dark:border-l-violet-500 border-violet-100 dark:shadow-violet-800 shadow-violet-300 dark:border-violet-900',
}

</script>
<template>
    <div class="rounded-lg shadow-lg border border-l-4 p-2 space-y-0 transition-all duration-300 ease-in-out hover:scale-[1.06]"
        :class="cardTheme[theme]">
        <!---Amount section--->
        <div class="flex items-center justify-between relative w-full">
            <h1 class="text-3xl font-bold font-mono text-ellipsis truncate">
                {{ amount }}
            </h1>
            <i :class="`${icon} text-${theme}-500`"
                class="text-3xl opacity-30 dark:opacity-50 absolute right-1 top-1"></i>
        </div>
        <!---card name/ type name-->
        <div class="capitalize text-xs font-semibold" :class="`text-${theme}-500`">
            {{ name }}
        </div>
        <div v-if="hasValue" class="flex items-center capitalize justify-end text-xs">
            value: &nbsp;{{ amount }}
        </div>
        <div v-else class="flex items-center font-bold capitalize justify-end gap-2 text-xs"
            :class="[parseFloat(trend) > 0 ? 'text-green-600' : 'text-red-600']">
            <i v-if="parseFloat(trend) > 0" class="fa-solid fa-arrow-trend-up text-sm"></i>
            <i v-else class="fa-solid fa-arrow-trend-down text-sm"></i>
            <span>{{ trend }}</span>
        </div>
        <!--find more button-->
        <div>
            <button @click="$emit('btnClick')" type="button" class="space-x-2 text-xs text-blue-600 cursor-pointer">
                <span>Find more</span>
                <i class="fa-solid fa-arrow-up-right-from-square"></i>
            </button>
        </div>
    </div>
</template>
