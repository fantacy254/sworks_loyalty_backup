<script setup>
    import { router, useForm } from '@inertiajs/vue3';
    import { ref } from 'vue';

    const props = defineProps({
        locations: Object
    })

    const form = useForm({
        name: ''
    })
    const editId = ref(null)

    const allowEdit = (id) => {
        if (!id) return

        const itm = props.locations.find((lc) => lc.id && id === lc.id)

        if (!itm) return

        editId.value = id
        form.name = itm.name
    }

    const resetFrom = () => {
        editId.value = null
        form.reset()
    }

    const btnHandler = () => {
        return editId.value ? updateLocation() : saveLocation()
    }

    const updateLocation = () => {
        form.patch(`/loyalty/masters/${editId.value}/location`, {
            onSuccess: () => {
                editId.value = null
                form.reset()
            }
        })
    }

    const saveLocation = () => {
        form.post('/loyalty/masters/location', {
            onSuccess: () => form.reset()
        })
    }

    function deletLocation(id) {
        if (confirm('Are you sure you want delete this record')) {
            router.delete(`/loyalty/masters/${id}/location`)
        }
    }

</script>
<template>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <!--form-->
        <div class="border rounded-md shadow-sm">
            <!--header-->
            <button type="button" @click="resetFrom()"
                class="text-sm p-3 flex items-center justify-start font-normal hover:bg-gray-50 w-full rounded-2xl">
                <i class="fa-solid fa-plus"></i>&nbsp;
                Add location
            </button>
            <hr>
            <!--body-->
            <form @submit.prevent="btnHandler()" class="p-2 space-y-3">
                <TextInput v-model="form.name" type="text" label="Name" must />
                <PrimaryButton type="submit" :name="editId ? 'Save changes' : 'Save'" :loading="form.processing"
                    class="w-full" />
            </form>
        </div>
        <!--listing-->
        <div class="border rounded-md shadow-sm">
            <!--header-->
            <h1 class="text-md p-3 font-normal">
                <i class="fa-solid fa-location-dot"></i>&nbsp;
                Locations ({{ locations.length }})
            </h1>
            <hr>
            <div class="p-4 space-y-2">
                <div v-for="loc in locations" :key="loc.id"
                    class="flex items-center border border-gray-200 rounded-lg text-sm p-2">
                    <h1 class="flex-1">{{ loc.name }}</h1>
                    <div class="flex items-center gap-1">
                        <button type="button" class="rounded-md hover:shadow-sm cursor-pointer text-blue-600"
                            @click="allowEdit(loc.id)">
                            <i class="fa-regular fa-pen-to-square"></i>
                        </button>
                        <button type="button" class="rounded-md hover:shadow-sm cursor-pointer text-red-600"
                            @click="deletLocation(loc.id)">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>