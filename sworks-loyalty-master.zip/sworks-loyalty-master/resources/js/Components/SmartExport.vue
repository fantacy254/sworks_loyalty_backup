<script>
import axios from "axios";
import { utils, writeFileXLSX, writeXLSX } from "xlsx";

export default {
    props: {
        transData: {
            type: Array,
            required: true,
        },
        name: {
            type: String,
            required: true,
        },
    },
    methods: {
        exportData() {
            try {
                // Extract headers dynamically from the first item in the response data
                const header = Object.keys(this.transData[0]);
                const resArray = this.transData.map((item) =>
                    header.map((header) => item[header]),
                );
                // Hardcoded data for the first three rows
                const titles = [
                    [this.$page.props.auth.company.name],
                    [this.$page.props.auth.company.address],
                    [this.name],
                ];

                // Calculate totals for numeric columns
                const totalRow = header.map((header, index) => {
                    if (index === 0) return "Total"; // First cell in total row
                    if (typeof this.transData[0][header] === "number") {
                        return this.transData.reduce(
                            (sum, row) => sum + row[header],
                            0,
                        );
                    }
                    return ""; // Non-numeric columns
                });

                let data = [...titles, header, ...resArray, totalRow];
                //console.log(this.transData)

                /**create worksheet and append workbook */
                const wb = utils.book_new();

                /**generate worksheet from state */
                const ws = utils.aoa_to_sheet(data);
                //const ws = utils.sheet_to_json(data)

                // Set up merging for the first three rows
                ws["!merges"] = [
                    { s: { r: 0, c: 0 }, e: { r: 0, c: 5 } },
                    { s: { r: 1, c: 0 }, e: { r: 1, c: 5 } },
                    { s: { r: 2, c: 0 }, e: { r: 2, c: 5 } },
                ];
                //Define Styles
                const firstRowStyle = {
                    font: { bold: true, sz: 13, color: { rgb: "0000FF" } },
                    alignment: { horizontal: "center", vertical: "center" },
                };

                //Apply style to the first three rows
                const range = utils.decode_range(ws["!ref"]);
                for (let R = 0; R <= 2; R++) {
                    for (let C = range.s.c; C <= range.e.c; C++) {
                        const cellAddress = utils.encode_cell({ r: R, c: C });
                        if (!ws[cellAddress])
                            ws[cellAddress] = {
                                t: "s",
                                v: "",
                            };
                        ws[cellAddress].s = firstRowStyle;
                    }
                }
                // Define style for the total row
                const totalRowStyle = {
                    font: { bold: true, sz: 12, color: { rgb: "FF0000" } },
                    alignment: { horizontal: "right", vertical: "center" },
                };

                // Apply style to the total row
                const totalRowIndex = data.length - 1;
                for (let C = 0; C < header.length; C++) {
                    const cellAddress = utils.encode_cell({
                        r: totalRowIndex,
                        c: C,
                    });
                    if (!ws[cellAddress]) ws[cellAddress] = { t: "s", v: "" }; // Initialize cell if it doesn't exist
                    ws[cellAddress].s = totalRowStyle;
                }

                /* calculate column width */
                const max_width = header.map((w, r) => ({
                    wch: Math.max(
                        ...data.map((row) =>
                            row[r] ? row[r].toString().length : 10,
                        ),
                    ),
                }));

                //set column widths
                ws["!cols"] = max_width;

                utils.book_append_sheet(wb, ws, this.name);

                /**export to XLSX */
                writeFileXLSX(wb, this.name + ".xlsx", {
                    compression: true,
                    cellStyles: true,
                });
            } catch (error) {
                console.log(error);
            }
        },
    },
};
</script>
<template>
    <button
        type="button"
        @click="exportData"
        :disabled="transData.length <= 0"
        :class="{ 'cursor-not-allowed': transData.length <= 0 }"
        class="hover:bg-green-900 hover:text-green-400 text-xs rounded-md p-2 bg-green-600 text-green-200"
    >
        <i class="fa-regular fa-file-excel"></i>
        Export
    </button>
</template>
