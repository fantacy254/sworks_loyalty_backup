<script setup>
import MyTransition from "@/Components/MyTransition.vue";
import { useForm } from "@inertiajs/vue3";
import { inject } from "vue";

const { showImport, importHandler } = inject("showImport");

const form = useForm({
    file: null,
});

const importCustomers = () => {
    form.post("/import-customers", {
        onSuccess: () => {
            form.reset();
            importHandler();
        },
    });
};
</script>
<template>
    <teleport to="body">
        <div v-show="showImport" @click.self="importHandler()"
            class="absolute z-9999 top-0 min-h-screen w-full bg-black/50 flex md:items-start justify-center dark:text-slate-300 px-4 md:px-0">
            <MyTransition>
                <div class="bg-white rounded-md border mx-auto md:max-w-lg w-full mt-10 p-2">
                    <h1 class="text-center text-lg text-gray-400 font-medium p-2">
                        Loyalty Customer import
                    </h1>
                    <hr />
                    <div class="mt-2 p-2">
                        <p class="text-sm text-gray-500">
                            To import your customers, please download the
                            template file, fill in the required information, and
                            then upload the completed file.
                        </p>
                        <a href="/export-template" download
                            class="inline-block mt-3 text-sm text-indigo-600 hover:text-indigo-900 font-medium">
                            <i class="fa-solid fa-file-arrow-down"></i>
                            Download Template
                        </a>
                        <form @submit.prevent="importCustomers()" enctype="multipart/form-data" class="mt-4">
                            <progress v-if="form.progress" :value="form.progress.percentage" max="100">
                                {{ form.progress.percentage }}%
                            </progress>
                            <input type="file" @input="form.file = $event.target.files[0]" name="file"
                                accept=".xlsx, .xls, .csv" required
                                class="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700" />
                            <primary-button type="submit" class="mt-3 w-full" icon="fa-solid fa-file-arrow-up"
                                name="Upload" :loading="form.processing" />
                        </form>
                    </div>
                    <hr />
                    <div></div>
                </div>
            </MyTransition>
        </div>
    </teleport>
</template>
