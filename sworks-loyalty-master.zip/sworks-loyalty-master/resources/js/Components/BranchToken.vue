<script setup>
import { Form } from "@inertiajs/vue3";

defineProps({
    companyId: {
        type: [String, Number],
        required: true,
    },
    branchId: {
        type: [String, Number],
        required: true,
    },
    branchName: {
        type: String,
        required: true,
    },
    token: {
        type: String,
        required: true,
    },
});
</script>
<template>
    <Form
        method="post"
        action="/oauth/generate-branch-token"
        v-slot="{ errors, processing }"
        class="flex items-center space-x-2 w-full"
        :disableWhileProcessing="true"
    >
        <div
            class="w-full md:w-fit space-y-2 md:space-y-0 flex flex-col md:flex-row md:space-x-2"
        >
            <text-input
                type="number"
                :modelValue="companyId"
                :error="errors.company_id"
                label="Company ID"
                name="company_id"
                placeholder="Company ID"
                class="w-full"
                hidden
                readonly
                must
            />
            <text-input
                type="number"
                :modelValue="branchId"
                :error="errors.branch_id"
                label="Branch ID"
                name="branch_id"
                placeholder="Branch ID"
                class="w-full"
                hidden
                readonly
                must
            />
            <text-input
                type="text"
                :modelValue="branchName"
                :error="errors.branch_name"
                label="Name"
                name="branch_name"
                placeholder="Branch Name"
                class="w-full md:w-fit"
                must
                readonly
            />
            <text-input
                v-if="token"
                type="text"
                :modelValue="token"
                :error="errors.token"
                label="Token"
                name="token"
                placeholder="Branch Token"
                class="w-full"
                readonly
            />
        </div>
        <button
            v-if="!token"
            title="Generate Token"
            type="submit"
            class="mt-4 text-nowrap text-gray-500"
            :loading="processing"
        >
            <i class="fas fa-key"></i>
        </button>
    </Form>
</template>
