<script setup>
    import { useForm, usePage } from "@inertiajs/vue3";
    import { computed, onMounted, ref, watch } from "vue";

    const props = defineProps({
        temps: Object,
        preview: {
            type: Boolean,
            default: false
        }
    })

    const page = usePage()
    const maxCount = 160
    const groups = ref([])
    const locations = ref([])
    const custCount = ref(0)

    const radioFilters = [
        { name: 'All', val: 'all' },
        { name: 'Manual input', val: 'manual' },
        { name: 'Group', val: 'group' },
        { name: 'Location', val: 'location' },
        { name: 'Gender', val: 'gender' },
    ]

    const form = useForm({
        sender: page.props.auth.company.sender_id,
        recipient: 'all',  //group,location,all
        master: 1,
        gender: 'm',
        phone_number: '',
        template_id: 'custom',
        message: ''
    })

    const selectSmsTemplate = (temp) => {
        const selectedTemp = props.temps.find(t => t.temp_id === temp).description

        return selectedTemp ? form.message = selectedTemp : form.reset('message')
    }

    const computedTemps = computed(() => {
        return props.temps.filter(temp => temp.temp_id === 'promotional');
    })

    const sampleMsgData = {
        'auth_code': '123456',
        'user_name': 'John Doe',
        'user_email': 'john.doe@example.com',
        'user_password': 'password123',
        'cust_name': 'John Doe',
        'points': 1500,
        'voucher': 'VOC-2024-087543',
        'expiry': '15th March 2025'
    }

    const messagePreview = computed(() => {
        const val = form.message ?? ''
        return val.replace(/\\n/g, '\n')
            .replace(/{(\w+)}/g, (match, key) => sampleMsgData[key] || match);
    })

    const sendBulkSms = () => {
        form.post('/crm/send-bulk', {
            onSuccess: () => {
                form.reset()
            }
        })
    }

    const getBulkMasters = async () => {
        const res = await axios.get('/loyalty/bulk-masters').catch((e) => { console.log(e.message) })

        if (res.data.length === 0) return

        groups.value = res.data[0]
        locations.value = res.data[1]
    }

    const getCustCount = async () => {
        if (form.recipient === 'manual') {
            custCount.value = 1
            return
        }
        custCount.value = 0
        await axios.get('/loyalty/bulk-count', { params: { selection: form.recipient, master: form.master, gender: form.gender } })
            .then((res) => {
                custCount.value = res.data
            }).catch((e) => {
                page.props.flash.error = e.message
                console.log('Catch exception', e)
            })
    }

    const smsRate = computed(() => page.props.auth.company.sms_rate)

    const estCost = computed(() => {
        return (custCount.value * smsRate.value).toFixed(2)
    })

    watch(() => [form.recipient, form.master, form.gender], () => {
        getCustCount()
    })

    onMounted(() => {
        getBulkMasters()
        getCustCount()
    })

</script>
<template>
    <div class="flex items-start gap-4 px-2 w-auto">
        <!--message template-->
       <div class="border dark:border-gray-400 rounded-xl p-2 shadow-md w-sm">
            <h1 class="p-2 text-center font-medium text-md">Message Template</h1>
            <hr>
            <form @submit.prevent="sendBulkSms()" class="space-y-2 p-2">
                <!--sender-->
               <TextInput type="text" name="sender" label="Sender" id="sender" v-model="form.sender" class="w-full"
                    disabled />
                <!--receipts-->
                <div class="space-y-1">
                   <label for="receipts" class="text-sm">Recipient:</label>
                    <div
                       class="flex items-center justify-start gap-2 border rounded-md border-gray-300 dark:border-gray-400 p-2 w-fit shadow-inner">
                       <label v-for="(itm, index) in radioFilters" :key="index"
                            class="text-xs flex items-center gap-1 cursor-pointer text-nowrap">
                            <input @change="form.reset('master')" type="radio" v-model="form.recipient" name="recipient"
                                class="focus:ring-0 focus:outline-none focus:border-none size-3.5" :id="itm.val"
                                :value="itm.val">
                            <span>{{ itm.name }}</span>
                        </label>
                    </div>
                </div>
                <!--phone number for manual-->
               <TextInput v-if="form.recipient === 'manual'" :error="form.errors.phone_number"
                    v-model="form.phone_number" name="phone_number" label="Phone Number" placeholder="eg. 0712345678" />
               <!--Group filter-->
                <SelectInput v-if="form.recipient === 'group'" v-model="form.master" label="Customer Group"
                    placeholder="Select customer group">
                    <option v-for="gp in groups" :key="gp.id" :value="gp.id">
                        {{ gp.name }}
                    </option>
                </SelectInput>
                <!--location filter-->
                <SelectInput v-if="form.recipient === 'location'" v-model="form.master" label="Customer Location"
                    placeholder="Select customer location">
                    <option v-for="loc in locations" :key="loc.id" :value="loc.id">
                        {{ loc.name }}
                    </option>
                </SelectInput>
               <!--gender filter-->
                <SelectInput v-if="form.recipient === 'gender'" v-model="form.gender" label="Gender"
                    placeholder="Select customer gender">
                    <option value="m"> Male </option>
                    <option value="f"> Female </option>
                </SelectInput>
                <!--message template-->
                <SelectInput @change="selectSmsTemplate($event.target.value)" v-model="form.template_id"
                    label="Message Template" placeholder="Select a template">
                    <option value="custom">Custom Message</option>
                    <option v-for="tmp in computedTemps" :key="tmp.temp_id" :value="tmp.temp_id">
                        {{ tmp.name }}
                    </option>
                </SelectInput>
                <!--message body-->
                <div>
                   <TextAreaInput name="message" id="message" label="Message" rows="5"
                        placeholder="Type your message here..." v-model="form.message"
                        :readonly="form.template_id !== 'custom'" must
                        :class="{ 'text-gray-400 cursor-not-allowed': form.template_id !== 'custom' }"
/>
                   <div class="flex items-center justify-between gap-2">
                       <p class="text-xs font-medium">Count {{ form.message.length }}/{{ maxCount }}</p>
                       <p class="text-xs font-normal">Est. Cost <strong class="text-sm">Ksh.{{ estCost }}</strong></p>
                    </div>
                    <p class="text-xs opacity-40 font-medium text-right">Rate @ Ksh.{{ smsRate }}</p>
                </div>
                <!--button-->
               <div v-if="custCount > 0" class="flex items-center">
                    <PrimaryButton type="submit" class="w-full" icon="fa-regular fa-paper-plane"
                        :name="`Send to ${custCount} recipient(s)`" />
                </div>
            </form>
        </div>
        <!--message preview-->
       <div v-if="preview" class="md:flex-1 border dark:border-gray-400 rounded-xl p-1 shadow-md">
            <h1 class="p-2 text-center font-medium text-md">Message Preview</h1>
            <hr>
            <div class="p-2 space-y-1">
               <p class="text-sm text-gray-500 dark:text-slate-50"><strong
                        class="text-gray-800 dark:text-slate-300">Sender:</strong>
                    {{ page.props.auth.company.sender_id }}
                </p>
               <p class="text-sm text-gray-500 dark:text-slate-50"><strong
                       class="text-gray-800 dark:text-slate-300">Recipient:</strong>
                    {{ form.recipient === 'manual' ? form.phone_number : `${custCount} recipient(s)` }}
                </p>
               <p class="text-sm text-gray-500 dark:text-slate-50"><strong
                        class="text-gray-800 dark:text-slate-300">Template:</strong>
                    {{form.template_id === 'custom' ? 'Custom Message' : temps.find(t => t.temp_id === form.template_id)?.name}}
                </p>
               <div class="mt-2 p-2 border dark:border-gray-400 rounded-md bg-gray-50 dark:bg-inherit min-h-48">
                    <p class="text-sm h-full leading-loose whitespace-pre-wrap">
                        {{ messagePreview ?? 'Message Preview' }}
                    </p>
                </div>
            </div>
           <!--form errors-->
            <ul v-if="form.errors" class="p-4 space-y-2 list-decimal">
                <li v-for="(err, index) in form.errors" :key="index" class="text-sm text-red-500">{{ err }}</li>
            </ul>
        </div>
    </div>
</template>