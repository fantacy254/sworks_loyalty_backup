import "./bootstrap";
import "../css/app.css";

import { createApp, h, ref } from "vue";
import { createInertiaApp, Head, Link } from "@inertiajs/vue3";
import { resolvePageComponent } from "laravel-vite-plugin/inertia-helpers";

import VueSweetalert2 from "vue-sweetalert2";
import "sweetalert2/dist/sweetalert2.min.css";

import PrimaryButton from "./Components/PrimaryButton.vue";
import SecondaryButton from "./Components/SecondaryButton.vue";
import FlashMessage from "./Components/FlashMessage.vue";

import TextInput from "./Components/TextInput.vue";
import SelectInput from "./Components/SelectInput.vue";
import TextAreaInput from "./Components/TextAreaInput.vue";

import loader from "./Components/Loader.vue";
import axios from "axios";

import { initializeTheme } from "./utlis/theme.js";
import { createPinia } from "pinia";

const isLoading = ref(false);

axios.interceptors.request.use(
    (config) => {
        isLoading.value = true;
        return config;
    },
    (error) => {
        isLoading.value = false;
        return Promise.reject(error);
    },
);

axios.interceptors.response.use(
    (response) => {
        isLoading.value = false;
        return response;
    },
    (error) => {
        isLoading.value = false;
        return Promise.reject(error);
    },
);

const pinia = createPinia()

const appName = import.meta.env.VITE_APP_NAME || "Smartworks Trading Co. Ltd";

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) =>
        resolvePageComponent(
            `./Pages/${name}.vue`,
            import.meta.glob("./Pages/**/*.vue"),
        ),
    setup({ el, App, props, plugin }) {
        const VueApp = createApp({ render: () => h(App, props) })
            .use(plugin)
            .use(VueSweetalert2)
            .use(pinia)
            .component("Head", Head)
            .component("Link", Link)
            .component("Loader", loader)
            .component("PrimaryButton", PrimaryButton)
            .component("SecondaryButton", SecondaryButton)
            .component("TextInput", TextInput)
            .component("SelectInput", SelectInput)
            .component("TextAreaInput", TextAreaInput)
            .component("FlashMessage", FlashMessage)
            .provide("isLoading", isLoading);

        VueApp.mount(el);
    },
    progress: {
        color: "#FFA500",
        includeCSS: true,
        showSpinner: true,
    },
});

initializeTheme();
