// resources/js/composables/useEncryption.js
import axios from 'axios'

export const useEncryption = () => {
    /**
     * Request backend to encrypt a value
     */
    const encrypt = async (value) => {
        try {
            const response = await axios.post('/param/encrypt', { value })
            return response.data.encrypted
        } catch (error) {
            console.error('Encryption failed:', error.response)
            return value
        }
    }

    /**
     * Generate encrypted route with parameters
     */
    const encryptedRoute = async (baseRoute, params = {}) => {
        const encrypted = {}

        for (const [key, value] of Object.entries(params)) {
            encrypted[key] = await encrypt(value)
        }

        return route(baseRoute, encrypted)
    }

    return { encrypt, encryptedRoute }
}