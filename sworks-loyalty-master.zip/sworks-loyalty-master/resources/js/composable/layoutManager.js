import { computed, ref } from "vue";

const menuToggles = ref([]);
const subToggles = ref([]);
const isMobileMenuOpen = ref(false);
const menuCollapsed = ref(false);
const showFooterNavUser = ref(false)

export function useLayoutManager() {
    const isMobile = computed(() => {
        return window.innerWidth < 768;
    });

    function toggleNavMenu(index) {
        const navIndex = menuToggles.value.indexOf(index);
        if (navIndex === -1) {
            menuToggles.value = [];
            menuToggles.value.push(index);
        } else {
            menuToggles.value.splice(navIndex, 1);
        }
    }

    function toggleSubMenu(index) {
        const navIndex = subToggles.value.indexOf(index);
        if (navIndex === -1) {
            subToggles.value = [];
            subToggles.value.push(index);
        } else {
            subToggles.value.splice(navIndex, 1);
        }
    }

    function closeMobileMenu() {
        if (isMobile.value) {
            isMobileMenuOpen.value = false;
        }
    }

    function sidebarToggle() {
        if (isMobile.value) {
            isMobileMenuOpen.value = !isMobileMenuOpen.value;

            console.log("toggling mobile menu", isMobileMenuOpen.value);
        } else {
            menuCollapsed.value = !menuCollapsed.value;
            console.log("toggling menu", menuCollapsed.value);
        }
    }

    return {
        menuToggles,
        toggleNavMenu,
        toggleSubMenu,
        subToggles,
        isMobile,
        isMobileMenuOpen,
        closeMobileMenu,
        sidebarToggle,
        menuCollapsed,
        showFooterNavUser,
    };
}
