import { defineStore } from "pinia";
import { reactive, ref } from "vue";


export const useAuthManager = defineStore('auth', () => {
    const showAuth = ref(false)
    const authCode = ref('')
    const loading = ref(false)
    const errMsg = ref('')
    const trans=ref('')
    let authenticationResolver = null

    function closeAuthModal(result = false){
        showAuth.value = false
        authenticationResolver?.(result)
        authenticationResolver = null
    }

    function openAuthModal(){
        showAuth.value = true
    }

    function requestAuthentication(){
        authCode.value = ''
        errMsg.value = ''
        openAuthModal()

        return new Promise((resolve) => {
            authenticationResolver = resolve
        })
    }

    async function authenticate(){
        console.log('authenticating...', authCode.value)
        if(!authCode.value) return false

        loading.value = true

        try {
        const res = await axios.post('/trans/auth/validate', {
            transType: trans.value,
            authCode: authCode.value
        })

            if(res.data.cd != 0){
                errMsg.value = res.data.msg
                return false
            }

            closeAuthModal(true)
            return true
    } catch (error) {
        errMsg.value = error.message
        return false
    }finally{
        loading.value=false
    }
    }

    return { showAuth, trans, errMsg, authCode, authenticate, requestAuthentication, openAuthModal, closeAuthModal }
})