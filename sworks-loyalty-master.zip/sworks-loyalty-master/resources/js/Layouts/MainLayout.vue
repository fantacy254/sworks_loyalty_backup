<script setup>
import { inject, onMounted, ref, watch } from "vue";
import { usePage } from "@inertiajs/vue3";
import FlashMessage from "@/Components/FlashMessage.vue";
import AppShell from "@/Components/ui/AppShell.vue";
import SideBar from "@/Components/ui/SideBar.vue";
import NavBar from "@/Components/ui/NavBar.vue";
import NavMenu from "@/Components/ui/NavMenu.vue";
import MainContent from "@/Components/ui/MainContent.vue";

const page = usePage();

const isLoading = inject("isLoading");

const navItems = [
    {
        label: "Dashboard",
        icon: "fa-solid fa-building-columns",
        url: "/",
        class: "",
        show: true,
    },
    //Loyalty
    {
        label: "Loyalty",
        icon: "fa-regular fa-address-card",
        dropmenu: true,
        show: true,
        subNavItems: [
            {
                sublabel: "Masters",
                suburl: "/loyalty/masters",
                subicon: "fa-solid fa-users-gear",
                show: page.props.auth.user.isAdmin,
            },
            {
                sublabel: "Loyalty Customers",
                suburl: "/customers",
                subicon: "fa-solid fa-users-viewfinder",
                show: true,
            },
            {
                sublabel: "Customer Statement",
                suburl: "/loyalty-statement",
                subicon: "fa-solid fa-elevator",
                show: true,
            },
            {
                sublabel: "Customer Listing",
                suburl: "/customer-listing",
                subicon: "fa-solid fa-toolbox",
                show: true,
            },
            {
                sublabel: "Redeem points",
                suburl: "/loyalty-balance",
                subicon: "fa-regular fa-address-book",
                show: true,
            },
            {
                sublabel: "Loyalty Transaction",
                subicon: "fa-solid fa-map-location-dot",
                dropmenu: true,
                show: true,
                minimenu: [
                    {
                        minilabel: "Award Points",
                        miniurl: "/points-award",
                        minicon: "fa-solid fa-award",
                        show: true,
                    },
                    {
                        minilabel: "Cancel Points Award",
                        miniurl: "/cancel-points",
                        minicon: "fa-solid fa-text-slash",
                        show: true,
                    },
                    {
                        minilabel: "Points Adjustments",
                        miniurl: "/points-adj",
                        minicon: "fa-solid fa-sliders",
                        show: true,
                    },
                ],
            },
            {
                sublabel: "Transaction Listing",
                suburl: "/trans-listing",
                subicon: "fa-solid fa-list-check",
                show: true,
            },
            {
                sublabel: "Loyalty voucher Listing",
                suburl: "/voucher-listing",
                subicon: "fa-solid fa-memory",
                show: true,
            },
        ],
    },
    //CRM
    {
        label: "CRM",
        icon: "fa-regular fa-envelope",
        dropmenu: true,
        show: true,
        subNavItems: [
            {
                sublabel: "Masters",
                suburl: "/crm/masters",
                subicon: "fa-solid fa-envelope-open-text",
                show: page.props.auth.user.isAdmin,
            },
            {
                sublabel: "Bulk SMS",
                suburl: "/crm/send-bulk",
                subicon: "fa-solid fa-envelopes-bulk",
                show: true,
            },
            {
                sublabel: "Outbox",
                suburl: "/crm/outbox",
                subicon: "fa-regular fa-envelope-open",
                show: true,
            },
        ]
    },
    //admin
    {
        label: "Admin",
        icon: "fa-solid fa-user-tie",
        dropmenu: true,
        show: true,
        subNavItems: [
            {
                sublabel: "Users",
                suburl: "/user",
                subicon: "fa-solid fa-users-gear",
                show: page.props.auth.user.isAdmin,
            },
            {
                sublabel: "Rights & Permissions",
                suburl: "/permissions",
                subicon: "fa-solid fa-person-walking-dashed-line-arrow-right",
                show: page.props.auth.user.isAdmin,
            },
            {
                sublabel: "My Profile",
                suburl: "/user/profile",
                subicon: "fa-solid fa-chalkboard-user",
                show: true,
            },
        ],
    },
];
//dropdownIcon: ref(false)
</script>
<template>
    <AppShell>
        <SideBar>
            <NavBar>
                <NavMenu :navItems="navItems" />
            </NavBar>
        </SideBar>
        <!--body-->
        <MainContent>
            <Loader :show="isLoading" />
            <FlashMessage />
            <slot />
        </MainContent>
    </AppShell>
</template>
