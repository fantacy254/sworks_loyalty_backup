<script setup>
import SmartCloud from "@/Components/SmartCloud.vue";
</script>
<template>
    <!--flash messages-->
    <flash-message />
    <!--body-->
    <main
        class="flex items-center px-2 md:px-0 md:justify-center w-full min-h-screen dark:bg-black/90 dark:text-slate-50"
    >
        <div class="w-full md:w-auto transition-all ease-in-out duration-300">
            <smart-cloud class="flex items-center justify-center" />
            <slot />
        </div>
    </main>
</template>
