<script setup>
import AppShell from "@/Components/ui/AppShell.vue";
import SideBar from "@/Components/ui/SideBar.vue";
import NavBar from "@/Components/ui/NavBar.vue";
import NavMenu from "@/Components/ui/NavMenu.vue";
import MainContent from "@/Components/ui/MainContent.vue";
import FlashMessage from "@/Components/FlashMessage.vue";
import { inject } from "vue";

const isLoading = inject("isLoading");

const navItems = [
    {
        label: "Dashboard",
        url: "/master-dashboard",
        icon: "fas fa-tachometer-alt",
        show: true,
    },
    {
        label: "Company Center",
        url: "/company-center",
        icon: "fas fa-building",
        show: true,
    },
    {
        label: "OAuth Integration",
        url: "/oauth/integration",
        icon: "fas fa-shield-alt",
        show: true,
    },
     {
        label: "SMS Usage",
        url: "/company/sms-usage",
        icon: "fa-regular fa-comments",
        show: true,
    },
];
</script>
<template>
    <AppShell>
        <SideBar>
            <NavBar>
                <NavMenu :navItems="navItems" />
            </NavBar>
        </SideBar>
        <!--body-->
        <MainContent>
            <Loader :show="isLoading" />
            <FlashMessage />
            <slot />
        </MainContent>
    </AppShell>
</template>
