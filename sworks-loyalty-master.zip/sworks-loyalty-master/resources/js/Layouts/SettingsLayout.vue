<script setup>
import NavMenu from "@/Components/ui/NavMenu.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { usePage } from "@inertiajs/vue3";

const page = usePage();
const navItems = [
    {
        label: "General",
        icon: "fas fa-gear",
        url: "/settings",
        class: "",
        show: true,
    },
    {
        label: "Notifications",
        icon: "fa-regular fa-bell",
        url: "/settings/notifications",
        class: "",
        show: page.props.auth.user.isAdmin,
    },
    {
        label: "Privacy",
        icon: "fa-solid fa-shield-halved",
        url: "/settings/privacy",
        class: "",
        show: true,
    },
];
</script>
<template>
    <div>
        <!--section header-->
        <PageTitle title="Settings" />
        <!--nav section-->
        <div class="md:flex md:items-start md:justify-start">
            <!--navbar-->
            <div class="hidden md:block w-48">
                <NavMenu :navItems="navItems" />
            </div>
            <!--navbar small screen-->
            <div
                class="md:hidden flex items-center justify-start mb-4 space-x-2 overflow-auto no-scrollbar scroll-smooth"
            >
                <Link
                    v-for="(item, index) in navItems"
                    :key="index"
                    :href="item.url"
                    class="rounded-md border block px-4 py-2 text-sm font-medium hover:bg-gray-100"
                    :class="{
                        'text-blue-500 border-blue-500': page.url === item.url,
                    }"
                >
                    {{ item.label }}
                </Link>
            </div>
            <main class="border-l min-h-full w-full p-1 md:px-6">
                <slot />
            </main>
        </div>
    </div>
</template>
