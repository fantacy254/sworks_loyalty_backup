<script setup>
import { transMenu } from "@/utlis/TransMenu";
import { usePage } from "@inertiajs/vue3";
import { route } from "ziggy-js";
import { encryptParams } from "@/utlis/EncryptKey";

const page = usePage();

const title = "Transaction Listing";
</script>
<template>
    <!--meta heading-->

    <Head :title="title" />
    <!--Header section-->
    <div class="px-3 py-1">
        <h1 class="capitalize font-medium text-2xl text-slate-400">
            {{ title }}
        </h1>
    </div>
    <!--transaction listing layout-->
    <main>
        <!--menus section-->
        <section class="px-4">
            <div
                class="flex flex-wrap items-center justify-start space-x-3 px-3 py-2 w-full"
            >
                <div
                    v-for="(menu, index) in transMenu"
                    :key="index"
                    :title="menu.title"
                    class="group p-1 w-36 hover:border-b-4 hover:border-violet-600 rounded-b-md"
                    :class="{
                        'border-b-4 border-violet-600 text-black font-medium':
                            page.url.startsWith(`/reports/${menu.ledger}`),
                    }"
                >
                    <Link
                        :href="
                            route(
                                `${menu.ledger}.listing.home`,
                                menu.ledger === 'pos'
                                    ? { md: encryptParams(menu.led) }
                                    : {},
                            )
                        "
                        class="text-center text-slate-400 transition duration-300 ease-in-out"
                    >
                        <h2
                            class="group-hover:text-black group-hover:font-medium"
                            :class="{
                                'text-black font-medium': page.url.startsWith(
                                    `/reports/${menu.ledger}`,
                                ),
                            }"
                        >
                            {{ menu.title }}
                        </h2>
                    </Link>
                </div>
            </div>
        </section>
        <hr />
        <!--page section-->
        <main class="px-3 py-1">
            <slot />
        </main>
    </main>
</template>
