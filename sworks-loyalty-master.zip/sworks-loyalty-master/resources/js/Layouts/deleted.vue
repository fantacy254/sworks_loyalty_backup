<script setup>
import { inject, onMounted, ref, watch } from "vue";
import { usePage } from "@inertiajs/vue3";
import { setToggleDarkMode, setInitialTheme } from "@/utlis/theme.js";
import FlashMessage from "@/Components/FlashMessage.vue";

const page = usePage();

const isLoading = inject("isLoading");
const showDropdown = ref(false);
const showPoints = ref(false);
const showSideMenu = ref(true);
const userMenu = ref(false);
const show = ref(true);
const smallSideMenu = ref(false);
const menuItems = [
    {
        name: "Dashboard",
        icon: "fa-solid fa-building-columns",
        url: "/",
        class: "",
        show: true,
    },
    //Loyalty
    {
        name: "Loyalty",
        icon: "fa-regular fa-address-card",
        dropmenu: true,
        show: true,
        submenu: [
            {
                subname: "Loyalty Customers",
                suburl: "/customers",
                subicon: "fa-solid fa-users-viewfinder",
                show: true,
            },
            {
                subname: "Customer Statement",
                suburl: "/loyalty-statement",
                subicon: "fa-solid fa-elevator",
                show: true,
            },
            {
                subname: "Customer Listing",
                suburl: "/customer-listing",
                subicon: "fa-solid fa-toolbox",
                show: true,
            },
            {
                subname: "Balance Enquiry",
                suburl: "/loyalty-balance",
                subicon: "fa-regular fa-address-book",
                show: true,
            },
            {
                subname: "Loyalty Points",
                subicon: "fa-solid fa-map-location-dot",
                dropmenu: true,
                show: true,
                minimenu: [
                    {
                        mininame: "Award Points",
                        miniurl: "/points-award",
                        minicon: "fa-solid fa-award",
                        show: true,
                    },
                    {
                        mininame: "Cancel Points Award",
                        miniurl: "/cancel-points",
                        minicon: "fa-solid fa-text-slash",
                        show: true,
                    },
                    {
                        mininame: "Points Adjustments",
                        miniurl: "/points-adj",
                        minicon: "fa-solid fa-sliders",
                        show: true,
                    },
                ],
            },
            {
                subname: "Transaction Listing",
                suburl: "/trans-listing",
                subicon: "fa-solid fa-list-check",
                show: true,
            },
            {
                subname: "Loyalty voucher Listing",
                suburl: "/voucher-listing",
                subicon: "fa-solid fa-memory",
                show: true,
            },
        ],
    },
    //admin
    {
        name: "Admin",
        icon: "fa-solid fa-user-tie",
        dropmenu: true,
        show: true,
        submenu: [
            {
                subname: "Users",
                suburl: "/user",
                subicon: "fa-solid fa-users-gear",
                show: page.props.auth.user.isAdmin,
            },
            {
                subname: "Rights & Permissions",
                suburl: "/permissions",
                subicon: "fa-solid fa-person-walking-dashed-line-arrow-right",
                show: page.props.auth.user.isAdmin,
            },
            {
                subname: "My Profile",
                suburl: `/user/profile/${page.props.auth.user.id}`,
                subicon: "fa-solid fa-chalkboard-user",
                show: true,
            },
        ],
    },
];
const openTitles = ref([]);
const openSubTitles = ref([]);
//dropdownIcon: ref(false)

const toggleTitle = (index) => {
    //dropdownIcon = !dropdownIcon
    const titleIndex = openTitles.value.indexOf(index);
    if (titleIndex === -1) {
        openTitles.value.push(index);
    } else {
        openTitles.value.splice(titleIndex, 1);
    }
};
const toggleSubTitle = (subIndex) => {
    const titleSubIndex = openSubTitles.value.indexOf(subIndex);
    if (titleSubIndex === -1) {
        openSubTitles.value.push(subIndex);
    } else {
        openSubTitles.value.splice(titleSubIndex, 1);
    }
};
const dropDown = () => {
    return (showDropdown.value = !showDropdown.value);
};
const sideMenu = () => {
    return (showSideMenu.value = !showSideMenu.value);
};
const showUserMenu = () => {
    return (userMenu.value = true);
};
const closeUserMenu = () => {
    return (userMenu.value = false);
};
const showPointsMenu = () => {
    return (showPoints.value = !showPoints.value);
};

const openSideMenu = () => {
    return (smallSideMenu.value = true);
};
const closeSideMenu = () => {
    return (smallSideMenu.value = false);
};
const toggleDarkMode = () => {
    closeUserMenu();
    setToggleDarkMode();
};

onMounted(() => {
    setInitialTheme();
});
</script>
<template>
    <AppShell>
        <!--sidebar in mini screens-->
        <teleport to="body">
            <Transition
                appear
                name="slide-fade"
                enter-active-class="animate__animated animate__fadeInLeft animate__faster"
                leave-active-class="animate__animated animate__fadeOutLeft animate__faster"
                mode="in-out"
            >
                <div
                    v-show="smallSideMenu"
                    @click.self="closeSideMenu()"
                    class="md:hidden min-h-screen w-full select-none absolute flex items-start justify-start text-slate-300 dark:text-slate-300 z-999999 inset-0 bg-black/50 backdrop-blur-sm space-x-5"
                >
                    <div
                        @click.stop
                        class="bg-indigo-800 dark:bg-gray-800 w-5/6 h-full min-h-screen overflow-y-auto no-scrollbar"
                    >
                        <div
                            class="shadow-indigo-950 shadow-lg text-xs bg-indigo-900 space-x-4 dark:bg-gray-900 h-16 flex items-center justify-center sticky top-0 inset-0 z-9"
                        >
                            <img
                                :src="`/storage/Images/smart-logo.png`"
                                alt=""
                                class="h-12 w-14"
                            />
                            <span class="font-medium">{{
                                page.props.auth.company.name
                            }}</span>
                        </div>
                        <!--menu items-->
                        <div
                            class="pb-16 overflow-y-auto ease-linear transition-all no-scrollbar duration-300"
                        >
                            <!--expanded menu-->
                            <div>
                                <ul class="space-y-2 p-2 text-xs">
                                    <li
                                        v-for="(item, index) in menuItems"
                                        :key="index"
                                        :class="{
                                            'border-l-4 text-orange-400 border-blue-500 bg-indigo-300/50 dark:bg-gray-700 rounded-lg':
                                                page.url === item.url,
                                        }"
                                        class=""
                                    >
                                        <Link
                                            @click="closeSideMenu()"
                                            v-if="!item.dropmenu && item.show"
                                            :href="item.url"
                                            class="flex items-center space-x-3 hover:bg-indigo-300/50 hover:dark:bg-gray-700 hover:text-orange-400 px-2 py-3 rounded-md"
                                        >
                                            <i :class="item.icon"></i>
                                            <span>{{ item.name }}</span>
                                        </Link>
                                        <div
                                            v-show="item.show"
                                            v-else
                                            @click="toggleTitle(index)"
                                            class="flex items-center justify-between hover:bg-indigo-300/50 hover:dark:bg-gray-700 hover:text-orange-400 px-2 py-3 rounded-md"
                                        >
                                            <div class="space-x-3">
                                                <i :class="item.icon"></i>
                                                <span>{{ item.name }}</span>
                                            </div>
                                            <i
                                                :class="{
                                                    'text-red-500 rotate-180':
                                                        openTitles.includes(
                                                            index,
                                                        ),
                                                }"
                                                class="fa-solid fa-angle-left mr-2 transition-transform duration-300"
                                            ></i>
                                        </div>
                                        <!--submenus-->
                                        <ul
                                            v-if="
                                                item.dropmenu &&
                                                openTitles.includes(index)
                                            "
                                            class="mt-1 pt-1 ml-4"
                                        >
                                            <li
                                                v-for="(
                                                    sub, subIndex
                                                ) in item.submenu"
                                                :key="subIndex"
                                                class=""
                                                :class="{
                                                    'border-l-4 text-orange-400 border-blue-500 bg-indigo-300/50 dark:bg-gray-700 rounded-lg':
                                                        page.url === sub.suburl,
                                                }"
                                            >
                                                <Link
                                                    v-show="sub.show"
                                                    @click="closeSideMenu()"
                                                    v-if="!sub.dropmenu"
                                                    :href="sub.suburl"
                                                    class="hover:bg-indigo-300/50 hover:dark:bg-gray-700 hover:text-orange-400 flex items-center space-x-3 px-2 py-3 rounded-md"
                                                >
                                                    <i :class="sub.subicon"></i>
                                                    <span>{{
                                                        sub.subname
                                                    }}</span>
                                                </Link>
                                                <div
                                                    v-show="sub.show"
                                                    v-else
                                                    @click="
                                                        toggleSubTitle(subIndex)
                                                    "
                                                    class="hover:bg-indigo-300/50 hover:dark:bg-gray-700 hover:text-orange-400 flex items-center justify-between px-2 py-3 rounded-md"
                                                >
                                                    <div
                                                        class="space-x-3 hover:text-orange-400"
                                                    >
                                                        <i
                                                            :class="sub.subicon"
                                                        ></i>
                                                        <span
                                                            v-if="!showSideMenu"
                                                            >{{
                                                                sub.subname
                                                            }}</span
                                                        >
                                                    </div>
                                                    <i
                                                        :class="{
                                                            'text-red-500 rotate-180 animate-bounce':
                                                                openSubTitles.includes(
                                                                    subIndex,
                                                                ),
                                                        }"
                                                        class="fa-solid fa-angle-left mr-3"
                                                    ></i>
                                                </div>
                                                <!--minimenus-->
                                                <ul
                                                    v-if="
                                                        sub.dropmenu &&
                                                        openSubTitles.includes(
                                                            subIndex,
                                                        )
                                                    "
                                                    class="mt-1"
                                                >
                                                    <li
                                                        v-show="min.show"
                                                        @click="closeSideMenu()"
                                                        v-for="(
                                                            min, index
                                                        ) in sub.minimenu"
                                                        :key="index"
                                                        class="px-2 py-3 hover:bg-indigo-300/50 hover:dark:bg-gray-700 hover:text-orange-400 rounded-md"
                                                        :class="{
                                                            'border-l-4 text-orange-400 border-blue-500 bg-indigo-300/50 dark:bg-gray-700 rounded-lg':
                                                                page.url ===
                                                                min.miniurl,
                                                        }"
                                                    >
                                                        <Link
                                                            :href="min.miniurl"
                                                            class="space-x-3"
                                                        >
                                                            <i
                                                                :class="
                                                                    min.minicon
                                                                "
                                                            ></i>
                                                            <span
                                                                v-if="
                                                                    !showSideMenu
                                                                "
                                                                >{{
                                                                    min.mininame
                                                                }}</span
                                                            >
                                                        </Link>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <button
                        @click="closeSideMenu()"
                        type="button"
                        class="mt-2 md:hidden rounded-full text-2xl text-white"
                    >
                        <i class="fa-solid fa-x font-light"></i>
                    </button>
                </div>
            </Transition>
        </teleport>
        <!--Sidebar start
        <aside :class="[
            showSideMenu
                ? 'w-60 delay-700'
                : 'w-[53px] delay-200 duration-200 transition-transform',
        ]"
            class="absolute hidden lg:static left-0 top-0 z-9999 md:flex h-screen min-h-screen flex-col overflow-y-hidden from-indigo-950 text-slate-300 via-indigo-900 to-indigo-700 bg-linear-to-br dark:from-gray-800 dark:via-gray-800 dark:to-gray-700 transition-transform duration-200 delay-150 ease-out">
            <div :class="[showSideMenu ? 'h-14' : ' px-2 py-3 h-14']"
                class="shadow-indigo-950 shadow-lg bg-indigo-950 dark:bg-gray-950 flex items-center justify-center transition-all duration-150 ease-in-out">
                <img :src="`/storage/Images/smart-logo.png`" alt=""
                    class="mx-auto my-auto animate__animated animate__fadeInDown animate__faster h-11 w-10" />
                <smart-cloud />
            </div>
            <div :class="[
                !showSideMenu
                    ? 'mx-0 px-0 py-2 pt-2'
                    : 'mx-2 pt-6 py-4 px-0 text-sm',
            ]" class="text-slate-300 overflow-y-auto ease-linear transition-all no-scrollbar duration-300">
                expanded menu
                <ul :class="[showSideMenu ? 'space-y-2 p-2' : 'px-1']">
                    <li v-for="(item, index) in menuItems" :key="index" :class="{
                        'border-l-4 text-orange-400 border-blue-500 bg-indigo-300/50 dark:bg-gray-700 rounded-lg':
                            page.url === item.url,
                    }" class="">
                        <Link v-show="item.show" v-if="!item.dropmenu" :href="item.url"
                            class="flex items-center text-lg space-x-3 hover:bg-indigo-300/50 hover:text-orange-400 px-2 py-3 rounded-md">
                        <i :class="item.icon"></i>
                        <span v-if="showSideMenu" class="text-xs">{{
                            item.name
                        }}</span>
                        </Link>
                        <div v-show="item.show" v-else @click="toggleTitle(index)" :class="[
                            showSideMenu
                                ? 'justify-between'
                                : 'justify-evenly space-x-2',
                        ]"
                            class="flex items-center hover:bg-indigo-300/50 hover:text-orange-400 dark:hover:bg-gray-700 px-2 py-3 rounded-md">
                            <div :class="[
                                showSideMenu
                                    ? 'space-x-3'
        : 'w-full text-sm',
                            ]">
                                <i :class="item.icon"></i>
                                <span v-if="showSideMenu" class="text-xs">{{ item.name }}</span>
                            </div>
                            <i v-if="dropdownIcon" class="fa-solid fa-angle-down"
                                :class="[showSideMenu ? 'mr-2' : 'text-xs']"></i>
                            <i class="fa-solid fa-angle-left" :class="[showSideMenu ? 'mr-2' : 'text-xs']"></i>
                        </div>
                        submenus
                        <ul v-if="item.dropmenu && openTitles.includes(index)" :class="[
                            showSideMenu ? 'mt-1 pt-1 ml-4' : 'mx-auto',
                        ]">
                            <li v-for="(sub, subIndex) in item.submenu" :key="subIndex" class="" :class="{
                                'border-l-4 text-orange-400 border-blue-500 bg-indigo-300/50 dark:bg-gray-700 rounded-lg':
                                    page.url === sub.suburl,
                            }">
                                <Link v-if="!sub.dropmenu && sub.show" :href="sub.suburl"
                                    class="hover:bg-indigo-300/50 dark:hover:bg-gray-700 hover:text-orange-400 flex px-2 py-3 items-center space-x-3 rounded-md">
                                <i :class="sub.subicon"></i>
                                <span v-if="showSideMenu" class="text-xs">{{
                                    sub.subname
                                }}</span>
                                </Link>
                                <div v-show="sub.show" v-else @click="toggleSubTitle(subIndex)"
                                    class="hover:bg-indigo-300/50 dark:hover:bg-gray-700 hover:text-orange-400 flex items-center justify-between px-2 py-3 rounded-md">
                                    <div class="space-x-3 hover:text-orange-400">
                                        <i :class="sub.subicon"></i>
                                        <span v-if="showSideMenu">{{
                                            sub.subname
                                        }}</span>
                                    </div>
                                    <i class="fa-solid fa-angle-left" :class="[
                                        showSideMenu ? 'mr-3' : 'text-xs',
                                    ]"></i>
                                </div>
                                minimenus
                                <ul v-if="
                                    sub.dropmenu &&
                                    openSubTitles.includes(subIndex)
                                " class="mt-1">
                                    <li v-show="min.show" v-for="(min, index) in sub.minimenu" :key="index"
                                        class="px-2 py-3 hover:bg-indigo-300/50 dark:hover:bg-gray-700 hover:text-orange-400 rounded-md"
                                        :class="{
                                            'border-l-4 text-orange-400 border-blue-500 bg-indigo-300/50 dark:bg-gray-700 rounded-lg':
                                                page.url === min.miniurl,
                                        }">
                                        <Link :href="min.miniurl" class="space-x-3">
                                        <i :class="min.minicon"></i>
                                        <span v-if="showSideMenu">{{
                                            min.mininame
                                        }}</span>
                                        </Link>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </aside>-->

        <!--Content section-->
        <section
            class="flex-1 overflow-y-auto overflow-x-hidden scrollbar-thin"
        >
            <!--header start-
            <header
                class="h-14 shadow-md flex items-center md:justify-between justify-evenly sticky text-slate-500 bg-gray-200 dark:bg-gray-900 dark:text-slate-300 top-0 z-50 inset-0">
               ompany name section
                <div class="flex w-4/5 md:w-auto items-center justify-start md:space-x-8">
                    <button @click="sideMenu()" type="button"
                        class="p-2 hidden md:block text-indigo-800 dark:text-cyan-300 text-lg px-4 dark:bg-inherit font-extralight rounded-lg">
                        <i class="fa-solid fa-bars-staggered"></i>
                    </button>
                    <button @click="openSideMenu()" type="button"
                        class="p-2 md:hidden mx-4 text-lg text-blue-400 font-extralight rounded-lg">
                        <i class="fa-solid fa-bars-staggered"></i>
                    </button>
                    <div class="flex flex-1 items-center justify-start text-xs truncate">
                        <h1 class="font-semibold md:text-slate-500 dark:text-slate-300 text-slate-800">
                            {{ page.props.auth.company.name }}
                        </h1>
                        &nbsp; <i class="font-semibold text-lg">~</i>&nbsp;
                        <h2 class="uppercase">
                            {{
                                page.props.auth.branch.name
                                    ? page.props.auth.branch.name
                                    : "Main branch"
                            }}
                        </h2>
                    </div>
                </div>
               user dropdown section
                <div class="md:mr-3 mr-2 right-0 relative text-slate-500 dark:text-slate-300">
                    <button type="button" @click="showUserMenu" class="flex items-center w-32 justify-evenly text-xs">
                        <div class="flex items-center justify-start w-auto">
                            <div class="rounded-full border bg-inherit h-8">
                                <i class="fa-regular fa-user text-sm"></i>
                                <img :src="`/storage/Images/man.png`" alt="user" class="h-full w-full" />
                            </div>
                        </div>
                        <div class="w-full flex-1 flex items-center justify-start space-x-1">
                            <i v-if="userMenu" class="fa-solid fa-angle-up text-slate-500 text-xs"></i>
                            <i v-else class="fa-solid fa-angle-down text-slate-500 text-xs"></i>
                            <div class="text-left w-full p-0 text-ellipsis">
                                <p class="font-semibold uppercase hidden md:block">
                                    {{ page.props.auth.user.username }}
                                </p>
                                <p class="hidden md:block truncate overflow-hidden text-ellipsis max-w-20">
                                    {{ page.props.auth.user.email }}
                                </p>
                            </div>
                        </div>
                    </button>
                </div>
                <Teleport to="body">
                    <div v-show="userMenu" @click.self="closeUserMenu"
                        class="w-full min-h-screen z-9999 inset-0 absolute backdrop-brightness-95 select-none">
                        <Transition appear name="bounce"
                            enter-active-class="animate__animated animate__bounceIn animate__faster"
                            leave-active-class="animate__animated animate__bounceOut animate__faster">
                            <div @click.stop
                                class="absolute bg-slate-50 dark:bg-gray-800 text-xs shadow-xl shadow-gray-600 text-slate-700 dark:text-slate-300 flex items-center justify-center w-44 top-14 rounded-lg right-5 md:right-7">
                                <ul class="p-2 mx-1 w-full space-y-2">
                                    <li class="p-2">
                                        <h1 class="uppercase">
                                            {{ page.props.auth.user.name }}
                                        </h1>
                                        <p class="text-xs overflow-clip">
                                            {{ page.props.auth.user.email }}
                                        </p>
                                    </li>
                                    <hr />
                                    <li class="p-1 hover:bg-indigo-400/20 rounded-md">
                                        <Link @click="closeUserMenu" :href="`/user/profile/${page.props.auth.user.id}`"
                                            class="flex items-center space-x-2 capitalize">
                                        <i class="fa-solid fa-user-doctor"></i>
                                        <span>My profile</span>
                                        </Link>
                                    </li>
                                    <li class="p-1 hover:bg-indigo-400/20 rounded-md">
                                        <Link @click="closeUserMenu" href="/#"
                                            class="flex items-center space-x-2 capitalize">
                                        <i class="fa-solid fa-id-card"></i>
                                        <span>My points</span>
                                        </Link>
                                    </li>
                                    <li class="p-1 hover:bg-indigo-400/20 rounded-md">
                                        <button @click="toggleDarkMode" class="h-6 w-6">
                                            <div
                                                class="dark:hidden space-x-2 h-full w-full flex items-center justify-between text-nowrap">
                                                <i class="fa-regular fa-moon text-xl text-violet-600"></i>
                                                <span class="text-violet-600">Dark mode</span>
                                            </div>
                                            <div
                                                class="dark:flex hidden space-x-1 h-full w-full items-center justify-between text-nowrap">
                                                <i class="fa-regular fa-sun text-xl text-yellow-500"></i>
                                                <span class="text-yellow-300">Light mode</span>
                                            </div>
                                        </button>
                                    </li>
                                    <hr />
                                    <li class="px-1 py-2 hover:bg-indigo-500/20 rounded-md">
                                        <Link href="/logout" class="flex items-center space-x-2">
                                        <i class="fa-solid fa-arrow-right-from-bracket"></i>
                                        <span>Sign out</span>
                                        </Link>
                                    </li>
                                </ul>
                            </div>
                        </Transition>
                    </div>
                </Teleport>
            </header>
            header end-->
            <main
                class="mx-auto md:text-sm scrollbar-thin pb-14 md:pb-2 bg-gray-100 dark:bg-linear-to-tr dark:from-gray-950 dark:to-gray-900 dark:via-gray-700 dark:text-slate-300 min-h-screen py-2"
            >
                <Loader :show="isLoading" />
                <FlashMessage />
                <slot />
            </main>
            <hr />
            <!--footer start-->
            <footer
                class="bg-gray-100 dark:bg-linear-to-tr dark:from-gray-950 dark:to-gray-900 dark:via-gray-700 dark:text-slate-300"
            >
                <!--copy right section-->
                <div class="flex items-center justify-center p-3 bottom-0">
                    <h2 class="text-xs text-slate-400">
                        Copyright&nbsp;&#169;&nbsp;2025
                        <span class="text-slate-500"
                            >Smartworks Trading Co. Ltd</span
                        >. All rights reserved.
                    </h2>
                </div>
            </footer>
            <!--footer end-->
        </section>
    </AppShell>
</template>
