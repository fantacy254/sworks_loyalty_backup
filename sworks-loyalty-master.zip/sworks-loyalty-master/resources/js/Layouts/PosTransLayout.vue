<script setup>
import { computed } from "vue";
import TransListingLayout from "./TransListingLayout.vue";
import { usePage } from "@inertiajs/vue3";
import { decryptParams, encryptParams } from "@/utlis/EncryptKey";
import { route } from "ziggy-js";

const page = usePage();

const ltyp = [
    {
        title: "Caps listing",
        icon: "fa-solid fa-file-signature",
        description: "Short term credits",
        module: "caps",
    },
    {
        title: "Customer deposits",
        icon: "fa-solid fa-users-rays",
        description: "Customer deposits made",
        module: "deposits",
    },
    {
        title: "credit notes",
        icon: "fa-solid fa-kaaba",
        description: "Sales return notes",
        module: "cnotes",
    },
    {
        title: "visa card",
        icon: "fa-solid fa-money-bill-1-wave",
        description: "Debit/Visa card sales listing",
        module: "cards",
    },
    {
        title: "Discount sales",
        icon: "fa-solid fa-handshake-angle",
        description: "Discounted sales",
        module: "discount",
    },
    {
        title: "gift vouchers",
        icon: "fa-solid fa-gifts",
        description: "Gift vouchers listing",
        module: "gifts",
    },
    {
        title: "loyalty vouchers",
        icon: "fa-solid fa-elevator",
        description: "Loyalty voucher listing",
        module: "loyalty",
    },
];

const urlMd = computed(() => {
    const url = page.url;
    const pt = url.includes("?md=") ? url.split("?md=")[1] : null;
    return pt ? decryptParams(decodeURIComponent(pt)) : null;
});
</script>
<template>
    <trans-listing-layout>
        <!--navbar section-->
        <section
            class="flex shrink flex-1 items-center justify-start space-x-2"
        >
            <Link
                :href="
                    route('pos.listing.home', {
                        md: encryptParams(item.module),
                    })
                "
                v-for="(item, index) in ltyp"
                :key="index"
                :title="item.description"
                :class="{
                    'text-violet-900 bg-violet-600/40 border-violet-400':
                        urlMd === item.module,
                }"
                class="flex items-center group cursor-pointer text-slate-400 justify-center space-x-2 border border-violet-200 hover:border-violet-300 hover:bg-white rounded-md p-2"
            >
                <i
                    :class="`${item.icon} text-xl  group-hover:text-violet-300`"
                ></i>
                <h1
                    class="group-hover:text-violet-500 capitalize font-normal text-xs"
                >
                    {{ item.title }}
                </h1>
            </Link>
        </section>
        <!--content section-->
        <main>
            <slot />
        </main>
    </trans-listing-layout>
</template>
