export const stTypes = [
    { type: "ADJ", name: "Stock Adjustments" },
    { type: "DEL", name: "Delivery Note Sales" },
    { type: "EXP", name: "Shop Expenses" },
    { type: "JOB", name: "Job Card Sales" },
    { type: "REC", name: "Goods Receivables" },
    { type: "SEL", name: "General Sales" },
    { type: "TRF", name: "Stock Transfers" },
];
export default { stTypes };
