import CryptoJS from "crypto-js";

const secretKey =
    "6842c07df73441897ba0f3f851d06e26a1c08c8cc60b636936664aaed6474fc6";

export function encryptParams(params) {
    const stringifiedParams = JSON.stringify(params);
    const encryptedParams = CryptoJS.AES.encrypt(
        stringifiedParams,
        secretKey,
    ).toString();
    return encryptedParams;
}

export function decryptParams(params) {
    const decryptedBytes = CryptoJS.AES.decrypt(params, secretKey);
    const decryptedString = decryptedBytes.toString(CryptoJS.enc.Utf8);
    return JSON.parse(decryptedString);
}

export default { encryptParams, decryptParams };
