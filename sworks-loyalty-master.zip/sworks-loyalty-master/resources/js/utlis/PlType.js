export const plTypes = [
    { type: "REC", name: "Receipts " },
    { type: "JNL", name: "Journal" },
    { type: "INV", name: "Invoices" },
    { type: "PAY", name: "Payments" },
    { type: "WTX", name: "Witholding" },
];
export default { plTypes };
