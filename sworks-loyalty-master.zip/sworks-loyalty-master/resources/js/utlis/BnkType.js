export const bnkTyps = [
    { code: "EQTY", name: "EQUITY " },
    { code: "KCB", name: "KCB" },
    { code: "COORP", name: "CO-ORPERATIVE" },
    { code: "ABSA", name: "ABSA" },
];
export default { bnkTyps };
