export const transMenu = [
    { title: "Creditors (Suppliers)", ledger: "pl" },
    { title: "Debtors (Customer)", ledger: "sl" },
];
export default { transMenu };
