export const PopType = [
    { type: "POP", name: "Purchase Orders" },
    { type: "DRQ", name: "Distribution Requests" },
    { type: "IRQ", name: "Internal Requestions" },
    { type: "JOB", name: "Job Card Requisition" },
    { type: "GRN", name: "Receivable Drafts" },
];

export default { PopType };
