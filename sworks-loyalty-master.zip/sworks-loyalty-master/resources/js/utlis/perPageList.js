import { reactive } from "vue";

export const entry = reactive([
    { name: "5", value: 5 },
    { name: "10", value: 10 },
    { name: "15", value: 15 },
    { name: "25", value: 25 },
    { name: "50", value: 50 },
    { name: "100", value: 100 },
]);

export default entry;
