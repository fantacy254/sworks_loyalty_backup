export const transMenu = [
    { title: "Inventory", ledger: "inventory" },
    { title: "POP", ledger: "pop" },
    { title: "Creditors (Suppliers)", ledger: "purchases" },
    { title: "Debtors (Customer)", ledger: "sales" },
    { title: "POS (Point Of Sale)", ledger: "pos", led: "caps" },
];
export default { transMenu };
