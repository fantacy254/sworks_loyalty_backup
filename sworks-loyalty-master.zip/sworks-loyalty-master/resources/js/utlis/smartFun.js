import { computed } from "vue";

export const computedAmount = (amt) => {
    if (!amt) return 0.0;
    return parseFloat(amt).toLocaleString("en-NG", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    });
};

export const computedDate = (date) => {
    if (!date) return "";
    return new Date(date)
        .toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
        })
        .replace(/\//g, "-");
};

export const computedTimeDate = (date) => {
    if (!date) return "";
    return new Date(date)
        .toLocaleString("en-GB", {
            day: "2-digit",
            month: "2-digit",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
            hour12: false,
        })
        .replace(/\//g, "-")
        .replace(",", "");
};

export const computedNamedDate = (dateString) => {
    if (!dateString) return "";

    // Ensure we’re working with a Date object
    let date;
    if (typeof dateString === "string") {
        // Normalize "YYYY-MM-DD HH:mm:ss" → "YYYY-MM-DDTHH:mm:ss"
        date = new Date(dateString.replace(" ", "T"));
    } else if (dateString instanceof Date) {
        date = dateString;
    } else {
        // Fallback for timestamps or other types
        date = new Date(dateString);
    }

    if (isNaN(date)) return "";

    //const date = new Date(dateString.replace(' ', 'T')); // Convert to ISO format

    const day = date.getDate();
    const daySuffix = ((d) => {
        if (d > 3 && d < 21) return "th";
        switch (d % 10) {
            case 1:
                return "st";
            case 2:
                return "nd";
            case 3:
                return "rd";
            default:
                return "th";
        }
    })(day);

    const monthShort = date.toLocaleString("en-US", { month: "short" });
    const year = date.getFullYear();

    let hours = date.getHours();
    const minutes = date.getMinutes().toString().padStart(2, "0");
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12 || 12; // convert 0 -> 12

    return `${day}${daySuffix} ${monthShort} ${year} ${hours}:${minutes} ${ampm}`;
};

export const computedShortNamedDate = (dateString) => {
    if (!dateString) return "";

    // Ensure we’re working with a Date object
    let date;
    if (typeof dateString === "string") {
        // Normalize "YYYY-MM-DD HH:mm:ss" → "YYYY-MM-DDTHH:mm:ss"
        date = new Date(dateString.replace(" ", "T"));
    } else if (dateString instanceof Date) {
        date = dateString;
    } else {
        // Fallback for timestamps or other types
        date = new Date(dateString);
    }

    if (isNaN(date)) return "";

    //const date = new Date(dateString.replace(' ', 'T')); // Convert to ISO format

    const day = date.getDate();
    const daySuffix = ((d) => {
        if (d > 3 && d < 21) return "th";
        switch (d % 10) {
            case 1:
                return "st";
            case 2:
                return "nd";
            case 3:
                return "rd";
            default:
                return "th";
        }
    })(day);

    const monthShort = date.toLocaleString("en-US", { month: "short" });
    const year = date.getFullYear();

    let hours = date.getHours();
    const minutes = date.getMinutes().toString().padStart(2, "0");
    const ampm = hours >= 12 ? "PM" : "AM";
    hours = hours % 12 || 12; // convert 0 -> 12

    return `${day}${daySuffix} ${monthShort} ${year}`;
};

// Utility functions
export const formatDateTime = (date, hours = null, minutes = null) => {
    if (!date) return null;

    const d = new Date(date);

    // If hours provided → use them
    if (hours !== null && minutes !== null) {
        d.setHours(hours, minutes, 0);
    }

    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    const hh = String(d.getHours()).padStart(2, "0");
    const min = String(d.getMinutes()).padStart(2, "0");
    const ss = "00";

    return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
};

export function formatDate(date) {
    if (!date) return

    const d = new Date(date);
    
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

export const convertToNumber = (strng) => {
    if (!strng) return 0;
    return Number(strng.replace(/,/g, "") || 0);
};

export function getRandomColor() {
    const letters = "0123456789ABCDEF";

    let color = "#";
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

  export const getFirstDay = computed(() => {
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 2);

        return firstDay.toISOString().slice(0, 10);
    });

    export const getLastDay = computed(() => {
        const today = new Date();
        const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        let localDate = lastDay.toLocaleDateString("en-CA");

        return localDate;
    });

export default {
    computedAmount,
    computedDate,
    computedTimeDate,
    computedNamedDate,
    computedShortNamedDate,
    formatDateTime,
    convertToNumber,
    getFirstDay,
    getLastDay,
    getRandomColor
};
