export const slTypes = [
    { type: "REC", name: "Receipts " },
    { type: "ADJ", name: "Adjustments" },
    { type: "INV", name: "Invoices" },
    { type: "SLP", name: "Payment Slips" },
    { type: "WTX", name: "Witholding" },
];
export default { slTypes };
