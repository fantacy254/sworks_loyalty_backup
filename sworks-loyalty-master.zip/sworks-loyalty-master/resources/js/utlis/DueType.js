export const dueType = [{ type: "INV", name: "TAX Invoices " }];
export default { dueType };
