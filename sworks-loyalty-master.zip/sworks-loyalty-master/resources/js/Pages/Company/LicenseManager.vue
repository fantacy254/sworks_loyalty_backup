<script></script>
<template>
    <Head title="License Manager" />
    <main
        class="bg-slate-100 dark:bg-gray-800 min-h-screen relative select-none text-sm"
    >
        <!--header section-->
        TEST
    </main>
</template>
