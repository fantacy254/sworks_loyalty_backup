<script setup>
import MasterLayout from "@/Layouts/MasterLayout.vue";

defineOptions({
    layout: MasterLayout,
});
</script>
<template>
    <Head title="Master Dashboard" />
    <div>
        <h1 class="text-2xl font-bold mb-4">Master Dashboard</h1>
        <p class="">
            Welcome to the Master Dashboard. Here you can manage your company
            and view analytics.
        </p>
    </div>
</template>
