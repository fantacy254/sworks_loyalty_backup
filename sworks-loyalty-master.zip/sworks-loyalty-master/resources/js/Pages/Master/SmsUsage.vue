<script setup>
    import MasterLayout from "@/Layouts/MasterLayout.vue";
    import PageTitle from "@/Components/PageTitle.vue";
    import SmartTable from "@/Components/SmartTable.vue";
    import { computed, onMounted, ref, watch } from "vue";
    import { usePage } from "@inertiajs/vue3";

    defineOptions({
        layout: MasterLayout,
    });

    const page = usePage();
    const title = 'SMS Usage';

    defineProps({
        companies: []
    })

    const from = ref(null);
    const to = ref(null);

    const getFirstDay = computed(() => {
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 2);

        return firstDay.toISOString().slice(0, 10);
    });

    const getLastDay = computed(() => {
        const today = new Date();
        //const lastDay = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        let localDate = today.toLocaleDateString("en-CA");

        return localDate;
    });

    const data = ref([])
    const loading = ref(false);

    async function loadTrans() {
        loading.value = true;
        await axios
            .get('/company/sms-usage-trans', {
                params: {
                    from: from.value,
                    to: to.value,
                },
            })
            .then((res) => {
                //console.log(res)
                loading.value = false;
                data.value = res.data;
            })
            .catch((err) => {
                //console.log(err)
                loading.value = false;
                page.props.flash.error = err.response.data;
            });
    }

    const headers = computed(() => {
        return Object.keys(data.value[0] || {})
            .filter((key) => key !== 'sender' && key !== 'company_id')
            .map((key) => ({
                dbName: key,
                name: key
                    .split("_")
                    .map(
                        (word) =>
                            word.charAt(0).toLocaleUpperCase() + word.slice(1),
                    )
                    .join(" "),
            }));
    });

    const currentCompany = ref(0)
    const filteredData = computed(() => {
        return currentCompany.value === 0
            ? data.value
            : data.value.filter((trans) => {
                return trans.company_id && parseFloat(currentCompany.value) === parseFloat(trans.company_id)
        })
    })

    onMounted(() => {
        from.value = getFirstDay.value;
        to.value = getLastDay.value;
        loadTrans()
    });

    watch([from, to], () => {
        loadTrans()
    })

</script>
<template>

    <Head :title="title" />
    <PageTitle :title="title" />
    <!--filter section-->
    <div class="grid grid-cols-3 gap-2 p-4">
        <!--date section-->
        <div class="flex items-center justify-start gap-2">
            <text-input label="From" must v-model="from" type="date" id="from" required />
            <text-input label="To" v-model="to" type="date" id="to" required must />
        </div>
        <!--companies-->
        <div class="flex items-end justify-end ">
            <select-input v-model="currentCompany" label="Company" id="comapnies"
                class="text-xs w-full md:w-fit capitalize">
               <option :value="0" selected>All</option>
                <option v-for="(cp, index) in companies" :key="index" :value="cp.id" select-inputed="10"
                    class="p-2">
                    {{ cp.name }}
                </option>
           </select-input>
        </div>
        <!--refreh btn-->
        <div class="flex items-center justify-end">
            <primary-button :loading="loading" @click="loadTrans()" name="Refresh" type="submit" />
        </div>
    </div>
    <hr />
    <!--table section-->
    <div class="pb-10">
        <smart-table :data="filteredData" :headers="headers" message="No records found" />
    </div>
</template>