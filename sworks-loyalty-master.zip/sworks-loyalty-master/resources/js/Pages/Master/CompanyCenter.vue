<script setup>
import MasterLayout from "@/Layouts/MasterLayout.vue";
import PageTitle from "@/Components/PageTitle.vue";
import SmartTable from "@/Components/SmartTable.vue";
import { computed, ref } from "vue";
import CompanyForm from "@/Components/CompanyForm.vue";
import BranchForm from "@/Components/BranchForm.vue";
import AdminForm from "@/Components/AdminForm.vue";

defineOptions({
    layout: MasterLayout,
});

const props = defineProps({
    companies: {
        type: Array,
        required: true,
        default: () => [],
    },
});

const title = "Company Center";
const addCompany = ref(false);
const addBranch = ref(false);
const addAdmin = ref(false);

const headers = computed(() => {
    return Object.keys(props.companies[0] || {})
        .filter((key) => key !== "id" && key !== "db")
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});
</script>
<template>
    <Head :title="title" />
    <PageTitle :title="title" />
    <!--add company-->
    <div class="w-full transition-all ease-linear duration-300 space-y-2">
        <!--button-->
        <div
            class="flex items-center space-x-1 md:space-x-2 overflow-auto no-scrollbar scroll-smooth w-full p-1"
        >
            <button
                type="button"
                @click="addCompany = !addCompany"
                :class="{ 'bg-blue-600 text-white': addCompany }"
                class="text-xs border dark:border-gray-500 rounded-md p-2 text-nowrap"
            >
                <i class="fas fa-plus"></i>
                <span class="ml-1">Add Company</span>
            </button>
            <button
                type="button"
                @click="addBranch = !addBranch"
                :class="{ 'bg-blue-600 text-white': addBranch }"
                class="text-xs border dark:border-gray-500 rounded-md p-2 text-nowrap"
            >
                <i class="fas fa-plus"></i>
                <span class="ml-1">Add Branches</span>
            </button>
            <button
                type="button"
                @click="addAdmin = !addAdmin"
                :class="{ 'bg-blue-600 text-white': addAdmin }"
                class="text-xs border dark:border-gray-500 rounded-md p-2 text-nowrap"
                title="Add Company admin"
            >
                <i class="fas fa-user"></i>
                <span class="ml-1">Add Company Admin</span>
            </button>
        </div>
        <!--company form-->
        <div
            v-if="addCompany"
            class="border border-gray-100 rounded-md shadow-lg"
        >
            <CompanyForm />
        </div>
        <!--branch form-->
        <div
            v-if="addBranch"
            class="border border-gray-100 rounded-md shadow-lg"
        >
            <BranchForm :companies="companies" />
        </div>
        <!--user admin form-->
        <div
            v-if="addAdmin"
            class="border border-gray-100 rounded-md shadow-lg"
        >
            <AdminForm :companies="companies" />
        </div>
    </div>
    <!--table section-->
    <div class="mt-4 p-2">
        <SmartTable :data="companies" :headers="headers" />
    </div>
</template>
