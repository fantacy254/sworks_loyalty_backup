<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SettingsLayout from "@/Layouts/SettingsLayout.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { updateAppearance, appearance } from "@/utlis/theme";
import { watch } from "vue";

defineOptions({
    layout: Layout,
});

watch(
    appearance,
    (newVal) => {
        if (newVal) {
            updateAppearance(newVal);
        }
    },
    { immediate: true },
);
</script>
<template>
    <Head title="General Settings" />
    <SettingsLayout>
        <!--section header-->
        <PageTitle title="General" />
        <hr />
        <PageTitle
            title="Appearance"
            description="Update your account's appearance settings"
        />
        <ul class="select-none grid w-fit gap-2 grid-cols-3 pt-3">
            <li>
                <input
                    type="radio"
                    id="system"
                    value="system"
                    v-model="appearance"
                    name="app-theme"
                    class="hidden peer"
                    required=""
                    checked
                />
                <label
                    for="system"
                    class="inline-flex text-black bg-linear-to-br from-white via-gray-200 to-black border items-center justify-center w-full p-2 text-sm text-center rounded-md cursor-pointer peer-checked:hover:bg-brand-softer peer-checked:border-brand-subtle peer-checked:bg-brand-softer hover:bg-neutral-secondary-medium peer-checked:text-fg-brand-strong"
                >
                    System
                </label>
            </li>
            <li>
                <input
                    type="radio"
                    id="dark"
                    value="dark"
                    v-model="appearance"
                    name="app-theme"
                    class="hidden peer"
                />
                <label
                    for="dark"
                    class="inline-flex border bg-black text-white items-center justify-center w-full p-2 text-sm text-center rounded-md cursor-pointer peer-checked:hover:bg-brand-softer peer-checked:border-brand-subtle peer-checked:bg-brand-softer hover:bg-neutral-secondary-medium peer-checked:text-fg-brand-strong"
                >
                    Dark
                </label>
            </li>
            <li>
                <input
                    type="radio"
                    id="light"
                    value="light"
                    v-model="appearance"
                    name="app-theme"
                    class="hidden peer"
                />
                <label
                    for="light"
                    class="inline-flex dark:bg-white dark:text-black border items-center justify-center w-full p-2 text-sm text-center rounded-md cursor-pointer peer-checked:hover:bg-brand-softer peer-checked:border-brand-subtle peer-checked:bg-brand-softer hover:bg-neutral-secondary-medium peer-checked:text-fg-brand-strong"
                >
                    Light
                </label>
            </li>
        </ul>
    </SettingsLayout>
</template>
