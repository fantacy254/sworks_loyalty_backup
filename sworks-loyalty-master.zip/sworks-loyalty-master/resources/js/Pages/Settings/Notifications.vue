<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SettingsLayout from "@/Layouts/SettingsLayout.vue";
import PageTitle from "@/Components/PageTitle.vue";
import axios from "axios";
import { usePage, Form } from "@inertiajs/vue3";
import { onMounted, ref } from "vue";

defineOptions({
    layout: Layout,
});

const page = usePage();
const canSms = ref(0);
const canEmail = ref(0);
const sender = ref("");

async function getNotifySetting() {
    const res = await axios
        .get("/settings/notifications/show")
        .catch((e) => console.log(e.message));
    console.log(res);
    if (!res.data && res.data.length === 0) return;

    canSms.value = res.data[0].send_sms;
    canEmail.value = res.data[0].send_email;
    sender.value = res.data[0].sender_id;
}

async function updateNotifySetting(name, val) {
    console.log(name, val);

    const res = await axios
        .post("/settings/notifications", { type: name, value: val })
        .catch((e) => console.log(e.message));

    if (res.data === "Success") {
        page.props.flash.success = "Notification updated successfully";
    } else {
        page.props.flash.error = "Error updating notification";
        await getNotifySetting();
    }
}

const isEditing = ref(false);
const toggleEdit = () => {
    isEditing.value = !isEditing.value;
};

onMounted(() => {
    getNotifySetting();
});
</script>
<template>
    <Head title="Notifications Settings" />
    <SettingsLayout>
        <!--section header-->
        <PageTitle
            title="Notifications"
            description="Update your account's notifications settings"
        />
        <hr />
        <div class="p-2 md:w-96 w-full space-y-5">
            <div>
                <h1 class="text-lg font-medium">SMS</h1>
                <div class="flex items-center">
                    <label for="sms" class="text-sm flex-1"
                        >Allow SMS Notifications</label
                    >
                    <select
                        v-model="canSms"
                        @change="
                            updateNotifySetting(
                                $event.target.name,
                                $event.target.value,
                            )
                        "
                        name="send_sms"
                        id="sms"
                        class="rounded-md border-b-2 appearance-none text-xs py-1.5 outline-none ring-0 bg-inherit"
                    >
                        <option :value="1">YES</option>
                        <option :value="0">NO</option>
                    </select>
                </div>
            </div>
            <Form
                v-if="canSms"
                action="/settings/notifications/sender"
                method="POST"
                class="flex items-center space-x-4"
                v-slot="{ errors, processing }"
            >
                <text-input
                    type="text"
                    label="SMS Sender name"
                    name="sender"
                    v-model="sender"
                    :error="errors?.sender"
                    placeholder="TextMe"
                    autofocus
                    :disabled="!isEditing"
                    required
                />
                <div v-if="isEditing" class="flex items-center space-x-2">
                    <button
                        type="button"
                        title="Cancel edit"
                        class="btn text-lg text-red-500 hover:text-red-700"
                        @click="toggleEdit()"
                    >
                        <i class="fa-regular fa-circle-xmark"></i>
                    </button>
                    <button
                        type="submit"
                        title="Save changes"
                        class="btn text-green-600 text-lg"
                        :disabled="processing"
                    >
                        <i class="fa-regular fa-circle-check"></i>
                    </button>
                </div>
                <button
                    v-else
                    type="button"
                    title="Edit name"
                    class="btn text-lg text-blue-500 hover:text-blue-700"
                    @click="toggleEdit()"
                >
                    <i class="fa-regular fa-pen-to-square"></i>
                </button>
            </Form>
            <div>
                <h1 class="text-lg font-medium">Email</h1>
                <div class="flex items-center">
                    <label for="email" class="text-sm flex-1"
                        >Allow Email Notifications</label
                    >
                    <select
                        v-model="canEmail"
                        @change="
                            updateNotifySetting(
                                $event.target.name,
                                $event.target.value,
                            )
                        "
                        name="send_email"
                        id="email"
                        class="rounded-md border-b-2 appearance-none text-xs py-1.5 outline-none ring-0 bg-inherit"
                    >
                        <option :value="1">YES</option>
                        <option :value="0">NO</option>
                    </select>
                </div>
            </div>
        </div>
    </SettingsLayout>
</template>
