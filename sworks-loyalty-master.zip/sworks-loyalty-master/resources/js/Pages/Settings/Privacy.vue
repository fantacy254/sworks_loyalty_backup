<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SettingsLayout from "@/Layouts/SettingsLayout.vue";
import PageTitle from "@/Components/PageTitle.vue";
import axios from "axios";
import { usePage } from "@inertiajs/vue3";
import { onMounted, ref } from "vue";

defineOptions({
    layout: Layout,
});

const page = usePage();
const hasTwoFactor = ref(false);
const hasAuthText = ref(false);
const hasAuthEmail = ref(false);

async function getAuthPrivacy() {
    const res = await axios
        .get("/settings/privacy/show")
        .catch((e) => console.log(e.message));

    if (!res.data) return;

    hasTwoFactor.value = res.data.two_factor === 1 ? true : false;
    hasAuthText.value = res.data.auth_sms === 1 ? true : false;
    hasAuthEmail.value = res.data.auth_email === 1 ? true : false;
}

async function authenticateApp() {
    const res = await axios
        .post("/settings/privacy/two-factor", {
            activateTwoFactor: hasTwoFactor.value,
        })
        .catch((e) => console.log(e.message));

    if (res.data === "success") {
        page.props.flash.success = "2FA activated successfully!";
    } else {
        page.props.flash.error = "2FA activation failure.";
    }
}

async function authenticateSMS() {
    const res = await axios
        .post("/settings/privacy/can-sms", {
            activateAuthText: hasAuthText.value,
        })
        .catch((e) => console.log(e.message));

    if (res.data === "success") {
        page.props.flash.success =
            "Text authentication activated successfully!";
    } else {
        page.props.flash.error = "Text authentication failure.";
    }
}

async function authenticateEmail() {
    const res = await axios
        .post("/settings/privacy/can-email", {
            activateAuthEmail: hasAuthEmail.value,
        })
        .catch((e) => console.log(e.message));

    if (res.data === "success") {
        page.props.flash.success =
            "Email authentication activated successfully!";
    } else {
        page.props.flash.error = "Email authentication failure.";
    }
}

onMounted(() => {
    getAuthPrivacy();
});
</script>
<template>
    <Head title="Privacy Settings" />
    <SettingsLayout>
        <!--section header-->
        <PageTitle
            title="Privacy"
            description="Update your account's Privacy settings"
        />
        <hr />
        <h1 class="font-lg font-semibold mb-4 mt-4">
            Multi-factor authentication (MFA)<br /><span
                class="text-xs text-gray-400 font-normal"
                >Secure your account using more than one authentication
                protocol</span
            >
        </h1>
        <div class="md:w-1/2 w-full space-y-3">
            <label
                class="inline-flex items-center me-5 cursor-pointer w-full border border-gray-100 p-3 rounded-md"
            >
                <h1 class="text-md font-medium flex-1">
                    Authenticator App<br /><span class="text-xs text-gray-500"
                        >Use one-time code fron an authenticator app.</span
                    >
                </h1>
                <input
                    type="checkbox"
                    v-model="hasTwoFactor"
                    @change="authenticateApp()"
                    name="auth_name"
                    class="sr-only peer"
                />
                <div
                    class="shrink-0 cursor-pointer relative w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-soft dark:peer-focus:ring-brand-soft rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-buffer after:content-[''] after:absolute after:top-[2px] after:inset-s-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-600 dark:peer-checked:bg-green-600"
                ></div>
            </label>
            <label
                class="inline-flex items-center me-5 cursor-pointer w-full border border-gray-100 p-3 rounded-md"
            >
                <h1 class="text-md font-medium flex-1">
                    TEXT Message<br /><span class="text-xs text-gray-500"
                        >Use one-time code fron text sms sent to your account
                        phone number.</span
                    >
                </h1>
                <input
                    type="checkbox"
                    v-model="hasAuthText"
                    @change="authenticateSMS()"
                    name="auth_sms"
                    value=""
                    class="sr-only peer"
                />
                <div
                    class="shrink-0 cursor-pointer relative w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-soft dark:peer-focus:ring-brand-soft rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-buffer after:content-[''] after:absolute after:top-[2px] after:inset-s-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-600"
                ></div>
            </label>
            <label
                class="inline-flex items-center me-5 cursor-pointer w-full border border-gray-100 p-3 rounded-md"
            >
                <h1 class="text-md font-medium flex-1">
                    Email<br /><span class="text-xs text-gray-500"
                        >Receive one-time code sent to your account email
                        account.</span
                    >
                </h1>
                <input
                    type="checkbox"
                    v-model="hasAuthEmail"
                    @change="authenticateEmail()"
                    name="auth_email"
                    value=""
                    class="sr-only peer"
                />
                <div
                    class="shrink-0 cursor-pointer relative w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-brand-soft dark:peer-focus:ring-brand-soft rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-buffer after:content-[''] after:absolute after:top-[2px] after:inset-s-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-600"
                ></div>
            </label>
        </div>
    </SettingsLayout>
</template>
