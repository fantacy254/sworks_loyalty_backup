<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { getFirstDay, getLastDay } from "@/utlis/smartFun";
import { computed, onMounted, ref, watch } from "vue";
import SmartTable from "@/Components/SmartTable.vue";
import axios from "axios";
import CrmCard from "@/Components/CrmCard.vue";
import { getRandomColor, computedAmount } from "@/utlis/smartFun";
import { Doughnut, Line } from "vue-chartjs";

import {
    Chart as ChartJS,
    Title,
    Tooltip,
    Legend,
    BarElement,
    ArcElement,
    RadialLinearScale,
    TimeScale,
    Filler,
    CategoryScale,
    LinearScale,
    LineElement,
    PointElement,
    LineController,
    BarController,
} from "chart.js";
import { usePage } from "@inertiajs/vue3";

const isDark = document.documentElement.classList.contains('dark');
const centerTextPlugin = {
    id: "centerText",
    beforeDraw(chart) {
        const { ctx, chartArea } = chart;
        const cfg = chart.options.centerText;
        if (!cfg) return;

        const x = (chartArea.left + chartArea.right) / 2;
        const y = (chartArea.top + chartArea.bottom) / 2;

        ctx.save();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        // Label (top)
        ctx.font = "600 11px sans-serif";
        ctx.fillStyle = isDark ? '#ffffff' : "#3C3939"; // gray
        ctx.fillText(cfg.label, x, y - 10);

        // Value (bottom)
        ctx.font = "bold 16px sans-serif";
        ctx.fillStyle = isDark ? '#ffffff' : "#111";
        ctx.fillText(cfg.text, x, y + 12);

        ctx.restore();
    },
};

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    BarElement,
    ArcElement,
    RadialLinearScale,
    CategoryScale,
    TimeScale,
    Filler,
    LinearScale,
    LineElement,
    LineController,
    BarController,
    PointElement,
    centerTextPlugin,
);

defineOptions({ layout: Layout })
const title = 'Outbox'
const page = usePage()

const from = ref(getFirstDay.value)
const to = ref(getLastDay.value)
const temps = ref([])
const smsType = ref('all')
const trans = ref([])

const getTemps = async () => {
    const res = await axios.get('/crm/masters/show').catch((e) => { console.log(e.message) })

    if (res.data.length === 0) return

    temps.value = res.data
}

const loading = ref(false)
const getTrans = async () => {
    loading.value = true
    const res = await axios.get('/crm/outbox/trans', {
        params: {
            from: from.value,
            to: to.value
        }
    }).catch((e) => {
        console.log(e.message)
        loading.value = false
    })

    if (res.data.length === 0) {
        loading.value = false
        return
    }

    loading.value = false
    trans.value = res.data
}

const headers = computed(() => {
    const keys = ['id', 'sms_temp', 'sender', 'updated_at', 'company_id']
    return Object.keys(trans.value[0] || {})
        .filter((key) => !keys.includes(key))
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});

const filteredTrans = computed(() => {
    return smsType.value === 'all'
        ? trans.value
        : trans.value.filter((trn) => {
            return trn.sms_temp && smsType.value.toLowerCase() === trn.sms_temp.toLowerCase()
        })
})

const computedSmsType = computed(() => {
    return Object.entries(
        trans.value.reduce((acc, record) => {
            const temp = record.sms_temp || 'unspecified';
            acc[temp] = (acc[temp] || 0) + 1;
            return acc;
        }, {})
    )
        .map(([template, count]) => ({ template, count }))
        .sort((a, b) => a.template - b.template);
})

const smsTypeName = (type) => {
    const tp = temps.value.find((ts) => type.toLowerCase() === ts.temp_id)
    if (!tp) return

    return tp.name
}

const groupedSmsInitiators = computed(() => {
    const gp = {};
    trans.value.forEach((t) => {
        gp[t.initiator] = (gp[t.initiator] || 0) + 1;
    });

    return gp; //engine:2
});

const polarData = computed(() => {
    return {
        labels: Object.keys(groupedSmsInitiators.value),
        datasets: [
            {
                data: Object.values(groupedSmsInitiators.value),
                backgroundColor: Object.keys(groupedSmsInitiators.value).map(
                    (key) => getRandomColor(),
                ),
                hoverOffset: 30,
                borderWidth: 2,
            },
        ],
    };
});

const polarOptions = computed(() => {
    return {
        responsive: true,
        cutout: "45%",
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "top",
                labels: {
                    color: isDark ? '#ffffff' : "#000",
                    font: { size: 11 },
                    generateLabels(chart) {
                        const data = chart.data;
                        const values = data.datasets[0].data;

                        return data.labels.map((label, i) => ({
                            text: `${label} - ${computedAmount(values[i]).toLocaleString()}`,
                            fillStyle: data.datasets[0].backgroundColor[i],
                            color: isDark ? '#ffffff' : "#000",
                            index: i,
                        }));
                    },
                },
            },
            title: {
                display: false,
                text: `Analysis by Initiator`,
            },
            tooltip: {
                backgroundColor: "rgba(0, 0, 0, 0.9)",
                position: "nearest",
                yAlign: "bottom",
                callbacks: {
                    label(ctx) {
                        return `${ctx.label}: ${ctx.raw.toLocaleString()}`;
                    },
                },
            },
            datalabels: {
                color: isDark ? '#ffffff' : "#000",
                font: {
                    weight: "bold",
                },
                formatter(value, ctx) {
                    const data = ctx.dataset.data;
                    const total = data.reduce((a, b) => a + b, 0);
                    return ((value / total) * 100).toFixed(0) + "%";
                },
            },
        },
        centerText: {
            label: "Total Messages",
            text: `${trans.value.length}`,
        },
    };
});

function formatDate(date) {
    return new Date(date).toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
    })
}

const sortedSms = computed(() => {
    return [...trans.value]
        .sort((a, b) =>
            a.created_at - b.created_at
        )
})

const dailySms = computed(() => {
    const grouped = {}

    sortedSms.value.forEach((txt) => {
        const date = formatDate(txt.created_at)

        grouped[date] = (grouped[date] || 0) + 1
    })

    return grouped
})

const chartData = computed(() => {

    return {
        labels: Object.keys(dailySms.value),
        datasets: [{
            type: "line",
            label: 'Text Messages',
            data: dailySms.value,
            borderColor: getRandomColor(),
            backgroundColor: '#F3F2F2',
            fill: true,
            tension: 0.1
        }],
    };
});

const chartOptions = computed(() => {
    return {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: "index",
            intersect: false,
        },
        plugins: {
            datalabels: false,
            legend: {
                position: "top",
                labels: {
                    color: isDark ? '#ffffff' : "#000",
                    font: { size: 12 }
                }
            },
            title: {
                display: false,
                text: `Loyalty analysis`,
            },
            tooltip: {
                callbacks: {
                    label(ctx) {
                        return `Total: ${computedAmount(ctx.dataset.data[ctx.label])}`;
                    },
                },
            },
        },
        scales: {
            x: {
                beginAtZero: true,
                ticks: {
                    color: isDark ? '#ffffff' : "#000"
                },
                grid: {
                    color: isDark ? '#544F4F' : '#DCDADA'
                }
            },
            y: {
                beginAtZero: true,
                grid: {
                    drawOnChartArea: true,
                    color: isDark ? '#544F4F' : '#DCDADA'
                },
                title: {
                    display: true,
                    text: "Total Messages",
                    color: isDark ? '#ffffff' : "#000"
                },
                ticks: {
                    color: isDark ? '#ffffff' : "#000"
                },
            },
        },
    };
});

const tlUsage = computed(() => {
    return page.props.auth.company.sms_rate * trans.value.length
})

onMounted(() => {
    getTemps()
    getTrans()
})

watch([from, to], () => {
    getTrans()
})


</script>
<template>

    <Head :title="title" />
    <!--Header section-->
    <PageTitle :title="title" description="View and manage sent messages." />
    <!--filter section-->
    <div class="p-2 sticky top-10 z-10">
        <!--date section-->
        <div class="flex items-end justify-end gap-2">
            <text-input label="From" must v-model="from" type="date" id="from" required />
            <text-input label="To" v-model="to" type="date" id="to" required must />
            <!--Refresh Btn-->
            <button type="button"
                class="p-2 cursor-pointer focus:border-none focus:outline-none text-amber-500 bg-white dark:bg-inherit rounded-md"
                title="Refresh" @click="getTrans()" :disabled="loading">
                <i class="fa-solid fa-arrow-rotate-right text-2xl" :class="{ 'animate-spin': loading }"></i>
            </button>
        </div>
    </div>
    <h3 class="font-medium text-lg text-gray-400">Message anlysis</h3>
    <!--summary section-->
    <div class="grid grid-cols-6 gap-4 p-2">
        <!--Sum card-->
        <CrmCard :count="trans.length" template="Total Messages" cardClass="secondary"
            :value="computedAmount(tlUsage)" />
        <!--cards-->
        <CrmCard v-for="(tmp, index) in computedSmsType" :key="index" :count="tmp.count"
            :template="smsTypeName(tmp.template) ?? `${tmp.template} Messages`" />
    </div>
    <!--graph section-->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <!--doughut chart-->
        <div class="rounded-lg w-auto shadow-md border dark:border-gray-500">
            <h1 class="capitalize font-medium text-sm p-4 text-center">
                analysis by initiator
            </h1>
            <hr class="dark:text-gray-600" />
            <div class="px-2 py-3 w-full h-full">
                <div v-if="trans.length > 0">
                    <Doughnut :data="polarData" :options="polarOptions" style="height: 400px" />
                </div>
                <div v-else
                    class="h-full text-sm min-h-80 w-full flex items-center justify-center text-slate-600 dark:text-slate-300">
                    <h1>No records</h1>
                </div>
            </div>
        </div>
        <!--line chart-->
        <div class="md:col-span-2 rounded-lg shadow-md border dark:border-gray-500">
            <h1 class="capitalize font-medium p-4 text-sm text-center">
                Daily SMS analysis
            </h1>
            <hr class="dark:text-gray-600" />
            <div class="py-3 md:px-2 ">
                <Line v-if="trans.length > 0" :data="chartData" :options="chartOptions" style="height: 400px" />
                <div v-else class="h-full w-full min-h-80 flex text-sm items-center justify-center">
                    <h1>No records</h1>
                </div>
            </div>
        </div>
    </div>
    <h3 class="font-medium text-lg text-gray-400 py-2">Transaction Listing</h3>
    <!--sms class section-->
    <div class="md:max-w-sm md:mx-auto w-full">
        <select-input label="SMS Type" v-model="smsType" required name="types" id="types" class="w-full">
            <option value="all">All</option>
            <option value="custom">Custom Messages</option>
            <option v-for="(tmp, index) in temps" :key="index" :value="tmp.temp_id" class="text-xs capitalize">
                {{ tmp.name }}
            </option>
        </select-input>
    </div>
    <!--table section-->
    <smart-table :data="filteredTrans" :headers="headers" message="No records found" />
</template>