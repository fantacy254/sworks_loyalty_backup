<script setup>
    import Layout from "@/Layouts/MainLayout.vue";
    import PageTitle from "@/Components/PageTitle.vue";
    import { onMounted, ref } from "vue";
    import axios from "axios";
    import BulkTemplate from "@/Components/BulkTemplate.vue";
    import BulkPlaceholder from "@/Components/BulkPlaceholder.vue";

    defineOptions({ layout: Layout })
    const title = 'Send Bulk SMS'

    const temps = ref([])
    const getTemps = async () => {
        const res = await axios.get('/crm/masters/show').catch((e) => { console.log(e.message) })

        if (res.data.length === 0) return

        temps.value = res.data
    }

    onMounted(() => {
        getTemps()
    })

</script>
<template>

    <Head :title="title" />
    <!--Header section-->
    <PageTitle :title="title" description="Send bulk SMS messages to your contacts." />
    <!--placeholders-->
   <BulkPlaceholder />
    <!--section-->
    <BulkTemplate :temps="temps" preview />
</template>