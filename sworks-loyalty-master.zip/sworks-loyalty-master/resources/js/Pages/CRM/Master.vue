<script setup>
    import Layout from "@/Layouts/MainLayout.vue";
    import PageTitle from "@/Components/PageTitle.vue";
    import TemplateCard from "@/Components/TemplateCard.vue";
    import { computed } from "vue";
import BulkPlaceholder from "@/Components/BulkPlaceholder.vue";

    defineOptions({ layout: Layout })
    const props = defineProps({
        templates: { type: Array, default: () => [] }
    })

    const title = 'SMS Templates'

    const isDefaultTemp = (companyId) => {
        return companyId === null || companyId === undefined ? true : false;
    }

    const defaultTemplates = computed(() => {
        return props.templates.filter(temp => temp.company_id === null || temp.company_id === undefined);
    });

    const companyTemplates = computed(() => {
        return props.templates.filter(temp => temp.company_id !== null && temp.company_id !== undefined);
    });

</script>
<template>

    <Head :title="title" />
    <!--Header section-->
    <PageTitle :title="title" description="View and manage SMS classes together with their respective templates." />
    <!--notification if the account lacks default templates-->
    <div v-if="defaultTemplates.length > 0"
        class="alert alert-warning text-sm p-4 gap-2 border rounded-2xl bg-amber-50/50 border-amber-300 text-amber-600 md:w-md w-full mx-auto flex items-center justify-center"
        role="alert">
        <i class="fa-regular fa-bell-slash text-amber-500 text-xl"></i>
        <p class="text-xs">This account is currently using default templates. To add custom templates, use below
            templates or edit thier contents.</p>
    </div>
    <!--placeholders-->
    <BulkPlaceholder />
    <!--Templates-->
    <h1 v-if="defaultTemplates.length > 0" class="font-bold text-md text-gray-400">Default Templates</h1>
    <div v-if="defaultTemplates.length > 0" class="grid md:grid-cols-4 gap-4 px-2 md:px-0 py-3 md:w-5xl md:mx-auto">
        <!--default templates-->
        <TemplateCard v-for="temp in defaultTemplates" :key="temp.temp_id" :temp="temp"
            :isDefault="isDefaultTemp(temp.company_id)" />
    </div>
    <h1 v-if="companyTemplates.length > 0" class="font-bold text-md text-gray-400">Company Templates</h1>
    <div v-if="companyTemplates.length > 0" class="grid md:grid-cols-4 gap-4 px-2 md:px-0 py-3 md:w-5xl md:mx-auto">
        <!--company templates-->
        <TemplateCard v-for="temp in companyTemplates" :key="temp.temp_id" :temp="temp"
            :isDefault="isDefaultTemp(temp.company_id)" />
    </div>
</template>