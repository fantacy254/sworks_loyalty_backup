<script></script>
<template>
    <Head title="Error" />

    <div class="flex items-center justify-center">
        <img src="\storage\Image\error.png" alt="error" />
        <p>
            No connection could be made because the target machine actively
            refused it
        </p>
    </div>
</template>
