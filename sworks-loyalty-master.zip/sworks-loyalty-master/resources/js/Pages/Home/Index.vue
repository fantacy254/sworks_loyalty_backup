<script setup>
import MainLayout from "@/Layouts/MainLayout.vue";
import axios from "axios";
import Card from "@/Components/Card.vue";
import { computed, onMounted, ref } from "vue";
import { computedAmount, formatDate } from "@/utlis/smartFun";
import PageTitle from "@/Components/PageTitle.vue";
import { Bar, Doughnut, Line } from "vue-chartjs";

import {
    Chart as ChartJS,
    Title,
    Tooltip,
    Legend,
    BarElement,
    ArcElement,
    RadialLinearScale,
    TimeScale,
    Filler,
    CategoryScale,
    LinearScale,
    LineElement,
    PointElement,
    LineController,
    BarController,
} from "chart.js";

import { watch } from "vue";
import { router, usePage } from "@inertiajs/vue3";
import SmartTable from "@/Components/SmartTable.vue";
import DashCrmCards from "@/Components/DashCrmCards.vue";
import DashCrmTrans from "@/Components/DashCrmTrans.vue";
import DashCrmMonthly from "@/Components/DashCrmMonthly.vue";
import { useEncryption } from "@/composable/useEncryption";

const isDark = document.documentElement.classList.contains("dark");
const centerTextPlugin = {
    id: "centerText",
    beforeDraw(chart) {
        const { ctx, chartArea } = chart;
        const cfg = chart.options.centerText;
        if (!cfg) return;

        const x = (chartArea.left + chartArea.right) / 2;
        const y = (chartArea.top + chartArea.bottom) / 2;

        ctx.save();
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        // Label (top)
        ctx.font = "600 11px sans-serif";
        ctx.fillStyle = isDark ? "#ffffff" : "#3C3939"; // gray
        ctx.fillText(cfg.label, x, y - 10);

        // Value (bottom)
        ctx.font = "bold 16px sans-serif";
        ctx.fillStyle = isDark ? "#ffffff" : "#111";
        ctx.fillText(cfg.text, x, y + 12);

        ctx.restore();
    },
};

ChartJS.register(
    Title,
    Tooltip,
    Legend,
    BarElement,
    ArcElement,
    RadialLinearScale,
    CategoryScale,
    TimeScale,
    Filler,
    LinearScale,
    LineElement,
    LineController,
    BarController,
    PointElement,
    centerTextPlugin,
);

defineOptions({ layout: MainLayout });
const { encryptedRoute } = useEncryption();

const page = usePage();
const title = "Dashboard";

const customers = ref([]);

const quickLinks = [
    {
        link: "/customers",
        icon: "fa-solid fa-users-viewfinder",
        name: "Loyalty customers",
    },
    {
        link: "/trans-listing",
        icon: "fa-solid fa-list-check",
        name: "Transaction Listing",
    },
    {
        link: "/points-award",
        icon: "fa-solid fa-biohazard",
        name: "points award",
    },
    {
        link: "/points-adj",
        icon: "fa-solid fa-sliders",
        name: "points adjustments",
    },
    {
        link: "/users",
        icon: "fa-solid fa-users-gear",
        name: "system users",
    },
];

const cummPoints = ref(0);
const trans = ref([]);
const computedMonths = ref([]);

const today = new Date();
const currentPeriod = computed(() => {
    const ld = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    return formatDate(ld);
});

const filterPeriod = ref(currentPeriod.value);

const firstDay = computed(() => {
    const dt = new Date(filterPeriod.value);
    const t = new Date(dt.getFullYear(), dt.getMonth(), 1);

    return t.toLocaleDateString("en-CA");
});

const lastDay = computed(() => {
    const dt = new Date(filterPeriod.value);
    const ld = new Date(dt.getFullYear(), dt.getMonth() + 1, 0);

    return ld.toLocaleDateString("en-CA");
});

const latestCustomers = computed(() => {
    return customers.value.filter((cust) => {
        const dt = new Date(cust.created_at);
        return dt >= new Date(firstDay.value) && dt <= new Date(lastDay.value);
    });
});

const typeColor = {
    "AD-": "#8207DB",
    "AD+": "#FFB93B",
    AWD: "#F6339A",
    CAN: "#FB2C36",
    CRD: "#BBF451",
    ERN: "#5EA529",
    RED: "#C81CDE",
    CUST: "#5D0EC0",
};

const tlTrans = computed(() => {
    const gp = {};
    trans.value.forEach((t) => {
        gp[t.type] = (gp[t.type] || 0) + Number(t.points);
    });

    return gp;
});

const polarData = computed(() => {
    return {
        labels: Object.keys(tlTrans.value),
        datasets: [
            {
                data: Object.values(tlTrans.value),
                backgroundColor: Object.keys(tlTrans.value).map(
                    (key) => typeColor[key],
                ),
                hoverOffset: 30,
                borderWidth: 2,
            },
        ],
    };
});

const polarOptions = computed(() => {
    return {
        responsive: true,
        cutout: "55%",
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "top",
                labels: {
                    color: isDark ? "#ffffff" : "#000",
                    font: { size: 11 },
                    generateLabels(chart) {
                        const data = chart.data;
                        const values = data.datasets[0].data;

                        return data.labels.map((label, i) => ({
                            text: `${label} (${computedAmount(values[i]).toLocaleString()})`,
                            fillStyle: data.datasets[0].backgroundColor[i],
                            color: isDark ? "#ffffff" : "#000",
                            index: i,
                        }));
                    },
                },
            },
            title: {
                display: false,
                text: `Transation Analysis`,
            },
            tooltip: {
                backgroundColor: "rgba(0, 0, 0, 0.9)",
                position: "nearest",
                yAlign: "bottom",
                callbacks: {
                    label(ctx) {
                        return `${ctx.label}: ${ctx.raw.toLocaleString()}`;
                    },
                },
            },
            datalabels: {
                color: isDark ? "#ffffff" : "#000",
                font: {
                    weight: "bold",
                },
                formatter(value, ctx) {
                    const data = ctx.dataset.data;
                    const total = data.reduce((a, b) => a + b, 0);
                    return ((value / total) * 100).toFixed(0) + "%";
                },
            },
        },
        centerText: {
            label: "Points Holding",
            text: `${totalHoldingPoints.value}`,
        },
    };
});

const chartOptions = computed(() => {
    return {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: "index",
            intersect: false,
        },
        plugins: {
            datalabels: false,
            legend: {
                position: "top",
                labels: {
                    color: isDark ? "#ffffff" : "#000",
                    font: { size: 12 },
                },
            },
            title: {
                display: false,
                text: `Loyalty analysis`,
            },
            tooltip: {
                callbacks: {
                    label(ctx) {
                        return `${ctx.dataset.label}: ${computedAmount(ctx.raw)}`;
                    },
                },
            },
        },
        scales: {
            x: {
                ticks: {
                    color: isDark ? "#ffffff" : "#000",
                },
                grid: {
                    color: isDark ? "#544F4F" : "#DCDADA",
                },
            },
            y: {
                beginAtZero: true,
                title: {
                    display: true,
                    text: "Customers",
                    color: isDark ? "#ffffff" : "#000",
                },
                ticks: {
                    color: isDark ? "#ffffff" : "#000",
                },
                grid: {
                    color: isDark ? "#544F4F" : "#DCDADA",
                },
            },
            y1: {
                beginAtZero: true,
                position: "right",
                grid: {
                    drawOnChartArea: false,
                    color: isDark ? "#544F4F" : "#DCDADA",
                },
                title: {
                    display: true,
                    text: "Transactions",
                    color: isDark ? "#ffffff" : "#000",
                },
                ticks: {
                    color: isDark ? "#ffffff" : "#000",
                },
            },
        },
    };
});

const chartData = computed(() => {
    //combaine customer creation with transactions
    //1. first, collect unique dates
    const dates = Array.from(
        new Set([
            ...latestCustomers.value.map((c) => formatDate(c.created_at)),
            ...trans.value.map((t) => t.run_date),
        ]),
    ).sort();

    // customer count per day
    const custMap = latestCustomers.value.reduce((cus, c) => {
        const date = formatDate(c.created_at);

        cus[date] = (cus[date] || 0) + 1;

        return cus;
    }, {});

    const transMap = trans.value.reduce((acc, t) => {
        const date = t.run_date;
        const type = t.type;

        // create type group
        if (!acc[type]) {
            acc[type] = {};
        }

        // sum points by date
        acc[type][date] = (acc[type][date] || 0) + Number(t.points);

        return acc;
    }, {});

    // customer bar data
    const custData = dates.map((d) => custMap[d] || 0);

    // create line datasets dynamically
    const transDatasets = Object.keys(transMap).map((type) => ({
        type: "bar",
        label: type,

        data: dates.map((date) => transMap[type][date] || 0),

        borderColor: typeColor[type] || "#000",
        backgroundColor: typeColor[type] || "#000",
        tension: 0.4,
        yAxisID: "y1",
    }));

    return {
        labels: dates.map((dt) =>
            new Date(dt).toLocaleDateString("en-US", {
                month: "short",
                day: "numeric",
            }),
        ),
        datasets: [
            {
                type: "bar",
                label: "New Customers",
                data: custData,
                backgroundColor: "#1A1DD9",
            },
            ...transDatasets,
        ],
    };
});

const totalAwardPoints = computed(() => {
    const tl =
        trans.value.length > 0
            ? trans.value
                  .filter((itm) => itm.type === "AWD")
                  .reduce((sum, val) => sum + parseFloat(val.points), 0)
            : 0;

    return computedAmount(tl);
});

const totalEarnedPoints = computed(() => {
    const tl =
        trans.value.length > 0
            ? trans.value
                  .filter((itm) => itm.type === "ERN")
                  .reduce((sum, val) => sum + parseFloat(val.points), 0)
            : 0;

    return computedAmount(tl);
});

const totalRedeemPoints = computed(() => {
    const tl =
        trans.value.length > 0
            ? trans.value
                  .filter((itm) => itm.type === "RED")
                  .reduce((sum, val) => sum + parseFloat(val.points), 0)
            : 0;

    return computedAmount(tl);
});

const totalHoldingPoints = computed(() => {
    const dt = trans.value.length > 0 ? trans.value : [];

    const inward = dt
        .filter((itm) => itm.sign === "+")
        .reduce((sum, val) => sum + parseFloat(val.points), 0);

    const outward = dt
        .filter((itm) => itm.sign === "-")
        .reduce((sum, val) => sum + parseFloat(val.points), 0);

    const bal = inward - outward;
    return computedAmount(bal);
});

const custHeaders = computed(() => {
    return Object.keys(customers.value[0] || {})
        .filter((key) => key !== "branch_id")
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});

const transHeaders = computed(() => {
    return Object.keys(trans.value[0] || {})
        .filter((key) => key !== "branch_id" && key !== "sign")
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});

async function getSummaryData() {
    await axios
        .get("/get-dashboard-data", {
            params: {
                period: filterPeriod.value,
                from: firstDay.value,
                to: lastDay.value,
            },
        })
        .then((res) => {
            trans.value = res.data[0];
            cummPoints.value = res.data[1] || 0;
        })
        .catch((error) => {
            page.props.flash.error = error.response.data;
        });
}

async function getCustomerAnalysis() {
    await axios
        .get("/dashboard/getCustomers", {
            params: {
                period: filterPeriod.value,
                from: firstDay.value,
                to: lastDay.value,
            },
        })
        .then((res) => {
            customers.value = res.data;
        })
        .catch((err) => {
            console.log(err);
        });
}

const temps = ref([]);
const smsTrans = ref([]);
const getTemps = async () => {
    const res = await axios.get("/crm/masters/show").catch((e) => {
        console.log(e.message);
    });

    if (res.data.length === 0) return;

    temps.value = res.data;
};

const getSMSTrans = async () => {
    const res = await axios
        .get("/crm/outbox/trans", {
            params: {
                from: firstDay.value,
                to: lastDay.value,
            },
        })
        .catch((e) => {
            console.log(e.message);
        });

    if (res.data.length === 0) return;

    smsTrans.value = res.data;
};

const todaysTexts = computed(() => {
    return smsTrans.value.filter((txt) => {
        return (
            new Date(txt.created_at).toLocaleDateString() ===
            new Date().toLocaleDateString()
        );
    });
});

function resetDashData() {
    trans.value = [];
    customers.value = [];
    temps.value = [];
    smsTrans.value = [];
}

const loading = ref(false);

async function refreshDashboard() {
    loading.value = true;
    // reset all previous data first
    resetDashData();

    try {
        await Promise.all([
            getSummaryData(),
            getCustomerAnalysis(),
            getTemps(),
            getSMSTrans(),
        ]);
    } catch (error) {
        console.error("refreshDashboard failed:", error);
    } finally {
        loading.value = false;
    }
}

function getMonthsLastDays() {
    const year = new Date().getFullYear();
    const months = [
        "JANUARY",
        "FEBRUARY",
        "MARCH",
        "APRIL",
        "MAY",
        "JUNE",
        "JULY",
        "AUGUST",
        "SEPTEMBER",
        "OCTOBER",
        "NOVEMBER",
        "DECEMBER",
    ];

    return months.map((month, index) => {
        const date = new Date(year, index + 1, 0);
        const lastDayString = formatDate(date);
        return { month, lastDay: lastDayString };
    });
}

async function buildSecureLink(baseRoute, params) {
    const url = params
        ? await encryptedRoute(baseRoute, params)
        : route(baseRoute);

    router.visit(url);
}

onMounted(async () => {
    await refreshDashboard();
    getMonthsLastDays();
    computedMonths.value = getMonthsLastDays();
});

watch(
    filterPeriod,
    async () => {
        await refreshDashboard();
    },
    { immediate: true },
);
</script>
<template>
    <Head>
        <title>{{ title }}</title>
        <meta
            name="description"
            content="The leading loyalty program in kenya integratable with other softwares."
        />
        <meta property="org:title" content="Smart Loyalty" />
        <meta
            property="org:description"
            content="Enjoy loyalty services with built-in CRM at an affordable price."
        />
        <meta http-equiv="X-UA-Compatible" content="IE=7" />
        <meta http-equiv="X-UA-Compatible" content="ie=edge" />
        <meta
            name="keywords"
            content="smartworks, loyalty, smart loyalty, smartpos, crm"
        />
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    </Head>
    <!--Header section-->
    <PageTitle :title="title" />
    <!--filter section-->
    <div class="p-2 flex items-center justify-end sticky top-10 z-10">
        <!--date filter section-->
        <div
            class="inline-flex items-end md:justify-end flex-col md:flex-row flex-1 md:space-x-2 space-y-2 md:space-y-0 text-xs"
        >
            <select-input
                label="Period"
                placeholder="current period"
                v-model="filterPeriod"
                class="w-full md:w-48 text-xs"
            >
                <option value="00" selected disabled>Select period</option>
                <option
                    v-for="(item, index) in computedMonths"
                    :key="index"
                    :value="item.lastDay"
                >
                    {{ item.month }}
                </option>
            </select-input>
            <text-input
                type="date"
                label="From"
                class="text-xs w-full md:w-auto"
                v-model="firstDay"
            />
            <text-input
                type="date"
                label="To"
                class="text-xs w-full md:w-auto"
                v-model="lastDay"
            />
            <button
                type="button"
                class="p-2 cursor-pointer focus:border-none focus:outline-none text-amber-500 flex items-center gap-1 text-lg md:text-2xl"
                title="Refresh"
                @click="refreshDashboard()"
                :disabled="loading"
            >
                <span class="md:hidden flex items-center">Refresh</span>
                <i
                    class="fa-solid fa-arrow-rotate-right"
                    :class="{ 'animate-spin': loading }"
                ></i>
            </button>
        </div>
    </div>
    <!--Loyalty cards-->
    <div
        class="grid md:grid-cols-5 grid-flow-row gap-2 space-y-2 md:space-y-0 md:space-x-2 px-2"
    >
        <!--customers-->
        <Card
            theme="blue"
            :amount="customers.length"
            :trend="latestCustomers.length"
            icon="fa-solid fa-users-viewfinder"
            name="customers"
            @btnClick="buildSecureLink('loyalty.index')"
        />
        <!--points holding-->
        <Card
            theme="violet"
            :amount="computedAmount(cummPoints)"
            :trend="totalHoldingPoints"
            icon="fa-solid fa-circle-dollar-to-slot"
            name="Cummulative points"
            @btnClick="buildSecureLink('customers')"
        />
        <!--Awarded points-->
        <Card
            theme="red"
            :amount="totalAwardPoints"
            :value="totalAwardValue"
            icon="fa-solid fa-medal"
            name="points awarded"
            @btnClick="buildSecureLink('trans.create', { typ: 'AWD' })"
            hasValue
        />
        <!--Earned points-->
        <Card
            theme="green"
            :amount="totalEarnedPoints"
            icon="fa-solid fa-hand-holding-dollar"
            name="points earned"
            @btnClick="buildSecureLink('trans.create', { typ: 'ERN' })"
            hasValue
        />
        <!--Redeemed points-->
        <Card
            theme="amber"
            :amount="totalRedeemPoints"
            icon="fa-solid fa-money-bill-transfer"
            name="redeemed points"
            @btnClick="buildSecureLink('trans.create', { typ: 'RED' })"
            hasValue
        />
    </div>
    <!--graph section-->
    <div
        class="grid md:grid-cols-3 grid-cols-1 gap-2 md:gap-3 md:py-6 mt-5 mb-5"
    >
        <!--bar graph-->
        <div
            class="rounded-lg md:col-span-2 shadow-md border dark:border-gray-500"
        >
            <h1 class="capitalize font-medium p-4 text-sm text-center">
                customer analysis
            </h1>
            <hr class="dark:text-gray-600" />
            <div class="py-3 md:px-2">
                <Bar
                    v-if="trans.length > 0"
                    :data="chartData"
                    :options="chartOptions"
                    style="height: 400px"
                />
                <div
                    v-else
                    class="h-full w-full min-h-80 flex text-sm items-center justify-center"
                >
                    <h1>No records</h1>
                </div>
            </div>
        </div>
        <!--doughut chart--->
        <div class="rounded-lg w-full shadow-md border dark:border-gray-500">
            <h1 class="capitalize font-medium text-sm p-4 text-center">
                transactions analysis
            </h1>
            <hr class="dark:text-gray-600" />
            <div class="px-2 py-3 w-full h-full">
                <div v-if="trans.length > 0">
                    <Doughnut
                        :data="polarData"
                        :options="polarOptions"
                        style="height: 400px"
                    />
                </div>
                <div
                    v-else
                    class="h-full text-sm min-h-80 w-full flex items-center justify-center text-slate-600 dark:text-slate-300"
                >
                    <h1>No records</h1>
                </div>
            </div>
        </div>
    </div>
    <!--Table section-->
    <div class="grid md:grid-cols-3 grid-cols-1 gap-3 w-full mb-3">
        <!--Customer listing-->
        <div class="rounded-md border dark:border-gray-500 space-y-2 p-2">
            <!--head-->
            <h1 class="text-center p-1 capitalize font-medium">
                Customer list
            </h1>
            <hr class="dark:text-gray-600" />
            <!--table-->
            <SmartTable
                :headers="custHeaders"
                :data="customers"
                message="No records found"
                :branches="page.props?.branches"
            />
        </div>
        <!--Transactions listing-->
        <div
            class="md:col-span-2 rounded-md border dark:border-gray-500 space-y-2 p-2 w-full"
        >
            <!--head-->
            <h1 class="text-center p-1 capitalize font-medium">
                Today's transactions
            </h1>
            <hr class="dark:text-gray-600" />
            <!--table-->
            <SmartTable
                :headers="transHeaders"
                :data="trans"
                message="No records found"
                :branches="page.props?.branches"
            />
        </div>
    </div>
    <!--CRM section-->
    <!--Header section-->
    <PageTitle
        title="CRM"
        description="Get an overview of daily and monthly SMS usage."
    />
    <!--CRM cards-->
    <DashCrmCards :temps="temps" :texts="smsTrans" />
    <h1 class="font-semibold p-2">Today's SMS analysis</h1>
    <!--transactional analysis-->
    <DashCrmTrans :temps="temps" :trans="todaysTexts" />
    <!--CRM monthly analysis-->
    <h1 class="font-semibold p-2">Monthly SMS analysis</h1>
    <DashCrmMonthly :trans="smsTrans" />
    <!--quick access-->
    <div class="py-6 md:px-5 px-2">
        <div class="shadow-md rounded-md border dark:border-gray-500">
            <div class="mx-3 p-2 space-x-2 flex items-center justify-start">
                <i class="fa-solid fa-bezier-curve"></i>
                <h1 class="capitalize font-medium">quick links</h1>
            </div>
            <hr class="dark:text-gray-600" />
            <div
                class="grid md:grid-cols-4 grid-cols-2 md:gap-2 md:space-y-1 md:p-4"
            >
                <div
                    v-for="(item, index) in quickLinks"
                    :key="index"
                    class="flex items-center px-2 py-2 justify-start space-x-3"
                >
                    <i :class="item.icon" class="md:text-3xl text-lg"></i>
                    <Link
                        :href="item.link"
                        class="md:text-lg lg:text-sm text-sm font-bold text-cyan-500 capitalize"
                    >
                        {{ item.name }}
                    </Link>
                </div>
            </div>
        </div>
    </div>
    <!--end of loyalty dashboard-->
</template>
