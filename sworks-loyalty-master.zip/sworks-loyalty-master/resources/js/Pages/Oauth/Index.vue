<script setup>
import MasterLayout from "@/Layouts/MasterLayout.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { Form } from "@inertiajs/vue3";
import { computed, ref } from "vue";
import { route } from "ziggy-js";
import BranchToken from "@/Components/BranchToken.vue";

defineOptions({
    layout: MasterLayout,
});
const props = defineProps({
    companies: {
        type: Array,
        required: true,
        default: () => [],
    },
});
const title = "OAuth Integration";

const company = ref(null);

const token = computed(() => {
    return props.companies.find((c) => c.id === company.value)?.token || "";
});

const branches = computed(() => {
    return props.companies.find((c) => c.id === company.value)?.branches || [];
});
</script>
<template>
    <Head :title="title" />
    <PageTitle :title="title" />
    <div class="p-2 md:w-1/2 w-full space-y-2">
        <p class="text-xs mt-2">
            Select a company to view or generate an API token.
        </p>
        <div
            class="flex items-center md:justify-evenly space-x-2 md:w-fit w-full"
        >
            <div
                class="flex flex-col md:flex-row items-center md:space-x-2 w-full"
            >
                <select-input
                    v-model="company"
                    label="Company"
                    name="company"
                    placeholder="Select Company"
                    class="w-full"
                    autofocus
                    must
                >
                    <option value="" disabled selected>Select Company</option>
                    <option
                        v-for="company in companies"
                        :key="company.id"
                        :value="company.id"
                    >
                        {{ company.name }}
                    </option>
                </select-input>
                <text-input
                    v-if="token"
                    type="text"
                    label="Token"
                    name="token"
                    placeholder="API Token"
                    class="w-full"
                    disabled
                    v-model="token"
                />
            </div>
            <Form
                v-if="!token"
                method="post"
                :action="route('oauth.generate.token', { company_id: company })"
            >
                <button
                    title="Generate Token"
                    type="submit"
                    class="mt-4 text-nowrap text-gray-500"
                    :loading="processing"
                >
                    <i class="fas fa-key"></i>
                </button>
            </Form>
        </div>
        <p class="text-xs mt-2">Company branches</p>
        <branch-token
            :company-id="company"
            v-if="branches.length > 0"
            v-for="(br, index) in branches"
            :key="index"
            :branch-id="br.id"
            :branch-name="br.name"
            :token="br.client_key"
        />
        <p v-else class="text-xs p-10 text-center">
            No branches found for this company.
        </p>
    </div>
</template>
