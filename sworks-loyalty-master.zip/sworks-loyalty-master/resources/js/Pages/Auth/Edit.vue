<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import { useForm } from "@inertiajs/vue3";
import PageTitle from "@/Components/PageTitle.vue";

defineOptions({ layout: Layout });
const props = defineProps({
    user: Object,
    branches: Array,
    levels: Array,
});

const form = useForm({
    username: this.user[0].username,
    name: this.user[0].name,
    email: this.user[0].email,
    phone: this.user[0].phone_no,
    access_level: this.user[0].access_level_id,
    branch: this.user[0].br_code ?? "00",
});

function updateUser() {
    return form.patch(`/user/${props.user[0].id}/update`);
}

function resetUser() {
    //event.preventDefault();
    this.form.reset();
    return this.$inertia.get("/user");
}
</script>
<template>
    <Head title="Edit System User" />
    <!--title section-->
    <PageTitle title="Edit System user" />

    <!--user form-->
    <div class="flex items-center justify-center select-none px-2">
        <form
            @submit.prevent="updateUser"
            class="bg-white dark:bg-gray-800 rounded-lg w-full md:w-auto shadow-lg md:px-2 shadow-violet-600"
        >
            <!--header section-->
            <div class="md:p-4 p-2 flex items-center justify-center">
                <h1 class="capitalize font-semibold text-sm">
                    edit user details
                </h1>
            </div>
            <hr />
            <!--user details section-->
            <p class="md:text-sm text-xs italic px-2 py-1">
                Feel free to edit details below
            </p>
            <!--details section-->
            <div
                class="grid md:grid-cols-2 grid-cols-1 md:gap-5 gap-3 md:px-4 px-2 py-2 mb-3 text-sm"
            >
                <!--name section-->
                <div class="inline-block space-y-1">
                    <label for="name">Name:</label>
                    <input
                        v-model="form.name"
                        class="focus:ring-1 focus:ring-cyan-500 dark:bg-inherit dark:text-slate-300 ring-violet-700 ring-0.5 w-full rounded-md text-sm"
                        type="text"
                        name="name"
                        id="name"
                    />
                    <p v-if="form.errors" class="text-red-500 text-sm italic">
                        {{ form.errors.name }}
                    </p>
                </div>
                <div class="inline-block space-y-1">
                    <label for="username">Username:</label>
                    <input
                        disabled
                        autofocus
                        required
                        v-model="form.username"
                        class="focus:ring-1 focus:ring-cyan-500 text-sm dark:bg-inherit dark:text-slate-300 bg-slate-100 text-slate-400 ring-violet-700 ring-0.5 w-full rounded-md"
                        type="text"
                        name="username"
                        id="username"
                    />
                    <p v-if="form.errors" class="text-red-500 text-sm italic">
                        {{ form.errors.username }}
                    </p>
                </div>
                <!--contact section-->
                <div class="inline-block space-y-1">
                    <label for="email">Email:</label>
                    <input
                        required
                        v-model="form.email"
                        class="focus:ring-1 focus:ring-cyan-500 dark:bg-inherit dark:text-slate-300 ring-violet-700 ring-0.5 w-full rounded-md text-sm"
                        type="email"
                        name="email"
                        id="email"
                    />
                    <p v-if="form.errors" class="text-red-500 text-sm italic">
                        {{ form.errors.email }}
                    </p>
                </div>
                <div class="inline-block space-y-1">
                    <label for="phone">Phone:</label>
                    <input
                        v-model="form.phone"
                        class="focus:ring-1 focus:ring-cyan-500 dark:bg-inherit dark:text-slate-300 ring-violet-700 ring-0.5 w-full rounded-md text-sm"
                        type="text"
                        name="phone"
                        id="phone"
                    />
                    <p v-if="form.errors" class="text-red-500 text-sm italic">
                        {{ form.errors.phone }}
                    </p>
                </div>
                <!--access section-->
                <div class="inline-block space-y-1">
                    <label for="access">Designation:</label>
                    <select
                        required
                        v-model="form.access_level"
                        class="w-full focus:ring-1 focus:ring-cyan-500 dark:bg-inherit dark:text-slate-300 ring-violet-700 ring-0.5 uppercase rounded-md text-sm"
                        name="access"
                        id="access"
                    >
                        <option
                            v-for="(access, index) in levels"
                            :key="index"
                            :value="access.id"
                            class="dark:bg-inherit dark:text-slate-300"
                        >
                            {{ access.name }}
                        </option>
                    </select>
                    <p v-if="form.errors" class="text-red-500 text-sm italic">
                        {{ form.errors.acceess_level }}
                    </p>
                </div>
                <div class="inline-block space-y-1">
                    <label for="branch">Branch:</label>
                    <select
                        required
                        v-model="form.branch"
                        class="w-full focus:ring-1 focus:ring-cyan-500 dark:bg-inherit dark:text-slate-300 ring-violet-700 ring-0.5 rounded-md text-sm"
                        name="branch"
                        id="branch"
                    >
                        <option
                            v-if="branches.length > 0"
                            v-for="(branch, index) in branches"
                            :key="index"
                            :value="branch.code"
                            class="dark:bg-inherit dark:text-slate-300"
                        >
                            {{ branch.name }}
                        </option>
                        <option
                            value="00"
                            class="dark:bg-inherit dark:text-slate-300"
                        >
                            Main Branch
                        </option>
                    </select>
                </div>
            </div>
            <hr />
            <!--buttoms section-->
            <div class="px-4 py-3 space-x-2 flex items-center justify-end">
                <primary-button name="Update" type="submit" />
                <secondary-button
                    name="Cancel"
                    type="button"
                    @click="resetUser()"
                />
            </div>
        </form>
    </div>
</template>
