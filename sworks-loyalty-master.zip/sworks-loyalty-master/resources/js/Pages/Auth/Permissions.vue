<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import { useForm, usePage } from "@inertiajs/vue3";
import axios from "axios";
import { provide, ref, watch } from "vue";
import UserSearch from "@/Components/UserSearch.vue";
import PageTitle from "@/Components/PageTitle.vue";
import SearchButton from "@/Components/SearchButton.vue";

defineOptions({ layout: Layout });
defineProps({ permissions: Object });

const page = usePage();

const showModal = ref(false);
const searchId = ref("");

provide("showModal", showModal);
provide("searchId", searchId);

const form = useForm({
    userId: searchId.value,
    username: null,
    name: null,
    company: null,
    selectedUserPermissions: [],
});

const isSelected = ref(false);
const userPermissions = ref([]);

async function getUsers(id) {
    await axios
        .get("/user/get-user", {
            params: {
                id: id,
            },
        })
        .then((res) => {
            //console.log(res)
            isSelected.value = true;

            form.userId = res.data.id;
            form.username = res.data.username;
            form.name = res.data.name;
            form.company = res.data.company;
        })
        .catch((err) => {
            //console.log(err);
            page.props.flash.error = err;
        });
}

function getPermissions(id) {
    axios
        .get("/user/permissions", {
            params: {
                id: id,
            },
        })
        .then((res) => {
            //console.log(res);
            userPermissions.value = res.data;

            userPermissions.value.forEach((element) => {
                if (
                    !form.selectedUserPermissions.includes(
                        element.permission_id,
                    )
                ) {
                    form.selectedUserPermissions.push(element.permission_id);
                }
            });
        })
        .catch((err) => {
            //console.log(error)
            page.props.flash.error = err;
        });
}

function isChecked(id) {
    if (id == null || !Array.isArray(userPermissions.value)) {
        return false;
    }

    return userPermissions.some(
        (permission) => permission.permission_id === id,
    );
}

function saveRights() {
    //console.log('update button clicked')
    return form.post("/permissions", {
        onError: () => form.reset(),
    });
}

function cancelAssign(event) {
    event.preventDefault();
    return $inertia.get("/");
}

watch(
    searchId,
    (newVal) => {
        if (newVal) {
            if (isSelected.value === true) {
                return;
            }
            getUsers(searchId.value);
            getPermissions(searchId.value);
        } else {
            isSelected.value = false;
        }
    },
    { deep: true, immediate: true },
);
</script>
<template>
    <Head title="User Permission" />
    <!--user search modal-->
    <user-search v-if="showModal" />
    <!--title section-->
    <PageTitle title="User Rights & Permissions" />

    <!--details section-->
    <!--form section-->
    <form
        @submit.prevent="saveRights"
        class="md:shadow-md md:w-2/3 w-full rounded-lg px-1 md:px-3 py-1"
    >
        <!--user delatils section-->
        <p class="italic text-xs text-slate-400">Please provide user details</p>
        <div
            class="flex md:items-center md:justify-start flex-col md:flex-row md:space-x-4 md:space-y-0 space-y-2 w-full md:px-3 py-2 text-sm"
        >
            <div class="space-x-2 flex items-center w-full">
                <text-input
                    label="Username"
                    required
                    autofocus
                    v-model="form.username"
                    type="text"
                    id="username"
                    class="w-full"
                    :error="form.errors.username"
                />
                <search-button />
            </div>
            <text-input
                class="w-full"
                label="Name"
                disabled
                required
                v-model="form.name"
                type="text"
                id="name"
                :error="form.errors.name"
            />
            <text-input
                class="w-full"
                label="Company"
                disabled
                required
                v-model="form.company"
                type="text"
                id="name"
                :error="form.errors.company"
            />
        </div>
        <hr />
        <hr />
        <!--permissions details-->
        <p
            class="md:text-sm text-xs flex items-center justify-center capitalize text-slate-500"
        >
            permission details
        </p>
        <p
            v-if="form.errors"
            class="font-semibold md:text-sm text-xs text-red-500"
        >
            {{ form.errors.selectedUserPermissions }}
        </p>
        <!--all permissions-->
        <div
            class="grid md:grid-cols-2 grid-cols-1 gap-2 md:gap-1 text-sm md:p-1"
        >
            <div
                v-for="(permission, index) in permissions"
                :key="index"
                class="space-y-1 w-full inline-block dark:bg-inherit dark:text-slate-300"
            >
                <h1
                    class="font-semibold capitalize md:py-2 py-1 md:text-lg text-sm"
                >
                    {{ permission.category }}
                </h1>
                <label
                    v-for="(item, itemIndex) in permission.details"
                    :key="itemIndex"
                    class="inline-flex items-center md:me-32 me-24 w-full cursor-pointer"
                >
                    <input
                        type="checkbox"
                        :value="item.id"
                        v-model="form.selectedUserPermissions"
                        class="hidden peer"
                    />
                    <div
                        class="dark:bg-gray-600 relative w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-0 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:inset-s-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"
                    ></div>
                    <span
                        class="ms-2 md:text-sm text-xs font-normal capitalize"
                        >{{ item.permission }}</span
                    >
                </label>
            </div>
        </div>
        <hr />
        <!--button section-->
        <div class="flex items-center justify-end space-x-3 p-3">
            <primary-button name="Update" type="submit" tabindex="3" />
            <secondary-button
                name="Cancel"
                type="button"
                @click="cancelAssign"
                tabindex="4"
            />
        </div>
    </form>
</template>
