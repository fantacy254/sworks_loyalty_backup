<script setup>
import { useForm, usePage } from "@inertiajs/vue3";
import AuthLayout from "@/Layouts/AuthLayout.vue";
import AlertCard from "@/Components/AlertCard.vue";

defineOptions({
    layout: AuthLayout,
});

const page = usePage();

const form = useForm({});

function resendEmail() {
    return form.post("email/verification-notification");
}
</script>
<template>
    <Head title="Verification notice" />
    <Link href="/login" class="text-xs font-medium"
        ><i class="fa-solid fa-arrow-left-long"></i> Back to sign in</Link
    >
    <AlertCard :message="page.props.flash.status" variant="primary" />
    <div class="p-4">
        <div class="flex text-lg items-center justify-center">
            <h1 class="font-bold">Verify your Email address</h1>
        </div>
        <div class="p-3 text-sm">
            <p>
                Before proceeding, please check your email for a verification
                link.
            </p>
            <p>If you did not receive the email</p>

            <form
                @submit.prevent="resendEmail()"
                class="text-white flex items-center justify-center p-3"
            >
                <primary-button
                    type="submit"
                    class="text-white w-full p-3 rounded-md font-semibold capitalize"
                    name="Request another email"
                    :loading="form.processing"
                />
            </form>
        </div>
    </div>
</template>
