<script>
import Layout from "@/Layouts/MainLayout.vue";
import MasterLayout from "@/Layouts/MasterLayout.vue";

export default {
    layout: (h, page) => {
        return page.props?.branches.length > 0
            ? h(Layout, () => page)
            : h(MasterLayout, () => page);
    },
};
</script>

<script setup>
import UserModal from "@/Components/UserModal.vue";
import PasswordModal from "@/Components/PasswordModal.vue";
import { provide, ref } from "vue";
import PageTitle from "@/Components/PageTitle.vue";
import { usePage } from "@inertiajs/vue3";

const page = usePage();

defineProps({ user: Object });

const showUserModal = ref(false);
const showPasswordModal = ref(false);

provide("showUserModal", showUserModal);
provide("showPasswordModal", showPasswordModal);

function openUserModal() {
    showUserModal.value = true;
}

function openPasswordModal() {
    showPasswordModal.value = true;
}
</script>
<template>
    <!--title profile-->

    <Head :title="page.props.auth.user.name" />
    <!--user edit modal-->
    <user-modal v-if="showUserModal" :data="user" />
    <!--password modal-->
    <password-modal v-if="showPasswordModal" :user_id="user.id" />
    <!--title section-->
    <PageTitle title="My Profile" />

    <!--user details-->
    <main class="w-full md:w-1/2">
        <!--designation section-->
        <div class="md:px-3 flex items-center justify-start py-2">
            <div class="flex-1 w-full">
                <h1 class="font-semibold uppercase text-sm">
                    {{ user.access_level.name }} {{ user.username }}
                </h1>
                <span class="text-slate-400 text-xs">{{
                    page.props.auth.company.name
                }}</span>
            </div>
            <button @click="openUserModal" type="button"
                class="rounded-md space-x-1 py-1 px-2 text-sm border border-gray-300">
                <i class="fa-regular fa-pen-to-square text-xs"></i>
                <span>Edit</span>
            </button>
        </div>
        <!--profile picture-->
        <div class="flex items-center justify-start space-x-2 py-5 md:px-3">
            <div class="w-auto h-20">
                <img :src="`/storage/Images/man.png`" alt="profile pic" class="h-full w-full" />
            </div>
            <div>
                <h1 class="font-semibold text-lg">
                    {{ user.name }}
                </h1>
                <h5 class="md:text-sm text-xs text-slate-700 dark:text-slate-400 capitalize">
                    {{ user.access_level.name }}
                </h5>
                <h6 class="text-sm text-slate-800 dark:text-slate-400">
                    {{ page.props.auth.branch.name }}
                </h6>
            </div>
        </div>
        <!--contact details-->
        <div class="py-4 md:px-3">
            <h1 class="font-bold py-2">Contact</h1>
            <div
                class="flex items-center justify-start space-x-6 py-2 md:px-1 text-slate-600 dark:text-slate-300 min-w-full">
                <div class="space-x-2">
                    <i class="fa-solid fa-phone-volume border rounded-full p-3 cursor-pointer"></i>
                    <span class="md:text-sm text-xs select-all">{{
                        user.phone_no ? user.phone_no : "+254700 000 000"
                    }}</span>
                </div>
                <div class="space-x-2 relative">
                    <i class="fa-solid fa-envelope-circle-check border rounded-full p-2 cursor-pointer"></i>
                    <span class="select-all text-xs md:text-sm">{{
                        user.email ? user.email : "example@mail.com"
                    }}</span>
                    <div v-if="user.email_verified_at !== null"
                        class="absolute rounded-full bg-green-500 h-2.5 -inset-1 z-50 w-2.5">
                        <div class="rounded-full bg-green-400 animate-ping h-full w-full"></div>
                    </div>
                </div>
            </div>
        </div>
        <!--password section-->
        <div class="flex items-center justify-between md:px-3">
            <div class="space-y-1">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" placeholder="******************"
                    class="md:w-full w-60 text-sm rounded-md dark:bg-inherit dark:text-slate-300 border-slate-300"
                    disabled />
            </div>
            <button type="button" @click="openPasswordModal()"
                class="rounded-md space-x-1 py-1 px-2 text-sm border border-gray-300 flex">
                <i class="fa-regular fa-pen-to-square text-xs"></i>
                <span>Edit</span>
            </button>
        </div>
    </main>
</template>
