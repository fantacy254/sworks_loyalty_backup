<script setup>
import { useForm } from "@inertiajs/vue3";
import AuthLayout from "@/Layouts/AuthLayout.vue";
import Seperator from "@/Components/Seperator.vue";

defineOptions({
    layout: AuthLayout,
});

defineProps({
    companies: {
        type: Array,
        require: true,
    },
});

const form = useForm({
    company: null,
});

function companySession() {
    return form.post("/authenticate-session", {
        onFinish: () => form.reset(),
    });
}
</script>
<template>
    <Head title="Authenticate Session" />
    <div class="md:w-96 w-full text-sm md:text-lg p-3 space-y-2">
        <form @submit.prevent="companySession()" class="md:space-y-4 space-y-3">
            <p class="text-sm">Kindly select the company to continue.</p>
            <select-input
                v-model="form.company"
                :error="form.errors.company"
                class="w-full"
                name="company"
                id="company"
                placeholder="Select a company"
                required
            >
                <!---<transition-group appear name="list" tag="select-input">-->
                <option
                    v-for="(item, index) in companies"
                    :key="index"
                    :value="item.id"
                    class="text-xs md:tetxt-sm"
                >
                    {{ item.name }}
                </option>
                <!----</transition-group>-->
            </select-input>
            <hr />
            <div class="space-x-3 flex items-center justify-end">
                <Link
                    href="/logout"
                    class="underline outline-offset-4 hover:text-blue-800 text-sm py-2.5 px-4"
                    >Logout</Link
                >
                <primary-button type="submit" name="Login" />
            </div>
        </form>
        <!--separator-->
        <Seperator />
        <div class="p-2 gap-2 w-full">
            <p class="text-xs pb-2">
                Proceed to the master admin dashboard.
            </p>
            <div
                class="border border-gray-300 dark:border-gray-500 rounded-md text-sm p-3 w-full flex items-center justify-center hover:bg-gray-100 dark:hover:bg-black/85"
            >
                <Link href="/master-dashboard"> Master admin dashboard </Link>
            </div>
        </div>
    </div>
</template>
