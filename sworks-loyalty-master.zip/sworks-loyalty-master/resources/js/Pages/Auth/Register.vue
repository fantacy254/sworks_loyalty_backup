<script setup>
import { useForm } from "@inertiajs/vue3";
import AuthLayout from "@/Layouts/AuthLayout.vue";

defineOptions({
    layout: AuthLayout,
});

defineProps({ company: Array });

const form = useForm({
    name: null,
    username: null,
    email: null,
    company_id: null,
    phoneNo: null,
    password: null,
    password_confirmation: null,
    remember: false,
});

function register() {
    return form.post(
        "register",
        {
            params: {
                company_id: form.company_id,
            },
        },
        {
            onFinish: () => form.reset("password", "password_confirmation"),
        },
    );
}
</script>
<template>
    <Head title="Register" />

    <form
        @submit.prevent="register"
        class="bg-white rounded-lg shadow-gray-500 shadow-2xl text-sm mx-auto space-y-1 p-8 animate__animated animate__fadeInDown"
    >
        <div class="flex items-center justify-center font-bold text-xl p-1">
            <p>Create a Free Account</p>
        </div>
        <div class="space-y-2">
            <p for="company" class="font-semibold">Company:</p>
            <select
                v-model="form.company_id"
                name="company"
                id="company"
                class="text-sm w-3/5 rounded-lg border-gray-100 bg-slate-50 focus:border-blue-700"
                autofocus
                required
            >
                <option
                    v-for="(item, index) in company"
                    :key="index"
                    :value="item.id"
                >
                    {{ item.name }}
                </option>
            </select>
            <p v-if="form.errors" class="font-semibold text-red-500">
                {{ form.errors.company_id }}
            </p>
        </div>
        <hr />
        <div class="flex items-center justify-between space-x-7">
            <div class="space-y-1 w-full">
                <label for="name" class="font-semibold">Name:</label>
                <input
                    type="text"
                    v-model="form.name"
                    name="username"
                    id="name"
                    placeholder="Your name"
                    class="min-w-full text-sm bg-slate-50 rounded-md border-gray-100 focus:border-blue-700"
                    autocomplete="name"
                    autofocus
                    required
                />
                <p v-if="form.errors" class="font-semibold text-red-500">
                    {{ form.errors.name }}
                </p>
            </div>
            <div class="space-y-1 w-full">
                <label for="username" class="font-semibold">Username:</label>
                <input
                    type="text"
                    v-model="form.username"
                    name="username"
                    id="username"
                    placeholder="Your username"
                    class="w-full text-sm bg-slate-50 rounded-md border-gray-100 focus:border-blue-700"
                    autocomplete="username"
                    required
                />
                <p v-if="form.errors" class="font-semibold text-red-500">
                    {{ form.errors.username }}
                </p>
            </div>
        </div>
        <div class="flex items-center justify-center space-x-7">
            <div class="space-y-1 w-full">
                <label for="email" class="font-semibold">Email:</label>
                <input
                    type="email"
                    v-model="form.email"
                    name="email"
                    id="email"
                    placeholder="Your Email"
                    class="w-full text-sm bg-slate-50 rounded-md border-gray-100 focus:border-blue-700"
                    autocomplete="email"
                    required
                />
                <p v-if="form.errors" class="font-semibold text-red-500">
                    {{ form.errors.email }}
                </p>
            </div>
            <div class="space-y-1 w-full">
                <label for="phoneNo" class="font-semibold">PhoneNo:</label>
                <input
                    type="text"
                    v-model="form.phoneNo"
                    name="phoneNo"
                    id="phoneNo"
                    placeholder="Your phone"
                    class="w-full text-sm bg-slate-50 rounded-md border-gray-100 focus:border-blue-700"
                    autocomplete="phoneNo"
                    required
                />
                <p v-if="form.errors" class="font-semibold text-red-500">
                    {{ form.errors.phoneNo }}
                </p>
            </div>
        </div>
        <div class="flex items-center justify-center space-x-7">
            <div class="space-y-1 w-full">
                <label for="password" class="font-semibold">Password:</label>
                <input
                    type="password"
                    v-model="form.password"
                    name="password"
                    id="password"
                    class="w-full text-sm rounded-md bg-slate-50 border-gray-100 focus:border-blue-700"
                    placeholder="Password"
                    required
                />
                <p v-if="form.errors" class="font-semibold text-red-500">
                    {{ form.errors.password }}
                </p>
            </div>
            <div class="space-y-1 w-full">
                <label for="confirm-password" class="font-semibold"
                    >Confirm Password:</label
                >
                <input
                    type="password"
                    v-model="form.password_confirmation"
                    name="password"
                    id="confirm-password"
                    class="w-full text-sm rounded-md bg-slate-50 border-gray-100 focus:border-blue-700"
                    placeholder="Confirm"
                    required
                />
            </div>
        </div>
        <hr />
        <div class="flex items-center justify-start space-x-2 py-1 w-full">
            <input
                type="checkbox"
                v-model="form.remember"
                name="remember"
                id="remember"
                class="border-blue-700 rounded-sm focus:ring-offset-0 focus:border-0"
            />
            <label for="remember"
                >I accept the
                <Link href="#" class="text-sky-500">Terms and Conditions</Link>
            </label>
        </div>
        <div class="space-y-2">
            <div class="flex justify-center items-center">
                <button
                    type="submit"
                    class="text-white w-1/2 bg-linear-to-r from-cyan-800 via-blue-600 to-blue-800 p-3 rounded-md shadow-lg shadow-gray-400 font-semibold capitalize"
                >
                    create account
                </button>
            </div>
            <div>
                <Link href="login" class="w-full text-slate-500"
                    >Already have an account?
                    <span class="text-sky-600 font-semibold"
                        >Login here</span
                    ></Link
                >
            </div>
        </div>
    </form>
</template>
