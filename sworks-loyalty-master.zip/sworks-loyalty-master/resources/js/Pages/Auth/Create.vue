<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import { useForm, usePage } from "@inertiajs/vue3";
import axios from "axios";
import { ref } from "vue";
import { onMounted } from "vue";
import PageTitle from "@/Components/PageTitle.vue";

defineOptions({
    layout: Layout,
});

const page = usePage();

const form = useForm({
    fname: null,
    lname: null,
    username: null,
    email: null,
    phone_no: null,
    access_level: null,
    branch: null,
});
const access = ref([]);

const getAccessLevel = async () => {
    await axios
        .get("/access/show")
        .then((res) => {
            access.value = res.data;
        })
        .catch((error) => {
            //console.log(error)
        });
};

const saveUser = () => {
    return form.post("/user");
};

onMounted(() => {
    getAccessLevel();
});
</script>
<template>
    <Head title="User Registration" />
    <!--section header-->
    <PageTitle title="User Registration" />

    <!--form wrap section-->
    <main class="flex items-center justify-center md:px-3 mx-auto">
        <!--form section-->
        <div class="md:rounded-md bg-white shadow-md w-auto">
            <!--header section-->
            <div
                class="w-full rounded-t-md bg-indigo-800 flex items-center justify-center"
            >
                <h1 class="p-4 text-slate-50 shadow-sm">
                    User Registration Form
                </h1>
            </div>
            <hr />
            <!--form details-->
            <p class="text-slate-300 py-3 px-2 text-xs">
                Provide the details below. spaces marked with
                <i class="text-red-500">*</i> are mandatory
            </p>
            <hr />
            <form
                @submit.prevent="saveUser()"
                class="md:py-4 md:px-2 md:space-y-4"
            >
                <!--details section-->
                <div
                    class="flex flex-col md:flex-row md:items-center md:justify-evenly md:space-x-2 md:space-y-0 space-y-3 md:py-3"
                >
                    <text-input
                        v-model="form.fname"
                        :error="form.errors.fname"
                        type="text"
                        id="fname"
                        label="First Name"
                        placeholder="John"
                        class="w-full"
                        must
                        require
                    />
                    <text-input
                        v-model="form.lname"
                        :error="form.errors.lname"
                        type="text"
                        id="lname"
                        label="Last Name"
                        placeholder="Doe"
                        class="w-full"
                        must
                        require
                    />
                    <text-input
                        v-model="form.username"
                        :error="form.errors.username"
                        type="text"
                        id="username"
                        label="Username"
                        placeholder="john_doe254"
                        class="w-full"
                        must
                        require
                    />
                </div>
                <!--access section-->
                <div
                    class="flex flex-col md:flex-row md:items-center md:justify-between md:space-x-1 space-x-0 space-y-3 md:space-y-0 py-3"
                >
                    <text-input
                        v-model="form.email"
                        :error="form.errors.email"
                        type="text"
                        id="email"
                        label="Email"
                        placeholder="example@mail.com"
                        class="w-full"
                        must
                        require
                    />
                    <text-input
                        v-model="form.phone_no"
                        :error="form.errors.phone_no"
                        type="tel"
                        id="phone"
                        label="Phone"
                        placeholder="254712345678"
                        class="w-full"
                        must
                        require
                    />
                </div>
                <div
                    class="flex flex-col md:flex-row md:items-center md:justify-between md:space-x-1 space-x-0 space-y-3 md:space-y-0 py-3"
                >
                    <select-input
                        v-model="form.access_level"
                        :error="form.errors.access_level"
                        label="Access Level"
                        id="access_level"
                        class="w-full"
                        must
                        require
                    >
                        <option
                            class="uppercase"
                            v-for="(item, index) in access"
                            :key="index"
                            :value="item.id"
                        >
                            {{ item.name }}
                        </option>
                    </select-input>
                    <select-input
                        v-model="form.branch"
                        :error="form.errors.branch"
                        label="Branch"
                        id="branch"
                        class="w-full"
                        must
                        require
                    >
                        <option
                            class="uppercase"
                            v-if="page.props?.branches.length > 0"
                            v-for="(branch, index) in page.props?.branches"
                            :key="index"
                            :value="branch.id"
                        >
                            {{ branch.name }}
                        </option>
                    </select-input>
                </div>
                <hr />
                <!--Buttons section-->
                <div
                    class="p-4 flex items-center justify-end md:space-x-3 space-x-2"
                >
                    <primary-button type="submit" name="Save" />
                    <secondary-button type="reset" name="Cancel" />
                </div>
            </form>
        </div>
    </main>
</template>
