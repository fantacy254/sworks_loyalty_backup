<script setup>
import { useForm, usePage } from "@inertiajs/vue3";
import AuthLayout from "@/Layouts/AuthLayout.vue";

defineOptions({
    layout: AuthLayout,
});

const page = usePage();

const form = useForm({
    email: page.props.email,
    password: null,
    password_confirmation: null,
    token: page.props.token,
});

function resetPassword() {
    return form.post("/reset-password", {
        onFinish: () => form.reset(),
    });
}
</script>
<template>
    <Head title="Reset Password" />
    <Link href="/login" class="text-xs font-medium"
        ><i class="fa-solid fa-arrow-left-long"></i> Back to sign in</Link
    >
    <form
        @submit.prevent="resetPassword"
        class="text-sm md:mx-auto space-y-3 p-3 w-auto animate__animated animate__zoomIn"
    >
        <p class="font-medium text-sm">Reset your password</p>
        <p class="text-slate-500 md:text-sm text-xs">
            Welcome back! Enter your new password in the spaces below.
        </p>
        <text-input
            type="email"
            label="Email"
            v-model="form.email"
            :error="form.errors.email"
            placeholder="email"
            autofocus
        />
        <text-input
            type="password"
            label="New Password"
            v-model="form.password"
            :error="form.errors.password"
            placeholder="password"
        />
        <text-input
            type="password"
            label="Confirm"
            v-model="form.password_confirmation"
            :error="form.errors.password_confirmation"
            placeholder="confirm password"
        />
        <div class="flex items-center justify-start space-x-2 py-2 w-full">
            <input
                type="checkbox"
                name="remember"
                id="remember"
                class="border-blue-700 rounded-sm focus:ring-offset-0 focus:border-0"
            />
            <label for="remember"
                >I accept the
                <Link href="#" class="text-sky-500">Terms and Conditions</Link>
            </label>
        </div>
        <div class="space-y-2">
            <primary-button
                type="submit"
                class="w-full capitalize"
                name="reset password"
                :loading="form.processing"
            />
        </div>
    </form>
</template>
