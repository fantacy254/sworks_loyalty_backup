<script setup>
import { useForm, usePage } from "@inertiajs/vue3";
import { ref } from "vue";
import axios from "axios";
import AuthLayout from "@/Layouts/AuthLayout.vue";

defineOptions({
    layout: AuthLayout,
});

defineProps: ({
    company: Object,
});

const form = useForm({
    company_id: null,
    username: null,
    password: null,
    remember: false,
});

const page = usePage();
const users = ref([]);

async function getUsers() {
    await axios
        .get("/getUsers", {
            params: {
                company_id: form.company_id,
            },
        })
        .then((res) => {
            //console.log(res)
            users.value = res.data;
        })
        .catch((error) => {
            //console.log(error)
            page.props.flash.error = error;
        });
}

function login() {
    return form.post("/admin_login", {
        onFinish: () => form.reset("password"),
        onError: (err) => console.log(err),
    });
}
</script>
<template>
    <Head title="Login" />

    <form
        @submit.prevent="login"
        class="bg-white rounded-lg shadow-xl text-sm mx-auto space-y-3 p-8 w-auto animate__animated animate__fadeInDown"
    >
        <div class="flex items-center justify-center font-bold text-xl p-3">
            <p>Sign in to Account</p>
        </div>
        <div class="space-y-2">
            <label for="company" class="font-normal italic"
                >select company</label
            >
            <select
                v-model="form.company_id"
                name="company"
                id="company"
                class="w-full text-sm rounded-lg border-gray-100 bg-slate-50 focus:border-blue-700"
                autofocus
                required
            >
                <option
                    v-for="(item, index) in company"
                    :key="index"
                    :value="item.id"
                    selected
                >
                    {{ item.name }}
                </option>
            </select>
            <p v-if="form.errors" class="font-semibold text-red-500">
                {{ form.errors.companyId }}
            </p>
        </div>
        <div class="space-y-1">
            <label for="username" class="font-semibold">Username:</label>
            <input
                type="text"
                v-model="form.username"
                id="username"
                class="w-full text-sm rounded-lg border-gray-100 bg-slate-50 focus:border-blue-700"
                autofocus
                required
            />
            <!--<select v-model="form.username" name="username" id="username"
                        class="w-full text-sm rounded-lg border-gray-100 bg-slate-50 focus:border-blue-700" autofocus
                        required>
                        <option v-for="(item, index) in users" :key="index" :value="item.username" selected>
                            {{ item.name }}
                        </option>
                    </select>-->
            <p v-if="form.errors" class="font-semibold text-red-500">
                {{ form.errors.username }}
            </p>
        </div>
        <div class="space-y-1">
            <label for="password" class="font-semibold">Password:</label>
            <input
                v-model="form.password"
                type="password"
                name="password"
                id="password"
                class="w-full text-sm rounded-md bg-slate-50 border-gray-100 focus:border-blue-700"
                placeholder="&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;"
                required
            />
            <p v-if="form.errors" class="font-semibold text-red-500">
                {{ form.errors.password }}
            </p>
        </div>
        <div class="flex items-center justify-between py-2 w-full">
            <div class="flex items-center justify-start space-x-2">
                <input
                    type="checkbox"
                    v-model="form.remember"
                    name="remember"
                    id="remember"
                    class="border-blue-700 rounded-sm focus:ring-offset-0 focus:border-0"
                />
                <label for="remember">Remember me</label>
            </div>
            <div>
                <Link href="forgot-password" class="text-blue-700">
                    Forgot password?
                </Link>
            </div>
        </div>
        <div class="space-y-2">
            <button
                type="submit"
                class="w-full text-lg hover:text-black text-white bg-linear-to-r from-cyan-800 via-blue-600 to-blue-800 p-3 rounded-md font-semibold"
            >
                <span v-if="form.processing" class="z-50 text-yellow-400">
                    Sending code...
                    <i class="fa-solid fa-spinner animate-spin"></i>
                </span>
                <span v-else>Request code</span>
            </button>
            <!--<Link href="register" class="text-slate-500">Don't have an account? <span
                        class="text-sky-600 font-semibold">Create an account</span></Link>-->
        </div>
    </form>
</template>
