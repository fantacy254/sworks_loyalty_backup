<script setup>
import { onMounted, onUnmounted, provide, ref } from "vue";
import { Form, router } from "@inertiajs/vue3";
import AuthLayout from "@/Layouts/AuthLayout.vue";
import CodeInput from "@/Components/CodeInput.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { useAuthManager } from "@/composable/authManager";

defineOptions({
    layout: AuthLayout,
});

const auth = useAuthManager();

const defaultCount = 2 * 60;
const maxCount = ref(defaultCount);
const processing = ref(false);
const interval = ref();

async function requestCode() {
    if (maxCount.value !== 0) return;

    router.post(
        "/resend-code",
        {},
        {
            onSuccess: () => startResendTimer(),
        },
    );
}

function submit() {
    processing.value = true;
    router.post(
        "/authorize",
        { code: auth.authCode },
        {
            onFinish: () => (processing.value = false),
        },
    );
}

const startResendTimer = () => {
    interval.value = setInterval(() => {
        maxCount.value--;
        if (maxCount.value === 0) clearInterval(interval.value);
    }, 1000);
};

const formatCount = (seconds) => {
    seconds = Math.max(0, Number(seconds) || 0);

    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;

    return `${minutes}min ${remainingSeconds}sec`;
};

provide("auth-code", {
    submit,
});

onMounted(() => {
    startResendTimer();
});

onUnmounted(() => {
    clearInterval(interval.value);
});
</script>
<template>
    <!--title head-->

    <Head title="Authentication" />
    <Link href="/logout" class="text-xs font-medium"
        ><i class="fa-solid fa-arrow-left-long"></i> Back to sign in</Link
    >
    <h1 class="text-center font-bold text-lg md:text-3xl">
        MFA Authentication
    </h1>
    <div class="space-y-2 p-2 md:p-4 rounded-md text-sm">
        <p class="flex items-center justify-center">
            Enter the 4-digit authorization code sent to your email address<br />and
            to your phone number.
        </p>
        <Form
            id="otp-form"
            @submit.prevent="submit()"
            class="md:w-96 w-full"
            v-slot="{ errors }"
        >
            <code-input />
            <p v-if="errors.code" class="text-red-500">
                {{ errors.code }}
            </p>
            <div class="mx-auto mt-4">
                <primary-button
                    type="submit"
                    class="text-white w-full p-3 rounded-md font-semibold capitalize"
                    name="Authenticate"
                    :loading="processing"
                />
            </div>
        </Form>
        <div class="text-sm mt-4">
            Didn't receive code?
            <button
                v-if="maxCount === 0"
                type="button"
                @click="requestCode()"
                class="font-medium text-indigo-500 dark:text-inherit hover:text-indigo-600"
            >
                Resend
            </button>
            <span v-else class="text-black dark:text-inherit"
                >Expires in <strong>{{ formatCount(maxCount) }}</strong></span
            >
        </div>
    </div>
</template>
