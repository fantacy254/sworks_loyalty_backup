<script setup>
import { useForm, usePage } from "@inertiajs/vue3";
import AuthLayout from "@/Layouts/AuthLayout.vue";
import AlertCard from "@/Components/AlertCard.vue";

defineOptions({ layout: AuthLayout });
const page = usePage();

const form = useForm({
    email: null,
});

function resetPassword() {
    return form.post("/forgot-password", {
        onFinish: () => form.reset("email"),
    });
}
</script>
<template>
    <Head title="Forgot Password" />
    <Link href="/login" class="text-xs font-medium"
        ><i class="fa-solid fa-arrow-left-long"></i> Back to sign in</Link
    >
    <AlertCard :message="page.props.flash.status" variant="primary" />
    <form
        @submit.prevent="resetPassword()"
        class="text-sm mx-auto space-y-3 p-3 w-auto"
    >
        <p class="font-medium text-sm">Forgot your password?</p>
        <p class="text-slate-500 md:text-sm text-xs">
            Don't fret! Just type in your email and we will send you a code<br />to
            reset your password!
        </p>
        <text-input
            type="email"
            label="Email"
            v-model="form.email"
            :error="form.errors.email"
            placeholder="email"
            autofocus
        />
        <div class="flex items-center justify-start space-x-2 py-2 w-full">
            <input
                v-model="form.remember"
                type="checkbox"
                name="remember"
                id="remember"
                class="border-blue-700 rounded-sm dark:bg-inherit focus:ring-offset-0 focus:border-0"
            />
            <label for="remember"
                >I accept the
                <Link href="#" class="text-sky-500">Terms and Conditions</Link>
            </label>
        </div>
        <div class="space-y-2">
            <primary-button
                type="submit"
                class="w-full capitalize"
                name="reset password"
                :loading="form.processing"
            />
        </div>
    </form>
</template>
