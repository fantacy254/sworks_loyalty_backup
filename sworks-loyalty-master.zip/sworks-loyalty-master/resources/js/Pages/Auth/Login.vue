<script setup>
import { useForm } from "@inertiajs/vue3";
import AuthLayout from "@/Layouts/AuthLayout.vue";

defineOptions({
    layout: AuthLayout,
});

const props = defineProps({
    company: Object,
});

const form = useForm({
    email: null,
    password: null,
    remember: false,
});

function login() {
    return form.post("login", {
        onFinish: () => form.reset("password"),
        onError: (err) => console.log(err),
    });
}
</script>
<template>

    <Head title="Login" />
    <form @submit.prevent="login" class="md:w-96 w-full rounded-lg text-sm md:space-y-2 space-y-3 p-2">
        <div class="flex items-center justify-center font-bold text-lg md:text-xl">
            <p>Sign in to Account</p>
        </div>
        <hr />
        <p class="italic capitalize md:text-sm text-xs">
            provide your login details below
        </p>
        <div class="space-y-4">
            <text-input type="email" label="Email" v-model="form.email" :error="form.errors.email" placeholder="email"
                autofocus />
            <text-input label="Password" type="password" v-model="form.password" :error="form.errors.password"
                placeholder="**********" />
        </div>
        <div class="flex items-center justify-between py-2 w-full">
            <div class="flex items-center justify-start space-x-1 cursor-pointer">
                <input type="checkbox" v-model="form.remember" name="remember" id="remember"
                    class="border-blue-700 dark:bg-inherit rounded-sm focus:ring-offset-0 focus:border-0" />
                <label for="remember">Remember me</label>
            </div>
            <div>
                <Link href="forgot-password" class="text-blue-700">
                Forgot password?
                </Link>
            </div>
        </div>
        <div class="space-y-2">
            <primary-button type="submit" class="text-white w-full p-3 rounded-md font-semibold capitalize" name="Login"
                :loading="form.processing" />
        </div>
    </form>
</template>
