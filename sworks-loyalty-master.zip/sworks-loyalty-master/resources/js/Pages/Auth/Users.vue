<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import { computed } from "vue";
import SmartTable from "@/Components/SmartTable.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { usePage } from "@inertiajs/vue3";

defineOptions({
    layout: Layout,
});
const props = defineProps({ users: Array });
const title = "System Users";
const page = usePage();

const headers = computed(() => {
    return Object.keys(props.users[0] || {})
        .filter((key) => key !== "id")
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});

const deleteUser = async (id) => {
    if (confirm("You are about to delete this user. Do you want to proceed?")) {
        await $inertia.delete(`/user/${id}`, {
            preserveState: true,
        });
    }
};

const restoreUser = async (id) => {
    if (
        confirm("You are about to restore this user. Do you want to proceed?")
    ) {
        await $inertia.post(`/user/${id}/restore`, {
            preserveState: true,
        });
    }
};
</script>
<template>
    <Head :title="title" />
    <!--title section-->
    <PageTitle :title="title" />
    <!--create sub agent button-->
    <div class="p-3">
        <Link
            href="/user/create"
            class="text-indigo-700 space-x-2 hover:text-indigo-900 font-normal text-xs"
        >
            <i class="fa-solid fa-person-circle-plus text-lg"></i>
            <span>Add System User</span>
        </Link>
    </div>
    <!--users section-->
    <div class="md:px-4 px-2 md:py-3 py-2 md:space-y-4 space-y-2">
        <smart-table
            :data="users"
            :headers="headers"
            message="No records found"
            :branches="page.props?.branches"
        />
    </div>
</template>
