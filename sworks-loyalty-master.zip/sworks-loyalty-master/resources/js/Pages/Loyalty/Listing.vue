<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SmartTable from "@/Components/SmartTable.vue";
import SmartExport from "@/Components/SmartExport.vue";
import SmartPrint from "@/Components/SmartPrint.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { computed } from "vue";
import { usePage } from "@inertiajs/vue3";
import { computedAmount } from "@/utlis/smartFun";

defineOptions({ layout: Layout });

const props = defineProps({
    data: Object,
});

const page = usePage()

const title = "Customer Listing";
const branches = page.props.branches

// Define header as a ref or const
const headers = computed(() => {
    return Object.keys(props.data[0] || {})
        .filter((key) => key !== "branch_id")
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});

const tlBal = computed(() => {
    const tl = props.data.reduce((acc, cust) => acc + (cust.acc_bal || 0), 0)
    return computedAmount(tl)
})

</script>

<template>

    <Head :title="title" />
    <!--Header section-->
    <PageTitle :title="title" />
    <div class="flex items-center justify-end md:p-2 px-2 md:space-x-3 space-x-1">
        <SmartExport :transData="data" name="Customer Listing" />
        <SmartPrint :exportData="data" transName="Loyalty customer listing" :header="header" />
    </div>
    <div class="md:px-3 px-1 py-3">
        <smart-table :headers="headers" :data="data" :branches="branches" message="No records found" />
        <!--totals-->
        <div class="flex items-center justify-center">
            <TextInput id="accPoints" type="text" v-model="tlBal" class="md:w-auto w-full font-bold text-center" disabled />
        </div>
    </div>
</template>
