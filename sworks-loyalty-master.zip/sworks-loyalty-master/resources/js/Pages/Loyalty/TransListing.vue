<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SmartTable from "@/Components/SmartTable.vue";
import SmartPrint from "@/Components/SmartPrint.vue";
import SmartExport from "@/Components/SmartExport.vue";
import PrintVoucher from "@/Components/PrintVoucher.vue";
import axios from "axios";
import { computed, onMounted, provide, ref, watch } from "vue";
import PageTitle from "@/Components/PageTitle.vue";
import { usePage } from "@inertiajs/vue3";
import { getFirstDay, getLastDay } from "@/utlis/smartFun";

defineOptions({ layout: Layout });
const page = usePage();

const props = defineProps({
    types: Array,
    type: String
});


const showPrintModal = ref(false);
const voucherDoc = ref(null);
const transType = ref(props.type ?? 'all');

const openPrintModal = (index) => {
    voucherDoc.value = index;
    showPrintModal.value = true;
    //console.log(index)
};

provide("showPrintModal", showPrintModal);
provide("voucherDoc", voucherDoc);
provide("openPrintModal", openPrintModal);
provide("transType", transType);


const branches = page.props.branches
const data = ref([]);
const title = "Transactions listing";

const headers = computed(() => {
    return Object.keys(data.value[0] || {})
        .filter((key) => key !== "branch_id")
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});
const from = ref(getFirstDay.value);
const to = ref(getLastDay.value);
const loading = ref(false);

async function loadTrans() {
    loading.value = true;
    await axios
        .get("/load-trans", {
            params: {
                type: transType.value,
                from: from.value,
                to: to.value,
            },
        })
        .then((res) => {
            //console.log(res)
            loading.value = false;
            data.value = res.data;
        })
        .catch((err) => {
            //console.log(err)
            loading.value = false;
            page.props.flash.error = err.response.data;
        });
}


onMounted(() => {
    loadTrans();
});

watch([transType, from, to], () => {
    loadTrans()
})

</script>
<template>

    <Head :title="title" />
    <!--loalty voucher modal-->
    <print-voucher v-if="showPrintModal" />
    <!--Header section-->
    <PageTitle :title="title" />
    <!--export section-->
    <div class="flex items-center justify-end md:justify-start md:space-x-3 space-x-1 px-3 py-1">
        <smart-export :transData="data" :name="title" />
        <smart-print :exportData="data" :transName="title" />
    </div>
    <!--body section-->
    <div class="md:px-4 px-1 text-xs md:text-sm">
        <!--type section-->
        <div class="md:px-1 py-2 md:flex-row flex-col flex md:items-end md:justify-start md:space-x-6">
            <div
                class="flex md:flex-row flex-col md:items-center justify-start space-x-0 space-y-2 md:space-y-0 md:space-x-4 md:flex-1">
                <!--type select-->
                <select-input label="Types" must v-model="transType" required name="types" id="types"
                    class="md:w-52 w-full">
                    <option value="all">All</option>
                    <option v-for="(item, index) in types" :key="index" :value="item.type" class="text-xs">
                        {{ item.name }}
                    </option>
                </select-input>
                <!--date section-->
                <text-input label="From" must v-model="from" type="date" id="from" required />
                <text-input label="To" v-model="to" type="date" id="to" required must />
            </div>
            <div class="flex items-end justify-end flex-1 md:grow-0 p-3">
                <primary-button :loading="loading" @click="loadTrans()" name="Refresh" type="submit" />
            </div>
        </div>
        <hr />
        <!--table section-->
        <div class="pb-10">
            <smart-table :data="data" :headers="headers" :branches="branches" message="No records found" />
        </div>
    </div>
</template>
