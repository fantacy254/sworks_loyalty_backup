<script setup>
    import Layout from "@/Layouts/MainLayout.vue";
    import PageTitle from "@/Components/PageTitle.vue";
    import { ref } from "vue";
    import LocationMaster from "@/Components/LocationMaster.vue";
    import GroupMaster from "@/Components/GroupMaster.vue";

    defineOptions({ layout: Layout })
    const title = 'Loyalty Masters'
    defineProps({
        locations: Object,
        groups: Object
    })

    const masters = [
        { name: 'Location', val: 'location', icon: 'fa-solid fa-location-dot' },
        { name: 'Groups', val: 'group', icon: 'fa-solid fa-people-group' }
    ]
    const masterTemp = ref('location')

</script>
<template>

    <Head :title="title" />
    <!--Header section-->
    <PageTitle :title="title" description="View and manage loyalty masters." />
    <!--masters list-->
    <div class="flex items-center justify-start p-2">
        <div class="rounded-lg bg-gray-50 p-2 gap-2 flex items-center">
            <div v-for="(mst, index) in masters" :key="index"
                class="py-2 px-4 text-sm hover:scale-[1.03] cursor-pointer rounded-lg gap-2"
                :class="{ 'bg-white shadow-sm': masterTemp === mst.val }">
                <input v-model="masterTemp" type="radio" name="masterTemplate" :id="mst.name" :value="mst.val"
                    class="peer sr-only">
                <i :class="mst.icon"></i>&nbsp;
                <label :for="mst.name" class=" cursor-pointer">{{ mst.name }}</label>
            </div>
        </div>
    </div>
    <!--mastre content-->
    <div class="p-2 w-full md:w-3xl md:mx-auto">
        <!--location masters-->
        <LocationMaster v-if="masterTemp === 'location'" :locations="locations" />
        <!--Group masters-->
        <GroupMaster v-if="masterTemp === 'group'" :groups="groups" />
    </div>
</template>