<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SmartSearch from "@/Components/SmartSearch.vue";
import PrintVoucher from "@/Components/PrintVoucher.vue";
import axios from "axios";
import moment from "moment";
import Swal from "sweetalert2/dist/sweetalert2";
import { computed, provide, ref, watch } from "vue";
import { usePage } from "@inertiajs/vue3";
import PageTitle from "@/Components/PageTitle.vue";
import { computedNamedDate } from "@/utlis/smartFun";

//layout
defineOptions({
    layout: Layout,
});

// Props
const props = defineProps({
    branches: Array,
});

// Inertia page context
const page = usePage();

// State
const custId = ref("");
const showModal = ref(false);
const showPrintModal = ref(false);
const voucherDoc = ref(null);

const brId = ref(page.props.auth.branch.id);
const cust = ref([]);
const master = ref([])

// Provide for child components
provide("showModal", showModal);
provide("showPrintModal", showPrintModal);
provide("voucherDoc", voucherDoc);

const openSearchModal = () => {
    showModal.value = true;
};

// Methods
async function getCustomer(id) {
    await axios
        .get(`/get-bal/${id}`)
        .then((res) => {
            //console.log(res);

            if (!Array.isArray(res.data)) {
                page.props.flash.info = res.data;

                cust.value = []
                master.value = []
                return;
            }

            cust.value = res.data[0]
            master.value = res.data[1]
        })
        .catch((err) => {
            cust.value = []
            master.value = []
            page.props.flash.error = err.response?.data;
        });
}

const redeemable = computed(() => {
    return (cust.value.actual_bal - master.value.min_redeem) || 0
})

const balAt = computed(() => {
    return computedNamedDate(cust.value.updated_at)
})

provide("custId", {
    custId,
    getCustomer,
});

async function redeemPoints(point) {
    if (confirm("You are about to redeem points. Do you want to continue?")) {
        await axios
            .post("/redeem-points", {
                br_id: brId.value,
                id: custId.value,
                points: point,
            })
            .then((res) => {
                if (res.status === 200) {
                    page.props.flash.success =
                        "Loyalty points redeemed successfully";
                    Swal.fire({
                        title: res.data.voucher,
                        text:
                            +res.data.points +
                            " points successfully redeemed, expires on " +
                            moment(res.data.expiry).format("DD-MMM-YYYY"),
                        icon: "success",
                        footer:
                            "voucher only valid within " +
                            res.data.days +
                            " days",
                    }).then((result) => {
                        if (result.isConfirmed) {
                            custId.value = "";
                            cust.value = []
                            redeemable.value = null;

                            voucherDoc.value = res.data.voucher;
                            showPrintModal.value = true;
                        }
                    });
                }
                if (res.status === 201) {
                    page.props.flash.info = res.data;
                }
            })
            .catch((err) => {
                cust.value = []
                redeemable.value = null;
                page.props.flash.error = err.response?.data;
            });
    }
}

function fireRedeem() {
    Swal.fire({
        title: "Redeem Points",
        input: "number",
        inputLabel: "Enter number of points to redeem",
        inputPlaceholder: "Enter points",
        showCancelButton: true,
        inputValidator: (value) => {
            if (!value) {
                return "The points field is mandatory";
            }
            if (value > redeemable.value) {
                return (
                    "You can not redeem more than" +
                    " " +
                    redeemable.value +
                    "!"
                );
            }
        },
    }).then((result) => {
        const { value: point } = result;
        if (point && result.isConfirmed) {
            redeemPoints(point);
        }
    });
}

</script>
<template>

    <Head title="Loyalty Balance" />
    <!--loalty voucher modal-->
    <print-voucher v-if="showPrintModal" />
    <!---search modal-->
    <smart-search v-if="showModal" />
    <!--Header section-->
    <PageTitle title="Customer points balance Enquiry" />
    <!--form part-->
    <div class="md:w-2xl md:mx-auto w-full p-2 rounded-md border">
        <h1 class="text-start uppercase p-2 font-semibold text-lg">Redeem Smartpoints</h1>
        <h3 class="font-semibold text-sm opacity-65 uppercase pt-2">select branch</h3>
        <hr>
        <div class="py-2">
            <select-input :disabled="$page.props.auth.user.access_level === 5" v-model="brId" label="Branch"
                class="w-full" must>
                <option value="" selected disabled>Select Branch</option>
                <option v-for="(br, index) in branches" :key="index" :value="br.id">
                    {{ br.name }}
                </option>
            </select-input>
        </div>
        <hr>
        <h3 class="font-semibold text-sm opacity-65 uppercase py-3">Customer details</h3>
        <hr>
        <!--customer Id section-->
        <div class="flex px-2 h-fit border rounded-md border-gray-400 my-2">
            <button type="button" @click="openSearchModal()"
                class="border-none focus:ring-0 focus:border-none rounded-md cursor-pointer">
                <i class="fa-solid fa-magnifying-glass text-lg opacity-50"></i>
            </button>
            <input @keyup.enter.prevent="getCustomer(custId)" @keydown.tab.prevent="getCustomer(custId)"
                v-model="custId" type="text" name="search" id="search"
                class="font-medium border-none text-xs ring-0 focus:ring-0 focus:border-none text-left w-full bg-inherit dark:text-slate-300"
                placeholder="Find customer(ID or Acc. No)" autofocus />
        </div>
        <!--customer details-->
        <div class="grid md:grid-cols-2 grid-cols-1 gap-3 cursor-not-allowed">
            <text-input label="A/C No" v-model="cust.accno" disabled class="w-full" />
            <text-input label="Name" v-model="cust.name" disabled class="w-full" />
            <text-input label="Balance" v-model="cust.actual_bal" disabled class="w-full" />
            <text-input label="Balance At" v-model="balAt" disabled class="w-full" />
        </div>
        <h3 class="font-semibold text-sm opacity-65 uppercase py-3">Transaction details</h3>
        <hr>
        <!--Points Details-->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3 cursor-not-allowed mb-3">
            <text-input label="Redeemable" v-model="redeemable" disabled class="w-full" />
            <text-input label="Min Points" v-model="master.min_redeem" disabled class="w-full" />
            <text-input label="@Rate" v-model="master.redeem" disabled class="w-full" />
            <text-input label="Cash Value" v-model="redeemable" disabled class="w-full" />
        </div>
        <hr>
        <!--report section-->
        <div class="flex items-center justify-end gap-2 transition-all duration-300 ease-in-out p-3">
            <primary-button v-if="Object.keys(cust).length > 0" @click="fireRedeem()" name="Redeem Points" type="button"
                :class="{ 'cursor-not-allowed': Object.keys(cust).length === 0 }"
                :disabled="Object.keys(cust).length === 0" />
            <div></div>
            <button type="button"
                class="text-sm capitalize py-3 px-2 rounded-md bg-cyan-500 md:font-medium text-nowrap">
                Print Blance
            </button>
        </div>
    </div>
</template>
