<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import { useForm } from "@inertiajs/vue3";
import { ref, computed } from "vue";
import { usePage, router } from "@inertiajs/vue3";
import PageTitle from "@/Components/PageTitle.vue";
    import Breadcrum from "@/Components/ui/Breadcrum.vue";

//define layout
defineOptions({
    layout: Layout,
});
    const title = 'Loyalty Customer'

    //breadcrums
    const breadcrums = [
        { title: 'Customers', to: '/customers' },
        { title: `Create ${title.toLowerCase()}`, to: '/create-customer' },
    ]

//define props
defineProps({
    branch: Object,
});

const page = usePage();

const form = useForm({
    branchId:
        page.props.auth.user.branch === "00"
            ? "01"
            : page.props.auth.user.branch,
    code: null,
    name: null,
    email: null,
    phone: null,
    pin_no: null,
    card_no: null,
    gender: "M",
    dob: null,
    address: null,
    status: false,
});

function saveCustomer() {
    form.post(
        "/save-customer",
        {
            //onFinish: () => form.reset()
        },
        { preserveState: true },
    );
}

const maxDate = computed(() => {
    const today = new Date();
    today.setFullYear(today.getFullYear() - 18);
    return today.toISOString().split("T")[0];
});

</script>
<template>

    <Head :title="title" />
    <PageTitle :title="title" description="List new loyalty customer by providing the details below." />
    <!--breadcrum-->
    <Breadcrum :breadcrums="breadcrums" />
        <form
@submit.prevent="saveCustomer()" class="grid grid-cols-1 md:w-2xl md:mx-auto border rounded-md p-4 space-y-2"
        >
            <h1
class="hidden font-bold text-lg py-1 md:flex items-center justify-start uppercase"
            >
            {{ title }}
            </h1>
        <h3 class="uppercase text-md font-medium text-gray-400">select branch</h3>
        <hr />
        <!--branch selection area-->
            <select-input
                required
                must
                :disabled="$page.props.auth.user.access_level === 5"
                v-model="form.branchId"
                :error="form.errors.branchId"
                label="Branch"
class="w-full"
            >
                <option
                    v-for="(br, index) in branch"
                    :key="index"
                    :value="br.id"
                >
                    {{ br.name }}
                </option>
            </select-input>
        <h3 class="uppercase text-md font-medium mt-4 text-gray-400">personal information</h3>
        <hr />
                <div
class="grid grid-cols-1 md:grid-cols-2 gap-4 "
                >
            <text-input required v-model="form.name" :error="form.errors.name" label="Name" placeholder="Name" must
                class="w-full" />
            <text-input v-model="form.email" type="email" :error="form.errors.email" label="Email" placeholder="Email"
                class="w-full" />
            <text-input required v-model="form.phone" :error="form.errors.phone" label="Phone No" placeholder="Phone No"
                must />
            <text-input v-model="form.card_no" type="text" :error="form.errors.card_no" label="Card No"
                placeholder="Card No" class="w-full" />
            <select-input must v-model="form.gender" label="Gender" :error="form.errors.gender" class="w-full">
                <option value="M" selected>Male</option>
                <option value="F">Female</option>
                <option value="O">Others</option>
            </select-input>
            <text-input required must v-model="form.dob" type="date" :max="maxDate" :error="form.errors.dob"
                label="Date of Birth" placeholder="DOB" class="w-full" />
        </div>
        <h3 class="uppercase text-md font-medium mt-4 text-gray-400">identification & location</h3>
        <hr />
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <text-input
                        required
                        v-model="form.code"
                        :error="form.errors.code"
label="ID Number"
                        placeholder="Customer Id"
                        must
                    />
            <text-input
                        v-model="form.pin_no"
                        :error="form.errors.pin_no"
                        label="Pin No"
placeholder="Pin Number" />
                </div>
        <text-area-input v-model="form.address" :error="form.errors.address" label="Address" class="w-full mt-2" />
        <h3 class="uppercase text-md font-medium mt-4 text-gray-400">account settings</h3>
        <hr />
        <div class="p-2">
                <div
class="border rounded-md flex items-center justify-start space-x-2 w-full text-sm p-3">
                <input v-model="form.status" type="checkbox" name="status" id="status"
                    class="rounded-sm size-4 dark:bg-inherit focus:ring-0 border border-violet-400" />
                        <label
                            for="status"
class="cursor-pointer font-medium text-nowrap">Block this
                    account:</label>
                <p v-if="form.errors" class="font-medium text-red-500">
                            {{ form.errors.status }}
                </p>
                </div>
            </div>
            <hr />
            <!--buttons section-->
            <div
                class="md:px-0 px-2 w-full flex items-center md:text-sm text-xs justify-end space-x-3"
            >
            <secondary-button name="Cancel" type="button" @click="this.$inertia.get('/customers')" />
            <primary-button type="submit" name="Save" />
            </div>
    </form>
</template>
