<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SmartExport from "@/Components/SmartExport.vue";
import SmartPrint from "@/Components/SmartPrint.vue";
import PrintVoucher from "@/Components/PrintVoucher.vue";
import PageTitle from "@/Components/PageTitle.vue";
import SearchInput from "@/Components/SearchInput.vue";
import axios from "axios";
    import { provide, ref, computed, onMounted, watch } from "vue";
import {
    computedAmount,
    computedDate,
        computedTimeDate,
        getFirstDay, getLastDay
} from "@/utlis/smartFun";
import { usePage } from "@inertiajs/vue3";
    import { entry } from "@/utlis/perPageList";

// Layout (for Inertia)
defineOptions({ layout: Layout });

// State
const showPrintModal = ref(false);
const voucherDoc = ref(null);

const vouchers = ref([]);
const search = ref("");
const status = ref("All");
const perPage = ref(15);
const currentPage = ref(1);
const sortKey = ref("");
const sortAsc = ref(true);
const loading = ref(false);

const page = usePage();
    const brId = ref(page.props.auth.branch.id);
    const branches = computed(() => page.props.branches)

    const headers = computed(() => {
        return Object.keys(vouchers.value[0] || {})
            .filter((key) => key !== "branch_id")
            .map((key) => ({
                dbName: key,
                name: key
                    .split("_")
                    .map(
                        (word) =>
                            word.charAt(0).toLocaleUpperCase() + word.slice(1),
                    )
                    .join(" "),
            }));
    });

const statusKey = [
    {
        label: "All",
        class: "text-blue-600 shadow-blue-400 focus:ring-blue-600",
        id: "all",
        value: "All",
    },
    {
        label: "Used",
        class: "text-green-600 shadow-green-400 focus:ring-green-600",
        id: "ultilized",
        value: "1",
    },
    {
        label: "Not Used",
        class: "text-red-600 shadow-red-400 focus:ring-red-600",
        id: "notUsed",
        value: "0",
    },
];


const from = ref(getFirstDay.value);
const to = ref(getLastDay.value);

// Provide for child components
provide("showPrintModal", showPrintModal);
provide("voucherDoc", voucherDoc);

// Methods
const openPrintModal = (index) => {
    voucherDoc.value = index;
    showPrintModal.value = true;
};

    async function getVouchers() {

    loading.value = true;
    await axios
        .get("/get-vouchers", {
            params: {
                from: from.value,
                to: to.value,
            },
        })
        .then((res) => {
            loading.value = false;
            vouchers.value = res.data;
        })
        .catch((error) => {
            loading.value = false;
            page.props.flash.error = error.response.data;
        });
}

function firstPage() {
    currentPage.value = 1;
}
function sortBy(key) {
    if (sortKey.value === key) {
        sortAsc.value = !sortAsc.value;
    } else {
        sortKey.value = key;
        sortAsc.value = true;
    }
}
function changePage(pageNum) {
    currentPage.value = pageNum;
    // this.$emit("page-changed", pageNum); // Not needed unless emitting to parent
}
function nextPage() {
    if (currentPage.value < totalPages.value) {
        currentPage.value++;
    }
}
function prevPage() {
    if (currentPage.value > 1) {
        currentPage.value--;
    }
}

// Computed
const getCheckedStatus = computed(() => {
    if (status.value === "All") {
        return vouchers.value;
    } else if (status.value === "1") {
        return vouchers.value.filter((item) => !!item.used);
    } else {
        return vouchers.value.filter((item) => !item.used);
    }
});

const filteredData = computed(() => {
    // Reset to first page on search
    currentPage.value = 1;
    const term = search.value?.toLowerCase().trim();

    if (!term && !brId.value) return getCheckedStatus.value;

    return getCheckedStatus.value.filter((item) => {
        const matchesSearch =
            !term ||
            (item.doc_no && item.doc_no.toLowerCase().includes(term)) ||
            (item.accno && item.accno.toLowerCase().includes(term)) ||
            (item.name && item.name.toLowerCase().includes(term)) ||
            (item.description &&
                item.description.toLowerCase().includes(term)) ||
            (item.customer && item.customer.toLowerCase().includes(term)) ||
            (item.code && item.code.toString().toLowerCase().includes(term)) ||
            (item.type && item.type.toString().toLowerCase().includes(term)) ||
            (item.pin_no &&
                item.pin_no.toString().toLowerCase().includes(term)) ||
            (item.reference &&
                item.reference.toString().toLowerCase().includes(term)) ||
            (item.notes &&
                item.notes.toString().toLowerCase().includes(term)) ||
            (item.phone && item.phone.toString().toLowerCase().includes(term));

        const matchesBranch =
            !brId.value ||
            parseFloat(item.branch_id) === parseFloat(brId.value);

        return matchesSearch && matchesBranch;
    })
});

const sortedData = computed(() => {
    if (sortKey.value) {
        return _.orderBy(
            filteredData.value,
            sortKey.value,
            sortAsc.value ? "asc" : "desc",
        );
    }
    return filteredData.value;
});

const paginatedData = computed(() => {
    const start = (currentPage.value - 1) * perPage.value;
    const end = start + perPage.value;
    return sortedData.value.slice(start, end);
});

const totalPages = computed(() => {
    return Math.ceil(sortedData.value.length / perPage.value);
});

const totalAmount = computed(() => {
    const num = vouchers.value.reduce((sum, red) => sum + red.amount, 0);
    return new Intl.NumberFormat("en-Us", {
        style: "decimal",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(num);
});

const totalUsedAmount = computed(() => {
    const num = vouchers.value.reduce(
        (sum, red) => (red.used ? sum + red.amount : sum),
        0,
    );
    return new Intl.NumberFormat("en-Us", {
        style: "decimal",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(num);
});

const totalPendingAmount = computed(() => {
    const num = vouchers.value.reduce(
        (sum, red) => (!red.used ? sum + red.amount : sum),
        0,
    );
    return new Intl.NumberFormat("en-Us", {
        style: "decimal",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }).format(num);
});

// Lifecycle
    onMounted(() => {
    getVouchers();
});

    watch([from, to], () => {
        getVouchers()
    })

</script>
<template>
    <!--title part-->

    <Head title="Loyalty Vouchers" />
    <!--loalty voucher modal-->
    <print-voucher v-if="showPrintModal" />
    <!--Header section-->
    <PageTitle title="Loyalty Vouchers" />
    <!--export section-->
    <div
        class="md:p-5 p-1 flex items-center justify-end md:justify-start md:space-x-3 space-x-1"
    >
        <smart-export :transData="vouchers" name="loyalty vouchers" />
        <smart-print :exportData="vouchers" transName="Loyalty Vouchers" />
    </div>
    <!--data section-->
    <div class="md:px-6 px-1 md:text-sm text-xs space-y-1 py-3">
        <!--query section-->
        <div
class="grid md:grid-cols-2 grid-cols-1 gap-2 space-y-2 md:space-y-0"
        >
            <!--date section-->
            <div
                class="flex flex-1 md:items-center md:justify-center space-x-4 w-full"
>
                <text-input
                    label="From"
                    v-model="from"
                    type="date"
                    id="from"
                    class="w-full"
                />
                <text-input
                    label="To"
                    v-model="to"
                    type="date"
                    id="to"
                    class="w-full"
                />
            </div>
            <div class="flex items-center md:justify-end justify-start space-x-10 p-2 w-full md:w-auto">   
            <!--radio buttton section-->
            <div
                class="flex items-center md:justify-center justify-start space-x-3 p-2 w-full md:w-auto border rounded-lg text-xs"
            >
                <div
                    v-for="(list, index) in statusKey"
                    :key="index"
                    class="space-x-1 text-sm flex items-center"
                >
                    <input
                        v-model="status"
                        type="radio"
                        name="status"
                        :id="list.id"
                        :value="list.value"
                        class="text-sm focus:ring-0 dark:bg-inherit"
                    />
                    <label class="cursor-pointer text-xs text-nowrap" :for="list.id">{{
                        list.label
                    }}</label>
                </div>
            </div>
                <!---Refresh button--->
                <primary-button
                    type="submit"
                    @click="getVouchers()"
                    name="Refresh"
/>
            </div>
        </div>
        <hr />
        <!--search section-->
        <div class="grid grid-cols-3 gap-3 px-1 md:px-0">
            <div class="space-x-2 flex-1 flex items-center">
                <select-input v-model="perPage" id="entry" class="w-14">
                    <option
                        v-for="(list, index) in entry"
                        :key="index"
                        :value="list.value"
                        selected="10"
                    >
                        {{ list.name }}
                    </option>
                </select-input>
                <label for="entry" class="capitalize text-xs md:block hidden"
                    >Entries per page</label
                >
            </div>
            <select-input label="Branch" :disabled="page.props.auth.user.access_level === 5" v-model="brId" id="branch"
                class="md:w-fit w-full capitalize">
                <option value="" selected disabled>Select Branch</option>
                <option v-for="(br, index) in branches" :key="index" :value="br.id">
                    {{ br.name.toLowerCase() }}
                </option>
            </select-input>
            <search-input v-model="search" />
        </div>
        <!--table section-->
        <div
            class="w-full overflow-auto max-h-96 scrollbar-thin md:rounded-lg rounded-md shadow-sm shadow-green-100 dark:shadow-slate-500"
        >
            <table class="bg-white dark:bg-gray-900 w-full">
                <thead
class="backdrop-blur-sm shadow-sm text-xs md:text-sm sticky top-0 z-1 "
                >
                    <tr>
                        <th v-if="headers?.length > 0"
                            class="p-3 font-medium text-nowrap border border-gray-200 dark:border-gray-700">
                            #
                        </th>
                        <th
v-for="(head, index) in headers"
                            :key="index"
                            class="p-3 font-medium text-nowrap capitalize border border-gray-200 dark:border-gray-700"
                        >
                            {{ head.name }}
                        </th>
                    </tr>
                </thead>
                <tbody
                    class="text-sm text-slate-600 dark:text-slate-300 space-y-4 w-auto"
                >
                    <tr v-if="paginatedData.length === 0" class="text-xs">
                        <td colspan="15" class="p-14 text-center">
                            No Records found
                        </td>
                    </tr>
                    <tr
                        v-else
v-for="(item, rowIndex) in paginatedData" :key="rowIndex"
                        class="hover:bg-gray-50 hover:cursor-pointer dark:hover:bg-gray-700 text-xs"
                        :class="[
                            item.used
        ? 'bg-green-100 dark:bg-green-800'
                                : 'bg-white dark:bg-gray-800',
                        ]"
                    >
                        <td v-if="headers?.length > 0"
                            class="py-4 px-2 text-nowrap border border-gray-100 dark:border-gray-700 text-xs w-auto"
                        >
                            {{ (currentPage - 1) * perPage + rowIndex + 1 }}
                        </td>
                        <td v-for="(header, colIndex) in headers" :key="colIndex" :class="{
                            'text-right bg-green-300 font-medium':
                                header.dbName === 'amount' ||
                                header.dbName === 'actual_bal' ||
                                header.dbName === 'points',
                            'select-all':
                                header.dbName === 'code' ||
                                header.dbName === 'accno' ||
                                header.dbName === 'reference',
}" class="py-4 px-2 text-nowrap border border-gray-100 dark:border-gray-700 text-xs w-auto"
                        >
                            <span
                                v-if="header.dbName === 'date' || header.dbName === 'used_rdate' || header.dbName === 'expiry'">{{ computedDate(item[header.dbName]) }}
                            </span>
                            <span v-else-if="header.dbName === 'voucher'" @click="openPrintModal(item.voucher)"
                                class=" font-medium text-blue-500">
                                {{ item.voucher }} <!--:href="`/voucher/print/${item.doc_no}`"-->
                            </span>
                            <span v-else-if="header.dbName === 'input_date'" class="text-xs"
                        >
                                {{ computedTimeDate(item[header.dbName]) }}
                            </span>
                            <span v-else-if="header.dbName === 'amount'" class="text-xs"
                        >
                                {{ computedAmount(item[header.dbName]) }}
                            </span>
                            <input v-else-if="header.dbName === 'used' || header.dbName === 'printed'"
                                type="checkbox"
                                name="used"
                                id="used"
:checked="item[header.dbName]"
                                class="size-3.5 text-xs rounded-full text-teal-600 accent-teal-600"
                                disabled
/>
                            <span class="text-xs" v-else>{{
                                item[header.dbName] ?? ""
                            }}</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--pagination section-->
        <hr />
        <div
            v-if="paginatedData.length > 0"
            class="flex items-center justify-between md:text-sm text-xs"
        >
            <div>
                <p class="text-xs md:text-sm">
                    Showing {{ currentPage }} of {{ totalPages }} pages
                </p>
            </div>
            <div class="p-2 space-x-3 flex items-center justify-center">
                <button
                    @click="firstPage"
                    :disabled="currentPage === 1"
                    class="hover:text-blue-600"
                >
                    First
                </button>
                <button
                    @click="prevPage"
                    :disabled="currentPage === 1"
                    class="hover:text-blue-600"
                >
                    <i class="fa-solid fa-angles-left text-xs"></i>
                </button>

                <span
                    v-if="currentPage > 2"
                    class="text-blue-600 font-semibold px-1"
                    >...</span
                >

                <button
                    v-if="currentPage > 1"
                    @click="changePage(currentPage - 1)"
                    class="text-blue-600"
                >
                    {{ currentPage - 1 }}
                </button>
                <button
                    class="md:text-sm text-white font-medium border rounded-full bg-blue-800 border-violet-500 md:p-1 p-0.5 shadow-lg shadow-violet-400"
                >
                    {{ currentPage }}
                </button>
                <button
                    v-if="currentPage < totalPages"
                    @click="changePage(currentPage + 1)"
                    class="text-blue-600"
                >
                    {{ currentPage + 1 }}
                </button>

                <span
                    v-if="currentPage < totalPages - 1"
                    class="text-blue-600 font-semibold px-1"
                    >...</span
                >

                <button
                    @click="nextPage"
                    :disabled="currentPage === totalPages"
                    class="hover:text-blue-600"
                >
                    <i class="fa-solid fa-angles-right text-xs"></i>
                </button>
                <button
                    @click="changePage(totalPages)"
                    :disabled="currentPage === totalPages"
                    class="hover:text-blue-600"
                >
                    Last
                </button>
            </div>
        </div>
        <hr />
        <!--totals section-->
        <div
            class="flex md:items-center md:justify-center md:space-x-5 space-x-1 pb-6 py-3"
        >
            <text-input
                label="Totals"
                v-model="totalAmount"
                type="text"
                id="total"
                disabled
            />
            <text-input
                label="Used"
                t
                v-model="totalUsedAmount"
                type="text"
                id="used"
                disabled
            />
            <text-input
                label="Pending"
                v-model="totalPendingAmount"
                type="text"
                id="pending"
                disabled
            />
        </div>
    </div>
</template>
