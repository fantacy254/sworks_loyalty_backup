<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SmartExport from "@/Components/SmartExport.vue";
import SmartPrint from "@/Components/SmartPrint.vue";
import SmartTable from "@/Components/SmartTable.vue";
import PageTitle from "@/Components/PageTitle.vue";
import { computed, ref, provide } from "vue";
import ImportModal from "@/Components/ImportModal.vue";
import { useForm } from "@inertiajs/vue3";

//define layout
defineOptions({
    layout: Layout,
});

// Define props using defineProps
const props = defineProps({
    customers: Array,
    branch: Array,
    groups: Object,
    locations: Object,
    canViewCreateBtn: {
        type: Boolean,
        default: false,
    },
});

const title = "Customer masters";

// Define header as a ref or const
const headers = computed(() => {
    return Object.keys(props.customers[0] || {})
        .filter((key) => key !== "branch_id")
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});

const assignHeaders = computed(() => {
    const keys = ['accno', 'code', 'name', 'phone', 'group', 'location']
    return Object.keys(props.customers[0] || {})
        .filter((key) => keys.includes(key))
        .map((key) => ({
            dbName: key,
            name: key
                .split("_")
                .map(
                    (word) =>
                        word.charAt(0).toLocaleUpperCase() + word.slice(1),
                )
                .join(" "),
        }));
});

const search = ref('')
const filteredAssignCust = computed(() => {
    const term = search.value?.toLowerCase().trim();

    if (!term) return props.customers;

    return props.customers.filter((item) => {
        const matchesSearch =
            !term ||
            (item.accno && item.accno.toLowerCase().includes(term)) ||
            (item.name && item.name.toLowerCase().includes(term)) ||
            (item.code && item.code.toString().toLowerCase().includes(term)) ||
            (item.phone && item.phone.toString().toLowerCase().includes(term));

        return matchesSearch;
    });
})

// Define methods as functions
function deleteCustomer(user) {
    window.Swal.fire({
        icon: "warning",
        text: "Are you sure you want to delete this Customer",
        showConfirmButton: true,
        confirmButtonText: "Delete",
        confirmButtonColor: "#ff0000",
        showCancelButton: true,
    }).then((result) => {
        if (result.isConfirmed) {
            // eslint-disable-next-line no-undef
            window.Inertia.delete(`/customer/${user}`);
        }
    });
}

const showImport = ref(false);
const importHandler = () => {
    showImport.value = !showImport.value;
};

const showAssign = ref(false)
const frm = useForm({
    custs: [],
    master: 0,
    currentTemp: ''
})

function assigntoAll() {
    if (isAllChecked.value) {
        frm.custs = []
    } else {

        frm.custs = filteredAssignCust.value.map((ct) => ({
            accno: ct.accno,
            id_no: ct.code
        }))
    }
}

const isAllChecked = computed(() => {
    return filteredAssignCust.value.every(cust => frm.custs.some(ct => ct.accno === cust.accno))
})

function isChecked(acc) {
    if (!acc) return
    return frm.custs.some(ct => ct.accno === acc)
}

function toggleLineCheck(acc) {
    if (!acc) return

    if (isChecked(acc)) {
        const idx = frm.custs.findIndex(cst => cst.accno === acc)

        if (idx === -1) return

        frm.custs.splice(idx, 1)
    } else {
        const cust = filteredAssignCust.value.find(ct => ct.accno === acc)

        if (!cust) return

        frm.custs.push({
            accno: cust.accno,
            id_no: cust.code
        })
    }
}

function openAssignTemplate(temp) {
    if (frm.currentTemp === temp) return

    frm.reset()

    showAssign.value = true
    frm.currentTemp = temp
}

function closeAssignTemplate() {
    search.value = ''
    showAssign.value = false
    frm.reset()
}

function postAssignData() {
    frm.post('/loyalty/masters', {
        onSuccess: () => closeAssignTemplate()
    })
}


provide("showImport", {
    showImport,
    importHandler,
});
</script>
<template>

    <Head :title="title" />
    <!--import modal-->
    <ImportModal v-if="showImport" />
    <!--Header section-->
    <PageTitle :title="title" />
    <div class="md:p-2 flex items-center flex-col md:flex-row md:justify-start md:gap-4">
        <!--customer masters-->
        <div class="flex items-center justify-start space-x-4 border border-gray-100 md:w-auto w-full rounded-md p-2">
            <Link href="/create-customer" class="text-indigo-600 text-xs space-x-2 hover:text-indigo-900 font-normal">
            <i class="fa-solid fa-person-circle-plus text-lg"></i>
            <span class="capitalize font-medium">new customer</span>
            </Link>
            <button @click="importHandler()"
                class="capitalize text-xs font-medium border rounded-xl px-2 py-1 hover:bg-gray-100 text-gray-600">
                <i class="fa-solid fa-cloud-arrow-up"></i>
                import
            </button>
        </div>
        <!--Customer grouping-->
        <div class="flex items-center space-x-4 rounded-md w-full md:w-auto p-2">
            <button type="button" @click="openAssignTemplate('group')"
                class="text-sm px-2 py-0.5 cursor-pointer hover:scale-[1.02] border rounded-md border-violet-300 text-violet-700 hover:bg-violet-50"
                :class="{ 'bg-violet-700 scale-[1.04] shadow-sm text-white hover:text-black': frm.currentTemp === 'group' }">
                <i class="fa-solid fa-arrows-down-to-people"></i>
                Assign group
            </button>
            <button type="button" @click="openAssignTemplate('location')"
                class="text-sm px-2 py-0.5 cursor-pointer hover:scale-[1.02] border rounded-md border-pink-300 text-pink-700 hover:bg-pink-50"
                :class="{ 'bg-pink-700 scale-[1.04] shadow-sm text-white hover:text-black': frm.currentTemp === 'location' }">
                <i class="fa-solid fa-street-view"></i>
                Assign location
            </button>
        </div>
        <!--export button-->
        <div class="flex flex-1 items-center justify-end md:mx-10 space-x-2 md:space-x-3 w-full md:w-auto">
            <SmartExport :transData="customers" name="Customer Listing" />
            <SmartPrint :exportData="customers" transName="Loyalty Customers" :header="headers" />
        </div>
    </div>
    <!--Assing group and location-->
    <div v-if="showAssign" class="p-2 transition-all duration-300 ease-in-out">
        <PageTitle :title="`Assign customer(s) ${frm.currentTemp}`" />
        <!--select table-->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <!--table-->
            <div class="space-y-2 col-span-2">
                <div class="grid grid-cols-2 gap-4">
                    <p class="text-sm">Select the customers to assign {{ frm.currentTemp }}</p>
                    <!--search-->
                    <div class="flex items-center border rounded-md border-gray-300 px-2 space-y-1">
                        <i class="fa-solid fa-magnifying-glass opacity-50"></i>
                        <input v-model="search" type="text" name="search" id="seach"
                            class="w-full text-sm p-1 border-none outline-none focus:border-none focus:outline-none focus:ring-0"
                            placeholder="Search here">
                    </div>
                </div>
                <div class="max-h-96 overflow-auto scrollbar-none border rounded-md px-2">
                    <table class="table-auto w-full border">
                        <thead class="backdrop-blur-sm shadow-sm text-xs md:text-sm sticky top-0 z-1 ">
                            <tr class="text-left">
                                <th class="p-3 font-medium text-nowrap flex items-center gap-1">
                                    <input @change="assigntoAll()" type="checkbox" name="assignAll" id="assignAll"
                                        :checked="isAllChecked"
                                        class="size-3.5 rounded-xs focus:outline-none focus:ring-0 cursor-pointer">
                                    <label for="assignAll" class=" cursor-pointer">All</label>
                                </th>
                                <th v-for="(hd, index) in assignHeaders" :key="index"
                                    class="p-3 font-medium text-nowrap capitalize border border-gray-200 dark:border-gray-700">
                                    {{ hd.name }}
                                </th>
                            </tr>
                        </thead>
                        <tbody class="text-xs  min-h-full transition-all ease-in-out transform delay-150 duration-300">
                            <tr v-if="filteredAssignCust.length > 0" v-for="(item, rowIndex) in filteredAssignCust"
                                :key="rowIndex" @click="toggleLineCheck(item.accno)"
                                :class="{ 'bg-violet-100 font-semibold': isChecked(item.accno) }"
                                class="hover:bg-slate-200 font-normal capitalize hover:cursor-default text-xs mx-2 dark:hover:bg-gray-700 transition-all ease-in-out transform delay-150 duration-300">
                                <td
                                    class="p-3 border text-nowrap text-xs hover:cursor-pointer border-gray-100 border-b-gray-200 dark:border-gray-700 capitalize">
                                    <input @change="toggleLineCheck(item.accno)" type="checkbox" name="assign"
                                        id="assign"
                                        class="size-3 rounded-xs focus:outline-none focus:ring-0 cursor-pointer"
                                        :checked="isChecked(item.accno)">
                                </td>
                                <td v-for="(header, colIndex) in assignHeaders" :key="colIndex"
                                    class="p-3 text-nowrap font-normal text-xs hover:cursor-pointer border-b border-b-gray-200 dark:border-gray-700 capitalize">
                                    {{ item[header.dbName] }}
                                </td>
                            </tr>
                            <tr v-else>
                                <td :colspan="assignHeaders?.length + 1"
                                    class="p-14 text-center text-slate-500 dark:text-gray-300">
                                    No records found
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <h1 class="text-sm font-medium">Total: {{ filteredAssignCust.length }}</h1>
            </div>
            <!--assign form-->
            <div class="border rounded-2xl shadow-md p-3">
                <h1 class="text-center font-medium text-lg p-2">Assign customer(s) {{ frm.currentTemp }}</h1>
                <form @submit.prevent="postAssignData()" class="space-y-3">
                    <p class="text-sm">Customers: <strong class="text-lg">{{ frm.custs.length }}</strong></p>
                    <SelectInput v-model="frm.master" v-if="frm.currentTemp === 'group'" id="group"
                        label="Customer Group" placeholder="Select customer group" must>
                        <option v-for="gp in groups" :key="gp.id" :value="gp.id">{{ gp.name }}</option>
                    </SelectInput>
                    <SelectInput v-model="frm.master" v-if="frm.currentTemp === 'location'" id="location"
                        label="Customer Location" placeholder="Select customer location" must>
                        <option v-for="loc in locations" :key="loc.id" :value="loc.id" class="capitalize">{{ loc.name }}
                        </option>
                    </SelectInput>
                    <hr>
                    <PrimaryButton v-if="frm.custs.length > 0"
                        :name="`Assign ${frm.custs.length} customer(s) ${frm.currentTemp}`" type="submit"
                        icon="fa-brands fa-stack-exchange" class="w-full" />
                    <SecondaryButton type="reset" name="Cancel" class="w-full" @click="closeAssignTemplate()" />
                </form>
            </div>
        </div>
    </div>
    <hr>
    <div class="md:px-4 px-1 py-2">
        <SmartTable :headers="headers" :data="customers" :branches="branch" hasAction message="No records found" />
    </div>
</template>
