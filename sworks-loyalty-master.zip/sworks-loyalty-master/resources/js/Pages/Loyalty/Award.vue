<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import { provide, ref, onMounted, watch } from "vue";
import axios from "axios";
import { usePage, useForm } from "@inertiajs/vue3";
import PageTitle from "@/Components/PageTitle.vue";
import SmartSearch from "@/Components/SmartSearch.vue";
import { useAuthManager } from "@/composable/authManager";
import AuthModal from "@/Components/AuthModal.vue";

defineOptions({
    layout: Layout,
});

const props = defineProps({
    trans_type: String,
    has_auth: Boolean
})

const title = 'Award Smartpoint'
const auth = useAuthManager()

const custId = ref("");
const showModal = ref(false);

const page = usePage();

const form = useForm({
    trans_type: props.trans_type,
    name: null,
    bal: null,
    refNo: null,
    points: null,
    notes: null,
    brcode: page.props.auth.branch.id,
});

provide("showModal", showModal);
const openSearchModal = () => {
    showModal.value = true;
};

async function getCustomer(id) {
    if (!id || id === undefined || id === "") {
        return;
    }

    await axios
        .get("/getcust", {
            params: {
                id: id,
            },
        })
        .then((res) => {
            if (res.status === 200) {
                form.name = res.data.name;
                form.bal = res.data.actual_bal ? res.data.actual_bal : 0;
            }
        })
        .catch((err) => {
            page.props.flash.error = err;
        });
}

provide("custId", {
    custId,
    getCustomer,
});

async function awardCust() {
    if (confirm("You are about to award customer loyalty points. Do you want to proceed?")) {
        if (props.has_auth) {
            auth.trans = props.trans_type
            const verified = await auth.requestAuthentication()

            if (verified) {
                return form.post(
                    `/customer/${custId.value}/award-points`,
                    {
                        onSuccess: () => {
                            form.reset();
                            custId.value = "";
                        },
                    },
                    { preserveState: true },
                );
            } else {
                return
            }
        }
    }
}

watch(
    custId,
    (newVal, oldVal) => {
        if (newVal !== oldVal && newVal !== "" && newVal.length >= 8) {
            getCustomer(custId.value);
        }
        if (custId.value === "") {
            showModal.value = false;
        }
    },
    { deep: true, immediate: true },
);
</script>
<template>

    <Head :title="title" />
    <!--smart search-->
    <smart-search v-if="showModal" />
    <!--authModal-->
    <AuthModal v-if="auth.showAuth" />
    <!--Header section-->
    <PageTitle :title="title" />
    <form @submit.prevent="awardCust()"
        class="space-y-2 text-sm md:w-xl md:mx-auto w-full md:border rounded-md md:shadow-sm p-2">
        <h1 class="text-start uppercase p-2 font-semibold text-lg">{{ title }}</h1>
        <h3 class="font-semibold text-sm opacity-60 uppercase pt-2">select branch</h3>
        <hr>
        <select-input :disabled="page.props.auth.user.access_level === 5" v-model="form.brcode" label="Branch"
            id="branch" must required class="w-full">
            <option value="" selected disabled>Select Branch</option>
            <option v-for="(br, index) in page.props?.branches" :key="index" :value="br.id" class="text-xs md:text-sm">
                {{ br.name }}
            </option>
        </select-input>
        <h3 class="font-semibold text-sm opacity-60 uppercase pt-2">Customer details</h3>
        <hr>
        <!--customer Id section-->
        <div class="flex px-2 h-fit border rounded-md border-gray-400">
            <button type="button" @click="openSearchModal()"
                class="border-none focus:ring-0 focus:border-none rounded-md cursor-pointer">
                <i class="fa-solid fa-magnifying-glass text-lg opacity-50"></i>
            </button>
            <input @keyup.enter.prevent="getCustomer(custId)" @keydown.tab.prevent="getCustomer(custId)"
                v-model="custId" type="text" name="search" id="search"
                class="border-none text-xs ring-0 focus:ring-0 focus:border-none text-left w-full bg-inherit dark:text-slate-300"
                placeholder="Find customer(ID or Acc. No)" autofocus />
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <text-input label="Name" v-model="form.name" type="text" id="name" disabled :error="form.errors.name"
                class="md:w-full" />
            <text-input label="Bal" v-model="form.bal" type="text" id="bal" disabled :error="form.errors.bal" />
        </div>
        <h3 class="font-semibold text-sm opacity-60 uppercase pt-2">Transaction details</h3>
        <hr>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
            <text-input label="Points" must v-model="form.points" type="number" id="points" required
                :error="form.errors.points" />
            <text-input label="Points Value" v-model="form.points" type="number" id="value" disabled
                :error="form.errors.points" />
        </div>
        <text-input label="Ref No" v-model="form.refNo" type="text" id="ref" :error="form.errors.refNo" />
        <text-area-input label="Narration" must v-model="form.notes" id="notes"
            class="w-full p-1 text-xs md:text-sm dark:bg-inherit dark:text-slate-300 uppercase rounded-md border-violet-300"
            cols="30" rows="5" required :error="form.errors.notes" />
        <hr />
        <div class="px-2 py-1 space-x-2 flex items-center justify-end">
            <secondary-button name="Cancel" type="button" @click="this.$inertia.get('/')" />
            <primary-button name="Save" type="submit" />
        </div>
    </form>
</template>
