<script setup>
import Layout from "@/Layouts/MainLayout.vue";
import SmartExport from "@/Components/SmartExport.vue";
import SmartPrint from "@/Components/SmartPrint.vue";
import StatementTable from "@/Components/StatementTable.vue";
import SmartSearch from "@/Components/SmartSearch.vue";
import SearchButton from "@/Components/SearchButton.vue";
import { usePage } from "@inertiajs/vue3";
import { computed, provide, ref, watch, onMounted } from "vue";
import axios from "axios";
import { computedAmount, computedShortNamedDate, getFirstDay, getLastDay } from "@/utlis/smartFun";
import PageTitle from "@/Components/PageTitle.vue";

//page layout
defineOptions({ layout: Layout });

// State variables
const page = usePage();
const showModal = ref(false);
const custId = ref("");
const header = [
    { name: "Date", sort: false },
    { name: "Type", sort: false },
    { name: "Doc No.", sort: false },
    { name: "Receipt Value", sort: false },
    { name: "Points In", sort: false },
    { name: "Points Out", sort: false },
    { name: "Running Bal", sort: false },
    { name: "Reference", sort: false },
    { name: "Input By", sort: false },
    { name: "Input Date", sort: false },
];
const transData = ref([]);
const loading = ref(false);
const active = ref(null);
const fromDate = ref(getFirstDay.value);
const toDate = ref(getLastDay.value);
const currDate = ref(new Date().toISOString().split('T')[0]);
const transView = ref('timeline');
const cust = ref([]);

// Provide for child components
provide("showModal", showModal);
const openSearchModal = () => {
    showModal.value = true;
};

// Methods
async function getCustomer(id) {
    if (!id || id === undefined || id === '') {
        return;
    }
    loading.value = true;
    await axios
        .get(`/getcust`, {
            params: {
                id: id,
            },
        })
        .then((res) => {
            loading.value = false
            cust.value = res.data
        })
        .catch((err) => {
            loading.value = false;
            // Handle error as needed
            page.props.flash.error = err;
        });
}

provide("custId", {
    custId,
    getCustomer,
});

async function getStatement(id, all) {
    try {
        if (!id || id === undefined || id === "") {
            return;
        }

        loading.value = true;
        transData.value.splice(transData.length, 0);

        await axios
            .get("/loyalty/get-statement", {
                params: {
                    id: id,
                    from: fromDate.value,
                    to: toDate.value,
                    viewAll: all
                },
            })
            .then((res) => {

                loading.value = false;

                transData.value = res.data;
            })
            .catch((err) => {
                loading.value = false;
                // Handle error as needed
                page.props.flash.error = err;
            });
    } catch (error) {
        loading.value = false;
        // Handle error as needed
        page.props.flash.error = error;
    }
}

const totalIn = computed(() => {
    return transData.value.reduce((sum, row) => sum + (row.points_in || 0), 0.0,);
})

const totalOut = computed(() => {
    return transData.value.reduce((sum, row) => sum + (row.points_out || 0), 0.0,);
})

const pointsBal = computed(() => {
    return totalIn.value - totalOut.value
})

provide("custId", {
    custId,
    getCustomer,
    getStatement,
});

function handleKeyPress() {
    getCustomer(custId.value);
    getStatement(custId.value);
}

const computedData = computed(() => {
    let runningBalance = 0;
    return transData.value.map((trans) => {
        runningBalance += (trans.points_in || 0) - (trans.points_out || 0);
        return {
            ...trans,
            running_balance: runningBalance,
        };
    });
});


watch(
    [fromDate, toDate],
    () => {
        getStatement(custId.value);
    },
    { immediate: true },
);

</script>
<template>

    <Head title="Customer Statement" />
    <!--search panel-->
    <smart-search v-if="showModal" />
    <!--Header section-->
    <PageTitle title="Loyalty customer A\C statment" />
    <!--statement card-->
    <!--Customer query-->
    <div
        class="grid grid-cols-1 md:grid-cols-2 items-end gap-4 md:w-5xl md:mx-auto border border-gray-100 rounded-md p-2">
        <!--customer Id section-->
        <div class="flex px-2 h-fit border border-gray-300 rounded-md">
            <button type="button" @click="openSearchModal()"
                class="border-none focus:ring-0 focus:border-none rounded-md cursor-pointer">
                <i class="fa-solid fa-magnifying-glass text-lg opacity-50"></i>
            </button>
            <input @keyup.enter.prevent="handleKeyPress()" @keydown.tab.prevent="handleKeyPress()" v-model="custId"
                type="text" name="search" id="search"
                class="border-none text-xs ring-0 focus:ring-0 focus:border-none text-left w-full bg-inherit dark:text-slate-300"
                placeholder="Find customer(ID or Acc. No)" autofocus />
        </div>
        <!--Date range-->
        <div class="flex items-end flex-col md:flex-row flex-1 gap-3">
            <text-input type="date" id="from" label="From" placeholder="From date" v-model="fromDate" class="w-full"
                required />
            <text-input type="date" id="to" label="To" placeholder="To date" v-model="toDate" class="w-full" required />
            <!--get button-->
            <primary-button @click="getStatement(custId)" name="Get" type="submit" :loading="loading" />
        </div>
    </div>
    <!--customer analysis-->
    <div
        class="grid grid-cols-1 md:grid-cols-2 gap-4 md:w-5xl md:mx-auto rounded-md p-2 transition-all duration-300 ease-in-out mt-2">
        <!--customer details-->
        <div v-if="Object.keys(cust).length > 0"
            class="rounded-md border bg-blue-600 text-white grid grid-cols-2 p-3 md:w-md relative hover:scale-[1.03] transition-all duration-300 ease-in-out">
            <span class="absolute right-2 bottom-2 text-xs border rounded-lg px-2 py-1 capitalize shadow-sm"
                :class="[cust.active ? 'bg-green-200 text-green-600 border-green-300 shadow-green-300' : 'bg-red-200 text-red-600 border-red-300 shadow-red-300']">{{
                    cust.active ? 'active' : 'inactive' }}</span>
            <!--personal details-->
            <div>
                <p class="text-sm opacity-80">Customer </p>
                <h1 class="font-semibold text-bas p-2">{{ cust.name }}</h1>
                <p class="text-sm opacity-80">Acc no: {{ cust.accno }}</p>
                <p class="text-sm opacity-80">Phone: {{ cust.phone }}</p>
                <p class="text-sm opacity-80">Email: {{ cust.email }}</p>
            </div>
            <!--account details-->
            <div>
                <p class="text-sm opacity-80 text-end">Current balance as at</p>
                <h1 class="text-2xl font-semibold text-end">{{ computedAmount(cust.actual_bal) }}</h1>
                <p class="text-sm opacity-80 text-end">{{ computedShortNamedDate(currDate) }}</p>
            </div>
        </div>
        <!--transaction analysis-->
        <div v-if="transData.length > 0" class="grid grid-cols-2 md:grid-cols-4 gap-6 h-fit">
            <!--points in-->
            <div class="p-2 border rounded-lg h-fit shadow-sm">
                <h1 class="text-center text-xs">Points In</h1>
                <p class="font-semibold text-lg text-center p-2">{{ computedAmount(totalIn) }}</p>
            </div>
            <!--points out-->
            <div class="p-2 border rounded-lg h-fit shadow-sm">
                <h1 class="text-center text-xs">Points Out</h1>
                <p class="font-semibold text-lg text-center p-2">{{ computedAmount(totalOut) }}</p>
            </div>
            <!--net change-->
            <div class="p-2 border rounded-lg h-fit shadow-sm">
                <h1 class="text-center text-xs">Net Change</h1>
                <p class="font-semibold text-lg text-center p-2 flex text-nowrap"
                    :class="[pointsBal > 0 ? 'text-green-600' : 'text-red-600']">
                    <span v-if="pointsBal > 0">+</span>
                    <span v-else>-</span>
                    {{ computedAmount(pointsBal) }}
                </p>
            </div>
            <!--period-->
            <div class="p-2 border rounded-lg h-fit shadow-sm">
                <h1 class="text-center text-xs">Period</h1>
                <p class="font-semibold text-lg text-center p-2">{{ computedShortNamedDate(currDate) }}</p>
            </div>
        </div>
    </div>
    <!--transaction view -->
    <div class="flex items-end md:w-5xl md:mx-auto w-full rounded-md p-2">
        <h1 class="font-medium text-sm flex-1">Transaction History</h1>
        <!--view selection-->
        <div class="md:px-2">
            <div class="flex items-end gap-2">
                <!--timeline view-->
                <div class="capitalize p-2 border rounded-md text-sm cursor-pointer hover:scale-[1.03]"
                    :class="{ 'bg-blue-500 text-white scale-[1.03] shadow-sm': transView === 'timeline' }">
                    <input v-model="transView" type="radio" name="trans-view" value="timeline" id="timeline"
                        class="sr-only peer">
                    <label for="timeline">
                        <i class="fa-solid fa-arrow-trend-up"></i>
                        timeline
                    </label>
                </div>
                <!--table view-->
                <div class="capitalize p-2 border rounded-md text-sm cursor-pointer hover:scale-[1.03]"
                    :class="{ 'bg-blue-500 text-white scale-[1.03] shadow-sm': transView === 'table' }">
                    <input v-model="transView" type="radio" name="trans-view" value="table" id="table"
                        class="sr-only peer">
                    <label for="table">
                        <i class="fa-solid fa-table-list"></i>
                        table
                    </label>
                </div>
            </div>
        </div>
    </div>
    <!--transaction view-->
    <div v-if="transData.length > 0" class="md:w-5xl md:mx-auto">
        <!--timeline vuew-->
        <div v-if="transView === 'timeline'" class="overflow-auto scrollbar-thin p-2 space-y-2 max-h-96">
            <div v-for="(trn, index) in computedData" :key="index"
                class="text-sm border border-l-4 p-2 flex items-center space-x-2"
                :class="[trn.sign === '+' ? 'border-l-green-500' : 'border-l-red-500']">
                <!--date-->
                <h1 class="text-sm">{{ computedShortNamedDate(trn.run_date) }}</h1>
                <!--descriptions-->
                <div class="p-2">
                    <h1 class="flex items-center capitalize space-x-1">
                        <i class="text-xs"
                            :class="[trn.sign === '+' ? 'fa-solid fa-arrow-up text-green-600' : 'fa-solid fa-arrow-down text-red-500']"></i>
                        {{ trn.long_desc.toLowerCase() }}:&nbsp;<strong>{{ trn.sign }}{{ trn.sign === '+' ?
                            trn.points_in : trn.points_out }}</strong>
                    </h1>
                    <p>Running balance: {{ trn.running_balance }}</p>
                </div>
            </div>
        </div>
        <!--table view-->
        <Statement-Table v-if="transView === 'table'" :loading="loading" :header="header" :data="computedData" />
    </div>
    <div v-else class="p-10">
        <h1 class="text-center font-medium text-lg">No transactions in this period</h1>
        <p class="text-sm opacity-85 text-center">No activity recorded between {{ computedShortNamedDate(fromDate) }}
            and
            {{ computedShortNamedDate(toDate) }}. Try expanding the date range.
        </p>
        <div v-if="Object.keys(cust).length > 0" class="flex items-center justify-center p-2">
            <PrimaryButton @click="getStatement(cust.code, true)" type="button" icon="fa-regular fa-eye"
                name="View full history" />
        </div>
    </div>
    <hr />
    <!--Exporting buttons-->
    <div class="flex items-center justify-start px-6 py-3 mx-2 space-x-3">
        <SmartExport :transData="computedData" name="Customer Statement" />
        <SmartPrint :exportData="computedData" transName="Customer Statement" />
    </div>
</template>
