<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{{ $title }}</title>
        <style>
            table {
                width: 100%;
                min-width: 100%;
                table-layout: auto;
                margin-right: 0px;
                margin-right: 0px;
            }

            thead {
                background-color: #45b39d;
            }

            table,
            th {
                border: 0.245px solid #73c6b6;
                border-collapse: collapse;
                text-align: left;
            }

            th {
                font-weight: medium;
                padding: 4px;
                font-size: 0.9rem;
            }

            td {
                border-bottom: 0.25px solid #abb2b9;
                font-weight: medium;
                font-family: sans-serif;
                font-size: 0.675rem;
                text-transform: uppercase;
                padding: 2px;
            }

            th,
            td {
                font-style: normal;
                line-height: 1rem;
                padding: 0.45rem
            }

            tr:nth-child(even) {
                background-color: #f2f3f4;
            }

            section {
                display: flex;
                justify-content: center;
                align-items: center;
                text-align: center;
                padding: 20px;
            }

            section>div {
                max-width: 600px;
                margin: 0 auto;
            }

            .header {
                margin: 10px 0;
            }

            h1 {
                font-size: 2rem;
                margin-bottom: 3px;
            }

            p {
                font-size: 1rem;
                line-height: 1.5;
            }
        </style>
    </head>

    <body>
        <!--header section-->
        <section>
            <div>
                <h1>{{ $headers[0]->name }}</h1>
                <p class="header">{{ $headers[0]->address }}
                </p>
                <p class="header">{{ $headers[0]->pin_no }},
                    {{ $headers[0]->phone }}
                </p>
            </div>
        </section>
        <h3>{{ $title}}</h3>
        <table>
            <thead>
                <tr>
                    @foreach (array_keys($tableRows[0]) as $head)
                        <th>{{ ucfirst(str_replace('_', ' ', $head)) }}</th>
                    @endforeach
                </tr>
            </thead>
            <tbody>
                @foreach($tableRows as $item)
                    <tr>
                        @foreach ($item as $row)
                            <td>{{ $row }}</td>
                        @endforeach
                    </tr>
                @endforeach
            </tbody>
        </table>
    </body>

</html>