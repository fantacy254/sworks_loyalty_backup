<?php


return [

    /*
    |--------------------------------------------------------------------------
    | Default Notification Sender Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    |
    */

    'text_sender' => env('TEXTSMS_SHORTCODE', 'TextSMS'),

    'api_key' => env('TEXTSMS_API_KEY', 'ca3261b810d0818560d24321c3f8b30d'),

    'partner_id' => env('TEXTSMS_PARTNER_ID', 11145),

];