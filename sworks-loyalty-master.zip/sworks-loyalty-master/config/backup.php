<?php

return [

/**
 * MysQL path
 */
'mysqldump' => env('APP_ENV') === 'production'
? env('MYSQLDUMB_PROD_PATH', '/usr/bin/mysqldump') 
: env('MYSQLDUMB_DEV_PATH', 'C:\Program Files\MySQL\MySQL Server 8.0\bin\mysqldump.exe'),


'backup_email' => env('BACKUP_MAIL', 'sworksspprt@gmail.com'),

];