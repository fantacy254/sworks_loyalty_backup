<?php

namespace App\Listeners;

use App\Events\CustomerCreated;
use App\Notifications\NewCustomer;
use App\Notifications\SmsNotification;
use App\Support\SmsTemplateParser;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendCustomerCreationNotification
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(CustomerCreated $event)
    {
        if ($event->customer->email && $event->company->canSendEmail()) {
            $event->customer->notify(new NewCustomer($event->company->name));
        }

        if ($event->customer->routeNotificationForTextSms() && $event->company->canSendText()) {
            $sender = $event->company->sender();
            
            //$message = "Your account with " . $event->company->name . " has been created.\nThank you for joining us!";
            //Dear {cust_name}\nWelcome to our loyalty program!\nShop more to grow your points balance.

            $template = $event->company->smsTemplate('customer_onboard');
            $message = SmsTemplateParser::parse($template->description, [
                '{cust_name}' => $event->customer->name
            ]);


            $event->customer->notify(new SmsNotification($message, $sender, $template->temp_id, $event->company->id));
        }
    }
}
