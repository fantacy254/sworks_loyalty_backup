<?php

namespace App\Listeners;

use App\Events\DailyBackup;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Mail;

class BackupListener implements ShouldQueue
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Summary of handle
     * @param DailyBackup $event
     * @return void
     */
    public function handle(DailyBackup $event)
    {
        Mail::raw(
            'Daily backup completed successfully',
            function($message) use($event){
                $message
                ->to(config('backup.backup_email'))
                ->subject('Daily loyalty backup')
                ->attach($event->backup);
            }
        );
    }
}
