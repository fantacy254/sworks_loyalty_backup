<?php

namespace App\Listeners;

use App\Events\Authorize;
use App\Notifications\AuthorizeUser;
use App\Notifications\SmsNotification;
use App\Support\SmsTemplateParser;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Auth\MustVerifyEmail;

class sendAuthorizationNotification
{

    /**
     * Handle the event.
     *
     * @param  \App\Events\Authorize  $event
     * @return void
     */
    public function handle(Authorize $event)
    {
        if ($event->user && $event->user->hasVerifiedEmail()) {
            if ($event->user->hasEmailNotification() && $event->user->company->canSendEmail()) {
                $event->user->notify(new AuthorizeUser($event->code));
            }

            if ($event->user->hasSMSNotification() && $event->user->company->canSendText()) {
                $sender = $event->user->company->sender();

                $template = $event->user->company->smsTemplate('authentication');
                $message = SmsTemplateParser::parse($template->description, [
                    '{auth_code}' => $event->code
                ]);

                $event->user->notify(new SmsNotification($message, $sender, $template->temp_id, $event->user->company->id));
            }
        }
    }
}
