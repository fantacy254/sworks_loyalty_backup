<?php

namespace App\Listeners;

use App\Events\EarnedPoints;
use App\Notifications\EarnedSmartPoints;
use App\Notifications\SmsNotification;
use App\Support\SmsTemplateParser;

class SendEarnedPointsNotification
{

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(EarnedPoints $event)
    {
        if ($event->customer->email && $event->company->canSendEmail()) {
            $event->customer->notify(new EarnedSmartPoints($event->company->name, $event->branch->name, $event->points));
        }

        if ($event->customer->routeNotificationForTextSms() && $event->company->canSendText()) {
            $sender = $event->company->sender();

            //$message = "Dear " . $event->customer->name . ",\nYou have earned " . $event->points . " smart points.\nThank you for shopping with us!";
            //Dear {cust_name}\nYou have earned {points} smart points!\nKeep shopping to grow your points balance.

            $template = $event->company->smsTemplate('earned_points');
            $message = SmsTemplateParser::parse($template->description, [
                '{cust_name}' => $event->customer->name,
                '{points}' => $event->points,
            ]);

            $event->customer->notify(new SmsNotification($message, $sender, $template->temp_id, $event->company->id));
        }
    }
}
