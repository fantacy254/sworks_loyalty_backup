<?php

namespace App\Listeners;

use App\Events\SendBulkSMS;
use App\Notifications\SmsNotification;
use App\Support\SmsTemplateParser;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendBulkTextSMS
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(SendBulkSMS $event)
    {
        $msg = SmsTemplateParser::parse($event->message, [
            '{cust_name}' => $event->customer->name
        ]);

        $event->customer->notify(new SmsNotification($msg, $event->sender, $event->template, $event->company));
    }
}
