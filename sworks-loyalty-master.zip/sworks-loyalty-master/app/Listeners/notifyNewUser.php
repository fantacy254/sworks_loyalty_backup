<?php

namespace App\Listeners;

use App\Notifications\sendNewUserNotification;
use App\Notifications\SmsNotification;
use App\Support\SmsTemplateParser;
use Illuminate\Queue\InteractsWithQueue;

class notifyNewUser
{
    use InteractsWithQueue;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle($event)
    {

        if ($event->user) {
            if ($event->user->hasVerifiedEmail() && $event->user->hasEmailNotification() && $event->user->company->canSendEmail()) {
                $event->user->notify(new sendNewUserNotification());
            }

            if ($event->user->routeNotificationForTextSms() && $event->user->company->canSendText()) {
                $sender = $event->user->company->sender();
                //$message = "Your account has been created.\nUsername: " . $event->user->email . "\nPassword: " . $event->user->username . "\nChange your password on login.";
                //Dear {user_name}\nYour account has been created.\nUsername:  {user_email}\nPassword:  {user_password}\nChange your password on login.

                $template = $event->user->company->smsTemplate('account_creation');
                $message = SmsTemplateParser::parse($template->description, [
                    '{user_name}' => $event->user->name,
                    '{user_email}' => $event->user->email,
                    '{user_password}' => $event->user->username,
                ]);

                $event->user->notify(new SmsNotification($message, $sender, $template->temp_id, $event->user->company->id));
            }
        }
    }
}
