<?php

namespace App\Listeners;

use App\Notifications\VerifiedEmail;
use Illuminate\Auth\Events\Verified;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendEmailVerfifiedNotification
{

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  Verified  $event
     * @return void
     */
    public function handle(Verified $event)
    {
        if ($event->user && $event->user->hasVerifiedEmail()) {
            $event->user->notify(new VerifiedEmail());
        }
    }
}
