<?php

namespace App\Listeners;

use App\Events\RedeemedPoints;
use App\Notifications\RedemeedSmartPoints;
use App\Notifications\SmsNotification;
use App\Support\SmsTemplateParser;
use Carbon\Carbon;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class SendRedeemedPointsNotification
{

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(RedeemedPoints $event)
    {
        if ($event->customer->email && $event->company->canSendEmail()) {
            $event->customer->notify(new RedemeedSmartPoints($event->company->name, $event->branch->name, $event->voucher));
        }

        if ($event->customer->routeNotificationForTextSms() && $event->company->canSendText()) {
            $sender = $event->company->sender();

            //$message = "Dear " . $event->customer->name . ",\n" . $event->voucher->amount . " smart points have been redeemed.\nVoucher No: " . $event->voucher->doc_no . "\nValue: " . $event->voucher->amount . "\nExpiry: " . Carbon::parse($event->voucher->expiry)->format('jS F Y') . "\nThank you for shopping with us!";
            //Dear {cust_name},\nYou have redeemed {points} smart points.\nVoucher No:  {voucher}\nValue:  {points} \nExpiry: {expiry}\nThank you for shopping with us!

            $template = $event->company->smsTemplate('redeemed_points');
            $message = SmsTemplateParser::parse($template->description, [
                '{cust_name}' => $event->customer->name,
                '{points}' => $event->voucher->amount,
                '{voucher}' => $event->voucher->doc_no,
                '{expiry}' => Carbon::parse($event->voucher->expiry)->format('jS F Y'),
            ]);

            $event->customer->notify(new SmsNotification($message, $sender, $template->temp_id, $event->company->id));
        }
    }
}
