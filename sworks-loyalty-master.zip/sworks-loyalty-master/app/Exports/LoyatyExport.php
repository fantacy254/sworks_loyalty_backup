<?php

namespace App\Exports;

use App\Models\Loyalty;
use Maatwebsite\Excel\Excel;
use Illuminate\Support\Facades\Auth;
use Illuminate\Contracts\Support\Responsable;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\Exportable;
//use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithTitle;
//use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class LoyatyExport implements FromCollection, WithTitle, ShouldAutoSize, WithStyles
{
    use Exportable;

   /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        $query = Loyalty::select('accno', 'code', 'name', 'email', 'phone', 'actual_bal', DB::Raw('CASE WHEN status = 1 THEN "ACTIVE" ELSE "BLOCKED" END'), 'address', 'card_no', 'gender', 'dob')->get();
        return new Collection([
            //first sheet header
            [Auth::user()->company->name, '', '', '', '','', '', '', '', '', ''],
            //second sheet header
            [Auth::user()->company->address .',  '. Auth::user()->company->pin_no, '', '', '', '','', '', '', '', '', ''],
            //sheet title
            [$this->sheetHeader(), '', '', '', '', '','', '', '', '', ''],
            //headings
            [
            'Acc No',
            'ID',
            'Name',
            'Email',
            'Phone',
            'Points',
            'Status',
            'Address',
            'Card',
            'Gender',
            'Date of Birth',
            ],
            //data start
            $query
        ]); 
    }

    
    //public function headings(): array
   // {
  //      return [
 //           'Acc No',
  //          'ID',
 //           'Name',
 // //          'Email',
 //           'Phone',
 //           'Points',
 //           'Status',
  //          'Address',
   //         'Card',
   //         'Gender',
   //         'Date of Birth',
   //   //  ];
   // }

    public function sheetHeader(): String
    {
        $sheetName = 'Loyalty Customers';
        return $sheetName;
    }

    public function title(): String
    {
        return $this->sheetHeader();
    }

 //   public function startCell(): String
  //  {
  //      return 'A4';
   // }

    /**
    * Optional Writer Type
    */
    private $writerType = Excel::XLSX;


    public function styles(Worksheet $sheet)
    {
        return [
            // Merge cells for Company Name (columns A to K)
            'A1:K1' => [
                'mergeCenter' => true,
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
            ],
            // Styling for Company Name (center horizontally)
            'A2:K2' => [
                'mergeCenter' => true,
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
            ],
            // Styling for Company Name (center horizontally)
            'A3:K3' => [
                'mergeCenter' => true,
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
            ],
           
            // Styling for column 1 (Company Name)
            1 => [
                'font' => ['bold' => true, 'size' => 16],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
            ],
            // Styling for column 2 (Address)
            2 => [
                'font' => ['bold' => true, 'size' => 14],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
            ],
            // Styling for column 3 (Title)
            3 => [
                'font' => ['bold' => true, 'size' => 14],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
            ],
            //headings
            4 => [
                'font' => ['bold' => true,],
            ]
        ];
    }
}
