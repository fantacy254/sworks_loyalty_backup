<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithHeadings;

class TransExport implements FromCollection, WithHeadings
{
    protected $type;

    public function forType($type)
    {
        $this->type = $type;
    }
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        try {
            if($this->type === 'all') {
                return DB::table('loy_trans')->select('doc_no', 'type', 'run_date', 'amount', 'reference', 'notes', 'input_by')->get();
            }
            else
            {
                return DB::table('loy_trans')->where('type', $this->type)->select('doc_no', 'type', 'run_date', 'amount', 'reference', 'notes', 'input_by')->get();
            }
        } catch (\Throwable $th) {
            return $th->getMessage();
        }
       
    }
    public function headings(): Array
    {
        return [
            'Doc No.',
            'Type',
            'Date',
            'Points Value',
            'Reference',
            'Notes',
            'Input By'
        ];
    }
}
