<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class LoyaltyCustomerTemplateExport implements WithHeadings
{

    /**
     * @return array
     */
    public function headings(): array
    {
        return [
            'code',
            'name',
            'email',
            'phone',
            'pin_no',
            'card_no',
            'gender',
            'dob',
            'address',
            'acc_bal',
        ];
    }
}