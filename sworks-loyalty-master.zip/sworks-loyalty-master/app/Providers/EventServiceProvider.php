<?php

namespace App\Providers;

use App\Events\Authorize;
use App\Events\CustomerCreated;
use App\Events\DailyBackup;
use App\Events\EarnedPoints;
use App\Events\NewUser;
use App\Events\RedeemedPoints;
use App\Events\SendBulkSMS;
use App\Listeners\BackupListener;
use App\Listeners\notifyNewUser;
use App\Listeners\sendAuthorizationNotification;
use App\Listeners\SendBulkTextSMS;
use App\Listeners\SendCustomerCreationNotification;
use App\Listeners\SendEarnedPointsNotification;
use App\Listeners\SendEmailVerfifiedNotification;
use App\Listeners\SendRedeemedPointsNotification;
use App\Notifications\SmsNotification;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Events\Verified;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use App\Listeners\LogSendingMessage;
use App\Listeners\LogSentMessage;
use Illuminate\Mail\Events\MessageSending;
use Illuminate\Mail\Events\MessageSent;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        Verified::class => [
            SendEmailVerfifiedNotification::class,
        ],
        Authorize::class => [
            sendAuthorizationNotification::class
        ],
        CustomerCreated::class => [
            SendCustomerCreationNotification::class
        ],
        EarnedPoints::class => [
            SendEarnedPointsNotification::class
        ],
        RedeemedPoints::class => [
            SendRedeemedPointsNotification::class
        ],
        MessageSending::class => [
            LogSendingMessage::class,
        ],
        MessageSent::class => [
            LogSentMessage::class,
        ],
        NewUser::class => [
            notifyNewUser::class,
        ],
        SendBulkSMS::class=>[
            SendBulkTextSMS::class
        ],

        // Daily system backup
        DailyBackup::class => [
            BackupListener::class
        ]
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
