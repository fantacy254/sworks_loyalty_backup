<?php

namespace App\Services;

use App\Events\NewUser;
use App\Models\Branch;
use App\Models\Company;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;


class CompanyService
{    

    public static function generateAuthCode()
    {
        $authCode = rand(100000, 999999);
        // Store the code in the cache with a 15-minute expiry time
        Cache::put('_auth_code_' . Auth::user()->id, $authCode, now()->addMinutes(2));
        Cache::put('_authorize_user_' . Auth::user()->id, true);

        return $authCode;
    }

    public static function userCompany(User $user)
    {
        //get company ID
        $cp_id = session('company_id') !== $user->company_id ? session('company_id') : $user->company_id;

        //retrive company license
        $cp_linc = Company::where('id', $cp_id)->select('license')->value('license');

        //deconde license
        $cpDtls = base64_decode($cp_linc);

        //decode extracted json
        $cpJson = json_decode($cpDtls);

        return $cpJson->type ?? null;
    }

    public static function addCompany(
        string $name,
        string $address,
        string $email,
        string $phone,
        string $pin_no
    ) {
        try {
            DB::beginTransaction();

            $cp_db = config('database.db_prefix') . Str::of($name)->before(' ')->limit(10)->lower();
            $data = [
                'name' => Str::upper($name),
                'address' => $address,
                'email' => $email,
                'phone' => $phone,
                'pin_no' => $pin_no,
                'db' => $cp_db
            ];

            //generate license
            $licenseData = [
                'company' => $data,
                'type' => 'trial',
                'expires_at' => now()->addDays(30)->toDateString(),
            ];

            //encode license data to json
            $licenseJson = json_encode($licenseData);

            //encode json to base64
            $license = base64_encode($licenseJson);

            //create company
            $companyData = [
                ...$data,
                'sender_id' => $textSender ?? config('notification.text_sender'),
                'license' => $license,
                'token' => ApiService::generateAccessToken()
            ];

            Company::upsert($companyData, ['pin_no'], ['name', 'email', 'phone', 'license', 'token']);

            self::initializeCompany($cp_db);

            DB::commit();
        } catch (\Throwable $th) {
            Log::error('Error adding company: ' . $th->getMessage());
            DB::rollBack();
            throw $th;
        }
    }

    private static function initializeCompany(string $companyDb)
    {
        try {

            //check if database exists
            $dbExists = DB::select("SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?", [$companyDb]);

            if ($dbExists) {
                return;
            }

            //create database
            DB::statement("CREATE DATABASE IF NOT EXISTS `$companyDb`");

            // 2. Grant all privileges to the configured DB user for the new database
            try {
                $grantUser = env('DB_USERNAME', 'sworksco_support');
                $grantHost = env('DB_HOST', '127.0.0.1');
                $grantPassword = env('DB_PASSWORD', '');

                DB::statement("
                    CREATE USER IF NOT EXISTS `{$grantUser}`@`{$grantHost}`
                    IDENTIFIED BY '{$grantPassword}'
                ");

                DB::statement("
                    GRANT ALL PRIVILEGES ON `$companyDb`.*
                    TO `{$grantUser}`@`{$grantHost}`
                ");

                ////DB::connection('smart_core')->statement("FLUSH PRIVILEGES");
            } catch (\Exception $e) {
                // Log grant error but continue - user may already have privileges
                Log::warning("Could not grant privileges: " . $e->getMessage());
            }

            DynamicService::setDatabaseConnection($companyDb);

            Artisan::call('migrate', [
                '--database' => 'dynamic',
                '--force' => true
            ]);

            //run seed for master tables
            Artisan::call('db:seed', [
                '--force' => true
            ]);

        } catch (\Throwable $th) {
            Log::error('Error creating database: ' . $th->getMessage());
            throw $th;
        }
    }

    public static function addBranch(
        int $company,
        string $name,
        string|null $address = null,
        string|null $email = null,
        string|null $phone = null,
        string $input_by
    ) {
        try {

            $db = Company::findOrFail($company)->db;

            DynamicService::setDatabaseConnection($db);

            DB::beginTransaction();

            Branch::on('dynamic')->create([
                'name' => Str::upper($name),
                'address' => $address,
                'email' => $email,
                'phone' => $phone,
                'input_by' => $input_by
            ]);

            DB::commit();
        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }



    public static function setAdminUser(int $company, int $userId)
    {
        try {

            //aset user admin in company
            Company::where('id', (int) $company)
                ->update([
                    'admin' => (int) $userId
                ]);

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function addUser(string $name, string $username, string $email, string $phone, int $access_level, int $company, int $branch)
    {
        try {

            //add user
            $user = User::create([
                'name' => Str::upper($name),
                'username' => $username,
                'email' => $email,
                'phone_no' => $phone,
                'password' => Hash::make($username),
                'access_level_id' => (int) $access_level,
                'company_id' => (int) $company,
                'branch_id' => (int) $branch,
                'first_login' => true
            ]);

            event(new NewUser($user));


        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function updateNofication(
        int $company,
        string $type,
        int $value
    ) {
        try {

            Company::where('id', $company)
                ->update([
                    $type => $value,
                ]);

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function enableTwoFactor(
        int $userId,
        bool $state
    ) {
        try {
            User::where('id', $userId)
                ->update([
                    'two_factor' => $state
                ]);

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function enableSMSAuthentication(
        int $userId,
        bool $state
    ) {
        try {
            User::where('id', $userId)
                ->update([
                    'auth_sms' => $state
                ]);

        } catch (\Throwable $th) {
            throw $th;
        }
    }
    public static function enableEmailAuthentication(
        int $userId,
        bool $state
    ) {
        try {
            User::where('id', $userId)
                ->update([
                    'auth_email' => $state
                ]);

        } catch (\Throwable $th) {
            throw $th;
        }
    }


    public static function updateSender(
        int $company,
        string $sender
    ) {
        try {

            Company::where('id', $company)
                ->update([
                    'sender_id' => $sender,
                ]);

        } catch (\Throwable $th) {
            throw $th;
        }
    }
}