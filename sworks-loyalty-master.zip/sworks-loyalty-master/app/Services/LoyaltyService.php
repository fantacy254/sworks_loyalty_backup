<?php

namespace App\Services;

use App\Events\CustomerCreated;
use App\Events\EarnedPoints;
use App\Events\RedeemedPoints;
use App\Models\Branch;
use App\Models\Company;
use App\Models\Loyalty;
use App\Models\LoyMaster;
use App\Models\LoyType;
use App\Models\Master;
use App\Models\Voucher;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class LoyaltyService
{
    public static function serializeAmount($amount)
    {
        $amt = str_replace(',', '', $amount);
        return (int) $amt;
    }

    public static function generateAccNo(int $company, int $branch, string $code, string $name)
    {
        $cp = Company::findOrFail($company);
        DynamicService::setDatabaseConnection($cp->db);

        $exist = Loyalty::on('dynamic')->where('code', $code)->exists();

        if ($exist) {

            $cust = Loyalty::on('dynamic')->where('code', $code)->first();
            return (string) Str::upper($cust->accno);

        } else {

            $mst = LoyMaster::on('dynamic')
                ->where('item', 'loyalty')
                ->select('length', 'last_no')
                ->firstOrFail();

            $cust_init = Str::of($name)->ltrim()->substr(0, 1)->upper();

            do {
                $new_last = ++$mst->last_no;
                $cust_code = $cust_init . $company . $branch . str_pad($new_last, $mst->length - 1, '0', STR_PAD_LEFT);
                $chk = Loyalty::on('dynamic')->where('accno', $cust_code)->exists();
            } while ($chk);

            LoyMaster::on('dynamic')
                ->where('item', 'loyalty')
                ->update(['last_no' => $new_last]);

            return (string) Str::upper($cust_code);
        }
    }

    public static function generateTransDocNo(int $company, int $branch, string $trans_type)
    {
        $cp = Company::findOrFail($company);
        DynamicService::setDatabaseConnection($cp->db);

        $mst = LoyType::on('dynamic')
            ->where('type', $trans_type)
            ->select('last_no')
            ->firstOrFail();


        do {
            $new_last = ++$mst->last_no;
            $doc_no = $company . $branch . str_pad($new_last, 7 - 1, '0', STR_PAD_LEFT);
            $chk = DB::connection('dynamic')->table('loy_trans')->where('doc_no', $doc_no)->where('type', $trans_type)->exists();
        } while ($chk);

        return (string) Str::upper($doc_no); //12000001
    }

    public static function generateVoucherNumber(
        int $company,
        int $branch
    ) {
        $cp = Company::findOrFail($company);
        DynamicService::setDatabaseConnection($cp->db);

        $mst = Master::on('dynamic')
            ->firstOrFail();

        do {
            $new_last = ++$mst->last_redeem;

            $payload = Crypt::encrypt([
                'company' => $company,
                'branch' => $branch,
                'expiry' => now()->addDays($mst->expiry)->toDateString()
            ]);

            $doc_no = Str::upper(substr(hash('sha256', $payload), 0, 10));

            $chk = Voucher::on('dynamic')->where('doc_no', $doc_no)->exists();
        } while ($chk);

        Master::on('dynamic')
            ->update(['last_redeem' => $new_last]);

        $date = Carbon::now();

        return [
            'voucher' => $doc_no,
            'payload' => $payload,
            'days' => (int) $mst->expiry,
            'date' => Carbon::now(),
            'expiry' => $date->addDays($mst->expiry)->toDateString(),
        ];
    }

    public static function registerLoyaltyCustomer(
        int $idNo,
        string $name,
        ?string $email,
        string $phone,
        ?string $pin_no,
        ?string $card_no,
        ?string $address,
        ?bool $status,
        string $gender,
        string $dob,
        int $company,
        int $branch,
        string $inputBy
    ) {
        try {

            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            $exists = Loyalty::on('dynamic')
                ->where('code', $idNo)
                ->orWhere('name', $name)
                ->orWhere('phone', $phone)
                ->exists();

            if ($exists) {
                throw new \Exception('Customer with the provided ID number already exists');
            }

            $isAdult = Carbon::parse($dob)->lte(now()->subYears(18));
            if (!$isAdult) {
                throw new \Exception('Must be 18 years and above');
            }

            Loyalty::on('dynamic')
                ->create([
                    'accno' => self::generateAccNo($company, $branch, $idNo, $name), //T1100002
                    'code' => $idNo,
                    'name' => Str::upper(ltrim($name)),
                    'email' => $email,
                    'phone' => $phone,
                    'pin_no' => $pin_no,
                    'card_no' => $card_no,
                    'gender' => $gender,
                    'dob' => Carbon::parse($dob)->toDateString(),
                    'address' => $address,
                    'active' => $status,
                    'branch_id' => $branch,
                    'input_by' => Str::upper($inputBy),
                    'created_at' => now()
                ]);

            //notify customer of successful registration and welcome message
            $cust = Loyalty::on('dynamic')->where('code', $idNo)->first();
            
            event(new CustomerCreated($cp, $cust));

            return true;

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function updateLoyaltyCustomer(
        int $idNo,
        string $name,
        ?string $email,
        string $phone,
        ?string $pin_no,
        ?string $card_no,
        ?string $address,
        ?bool $status,
        string $gender,
        string $dob,
        int $company,
        int $branch,
        string $inputBy
    ) {
        try {

            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            $query = Loyalty::on('dynamic')
                ->where('code', $idNo);

            if (!$query->exists()) {
                throw new Exception('Customer with the provided ID number does not exist');
            }

            $loy = $query->firstOrFail();

                    $loy->name = Str::upper($name);
                    $loy->email = $email;
                    $loy->phone = $phone;
                    $loy->pin_no = $pin_no;
                    $loy->card_no = $card_no;
                    $loy->gender = $gender;
                    $loy->dob = Carbon::parse($dob)->toDateString();
                    $loy->address = $address;
                    $loy->active = $status;
                    $loy->branch_id = $branch;
                    $loy->input_by = Str::upper($inputBy);
                    $loy->created_at = now();

                    $loy->save();

            return true;

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function validateLoyaltyCustomer(int $company, string $cust_code)
    {
        try {
            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            $customer = Loyalty::on('dynamic')
                ->where('code', $cust_code)
                ->orWhere('card_no', $cust_code)
                ->orWhere('phone', $cust_code)
                ->first();

            if (!$customer) {
                throw new \Exception('Customer not found');
            }

            if (!$customer->active) {
                throw new \Exception('Customer account is inactive');
            }

            return $customer;

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function postEarnPoints(
        int $company,
        int $branch,
        string $docNo,
        string $trans_type,
        string $cust_code,
        string $date,
        string $rct_no,
        string $rct_amt,
        string $points,
        string $till_no,
        string $operator,
        string $notes = null
    ) {
        try {
            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            DB::beginTransaction();

            //reject duplicate entry
            $exists = DB::connection('dynamic')
                ->table('loy_trans')
                ->where('reference', $rct_no)
                ->where('run_date', Carbon::parse($date)->toDateString())
                ->where('branch_id', $branch)
                ->exists();

            if ($exists) {
                throw new Exception("This entry already exists");
            }

            //retrive loyalty customer
            $cust = Loyalty::on('dynamic')
                ->where('code', $cust_code)
                ->orWhere('accno', $cust_code)
                ->orWhere('card_no', $cust_code)
                ->orWhere('phone', $cust_code)
                ->firstOrFail();

            //save earn transaction
            DB::connection('dynamic')
                ->table('loy_trans')
                ->upsert([
                    'id' => (int) '100' . $docNo,
                    'doc_no' => $docNo,
                    'type' => $trans_type,
                    'run_date' => Carbon::parse($date)->toDateString(),
                    'reference' => $rct_no,
                    'amount' => $rct_amt,
                    'status' => 0,
                    'input_by' => Str::upper($operator),
                    'points' => $points,
                    'accno' => $cust->accno,
                    'period' => Carbon::parse($date)->endOfMonth()->toDateString(),
                    'notes' => $notes,
                    'branch_id' => $branch,
                    'sync' => true,
                    'till_no' => $till_no,
                    'operator' => Str::upper($operator),
                    'created_at' => now()->toDateTimeString(),
                ], ['run_date', 'reference', 'branch_id'], [
                    'id',
                    'doc_no',
                    'type',
                    'amount',
                    'status',
                    'input_by',
                    'points',
                    'accno',
                    'period',
                    'sync',
                    'till_no',
                    'operator',
                    'created_at'
                ]);

            //update customer points balance
            $cust->actual_bal += $points;
            $cust->save();

            //update trans type lastno
            LoyType::on('dynamic')
                ->where('type', $trans_type)
                ->update(['last_no' => DB::raw("COALESCE(last_no,0) + 1")]);

            DB::commit();

            //Notify customer of points earned
            event(new EarnedPoints($cp, $cust, Branch::findOrFail($branch), $points));

            return true;

        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    public static function postLoyTrans(
        int $company,
        int $branch,
        string $docNo,
        string $trans_type,
        string $cust_code,
        string $date,
        string $rct_no,
        string $rct_amt,
        string $input_by,
        string $points,
        string $till_no,
        string $operator,
        string $notes = null
    ) {
        try {
            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            DB::beginTransaction();

            //reject duplicate entry
            $exists = DB::connection('dynamic')
                ->table('loy_trans')
                ->where('reference', $rct_no)
                ->where('run_date', Carbon::parse($date)->toDateString())
                ->where('branch_id', $branch)
                ->exists();

            if ($exists) {
                throw new Exception("This entry already exists");
            }

            //retrive loyalty customer
            $cust = Loyalty::on('dynamic')
                ->where('code', $cust_code)
                ->orWhere('accno', $cust_code)
                ->orWhere('card_no', $cust_code)
                ->orWhere('phone', $cust_code)
                ->firstOrFail();

            //save earn transaction
            DB::connection('dynamic')
                ->table('loy_trans')
                ->upsert([
                    'id' => (int) '100' . $docNo,
                    'doc_no' => $docNo,
                    'type' => $trans_type,
                    'run_date' => Carbon::parse($date)->toDateString(),
                    'reference' => $rct_no,
                    'amount' => $rct_amt,
                    'status' => 0,
                    'input_by' => Str::upper($input_by),
                    'points' => $points,
                    'accno' => $cust->accno,
                    'period' => Carbon::parse($date)->endOfMonth()->toDateString(),
                    'notes' => $notes,
                    'branch_id' => $branch,
                    'sync' => true,
                    'till_no' => $till_no,
                    'operator' => Str::upper($operator),
                    'created_at' => now()->toDateTimeString(),
                ], ['run_date', 'reference', 'branch_id'], [
                    'id',
                    'doc_no',
                    'type',
                    'amount',
                    'status',
                    'input_by',
                    'points',
                    'accno',
                    'period',
                    'sync',
                    'till_no',
                    'operator',
                    'created_at'
                ]);

            //update customer points balance
            Loyalty::on('dynamic')
                ->where('code', $cust_code)
                ->orWhere('card_no', $cust_code)
                ->orWhere('phone', $cust_code)
                ->update(['actual_bal' => DB::raw("COALESCE(actual_bal,0) - {$points}")]);

            //update trans type lastno
            LoyType::on('dynamic')
                ->where('type', $trans_type)
                ->update(['last_no' => DB::raw("COALESCE(last_no,0) + 1")]);

            DB::commit();

            if ($trans_type !== 'RED') {
                event(new EarnedPoints($cp, $cust, Branch::findOrFail($branch), $points));
            }

            return true;

        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    public static function postPointsAdjustment(
        int $company,
        int $branch,
        string $docNo,
        string $trans_type,
        string $cust_code,
        string $rct_no,
        string $points,
        string $till_no,
        string $operator,
        string $notes = null
    ) {
        try {
            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            DB::beginTransaction();

            //reject duplicate entry
            $exists = DB::connection('dynamic')
                ->table('loy_trans')
                ->where('reference', $rct_no)
                ->where('run_date', Carbon::parse(now())->toDateString())
                ->where('branch_id', $branch)
                ->exists();

            if ($exists) {
                throw new Exception("This entry already exists" . $rct_no);
            }

            //retrive loyalty customer
            $cust = Loyalty::on('dynamic')
                ->where('code', $cust_code)
                ->firstOrFail();

            //save earn transaction
            DB::connection('dynamic')
                ->table('loy_trans')
                ->upsert([
                    'id' => (int) '100' . $docNo,
                    'doc_no' => $docNo,
                    'type' => $trans_type,
                    'run_date' => Carbon::parse(now())->toDateString(),
                    'reference' => $rct_no,
                    'amount' => $points,
                    'status' => 0,
                    'input_by' => Str::upper($operator),
                    'points' => $points,
                    'accno' => $cust->accno,
                    'period' => Carbon::parse(now())->endOfMonth()->toDateString(),
                    'notes' => $notes,
                    'branch_id' => $branch,
                    'sync' => true,
                    'till_no' => $till_no,
                    'operator' => Str::upper($operator),
                    'created_at' => now(),
                ], ['run_date', 'reference', 'branch_id'], [
                    'id',
                    'doc_no',
                    'type',
                    'amount',
                    'status',
                    'input_by',
                    'points',
                    'accno',
                    'period',
                    'sync',
                    'till_no',
                    'operator',
                    'created_at'
                ]);

            $typ = LoyType::on('dynamic')
                ->where('type', $trans_type)
                ->firstOrFail();

            //update customer points balance
            Loyalty::on('dynamic')
                ->where('code', $cust_code)
                ->update(['actual_bal' => DB::raw("COALESCE(actual_bal,0) {$typ->sign} {$points}")]);

            //update trans type lastno
            LoyType::on('dynamic')
                ->where('type', $trans_type)
                ->update(['last_no' => DB::raw("COALESCE(last_no,0) + 1")]);

            DB::commit();

            return true;

        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    public static function postVoucher(
        int $company,
        int $branch,
        string $docNo,
        string $payload,
        string $refNo,
        string $cust_code,
        string $points,
        string $input_by,
        string $expiry
    ) {
        try {
            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            DB::beginTransaction();

            //retrive loyalty customer
            $cust = Loyalty::on('dynamic')
                ->where('code', $cust_code)
                ->orWhere('accno', $cust_code)
                ->orWhere('card_no', $cust_code)
                ->orWhere('phone', $cust_code)
                ->firstOrFail();

            Voucher::on('dynamic')
                ->insert([
                    'doc_no' => $docNo,
                    'payload' => $payload,
                    'our_ref' => $refNo,
                    'date' => now()->toDateString(),
                    'cust_accno' => $cust->accno,
                    'cust_name' => $cust->name,
                    'cust_code' => $cust->code,
                    'amount' => $points,
                    'used' => false,
                    'input_by' => $input_by,
                    'input_date' => now(),
                    'printed' => true,
                    'expiry' => Carbon::parse($expiry)->toDateString(),
                    'points' => $points,
                    'br_code' => $branch
                ]);


            //notify redeemable customer
            $br = Branch::findOrFail($branch);
            $vc = Voucher::on('dynamic')->where('doc_no', $docNo)->firstOrFail();

            DB::commit();

            Log::info('Notify', [$vc]);
            event(new RedeemedPoints($cp, $cust, $br, $vc));

            return true;

        } catch (\Throwable $th) {
            DB::rollBack();
            throw $th;
        }
    }

    public static function validateVoucher(
        int $company,
        int $branch,
        string $voucher
    ) {
        try {

            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            $exists = Voucher::on('dynamic')->where('doc_no', $voucher);

            if (!$exists->exists()) {
                throw new Exception("Invalid Voucher provided");
            }

            $vc = $exists->select('doc_no', 'date', 'cust_accno', 'cust_name', 'cust_code', 'amount', 'used', 'expiry', 'payload')
                ->where('doc_no', $voucher)
                ->firstOrFail();

            Log::info($vc->payload);

            $voucherData = Crypt::decrypt($vc->payload);

            if (!isset($voucherData['company']) || !isset($voucherData['branch']) || !isset($voucherData['expiry'])) {
                throw new Exception("Invalid Voucher provided");
            }

            if ($voucherData['company'] !== $company) {
                throw new Exception("Voucher provided does not belong to this company");
            }

            if (Carbon::parse($vc->expiry)->lessThan(Carbon::today())) {
                throw new Exception("Voucher has Expired");
            }

            if ($vc->used) {
                throw new Exception("Voucher has been used");
            }

            return $vc->only('doc_no', 'date', 'cust_accno', 'cust_name', 'cust_code', 'amount', 'used', 'expiry');

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function consumeVoucher(
        int $company,
        int $branch,
        string $voucher,
        string $date,
        string $rct_no,
        string $till,
        string $operator
    ) {
        try {
            $cp = Company::findOrFail($company);
            DynamicService::setDatabaseConnection($cp->db);

            self::validateVoucher(
                $company,
                $branch,
                $voucher
            );

            Voucher::on('dynamic')
                ->where('doc_no', $voucher)
                ->update([
                    'used' => true,
                    'used_date' => Carbon::parse($date)->toDateString(),
                    'used_branch' => $branch,
                    'used_receipt' => $rct_no,
                    'used_rdate' => Carbon::parse($date)->toDateString(),
                    'used_till' => $till,
                    'edit_by' => $operator,
                ]);

            return true;
        } catch (\Throwable $th) {
            throw $th;
        }
    }
}