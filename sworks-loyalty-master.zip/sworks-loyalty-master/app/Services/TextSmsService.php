<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;

class TextSmsService
{
    protected $apiKey;
    protected $partnerId;

    public function __construct()
    {
        $this->apiKey = config('notification.api_key');
        $this->partnerId = config('notification.partner_id');
        //$this->shortCode = env('TEXTSMS_SHORTCODE');
    }

    public function sendSms($mobile, $message, $sender, $template, $company)
    {
        try {

            $url = 'https://sms.textsms.co.ke/api/services/sendsms';
            $response = Http::post($url, [
                'apikey' => $this->apiKey,
                'partnerID' => $this->partnerId,
                'message' => $message,
                'shortcode' => $sender,
                'mobile' => $mobile
            ]);

            $data = $response->json();
            //Log::info('Text Response', $data);

            // Top-level error response
            if (isset($data['response-code']) && $data['response-code'] != 200) {
                //Log::error('Unknown API error');
                throw new Exception($data['response-description'] ?? 'Unknown API error');
            }

            // Success response structure
            if (isset($data['responses'][0])) {
                $result = $data['responses'][0];

                if (($result['response-code'] ?? 0) != 200) {
                    //Log::error('Unknown API error');
                    throw new Exception($result['response-description'] ?? 'Unknown API error');
                }
            }

            DB::connection('smart_core')
                ->table('sms_trans')
                ->insert([
                    'phone' => $mobile,
                    'message' => $message,
                    'sms_temp' => $template,
                    'sender' => $sender,
                    'company_id' => $company,
                    'sent' => true,
                    'initiator' => Auth::user() ? Auth::user()->username : 'Smartpos',
                    'created_at' => now(),
                ]);

            //Log::info('SMS Usage saved');

            Session::flash('success', 'SMS has been sent to ' . $result['mobile']);


        } catch (\Throwable $th) {
            //Log::debug('Text error ' . $th->getMessage());

            Session::flash('error', $th->getMessage());
            //throw $th;
        }
    }
}