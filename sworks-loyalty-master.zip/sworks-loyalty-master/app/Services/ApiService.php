<?php

namespace App\Services;

use App\Models\AccessToken;
use App\Models\Branch;
use App\Models\Company;
use App\Models\User;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;


class ApiService
{
    public static function generateAccessToken()
    {
        $token = AccessToken::generateApiToken();

        return $token;
    }

    public static function generateClientKey(
        int $companyId,
        int $branchId
    ) {
        try {

            $db = Company::where('id', $companyId)->select('db')->value('db');
            DynamicService::setDatabaseConnection($db);

            $key = Crypt::encrypt([
                'company' => $companyId,
                'branch' => $branchId,
                'time' => now()->addDays(365)->toDateTimeString(),
            ]);

            Branch::on('dynamic')->where('id', $branchId)->update(['client_key' => $key]);

            return true;

        } catch (\Throwable $th) {
            Log::error($th);
            throw $th;
        }
    }

    public static function getClientKeyData(string $key)
    {
        try {
            if (!$key) {
                return;
            }

            $data = Crypt::decrypt($key);

            if (!$data) {
                return;
            }

            return $data;

        } catch (\Throwable $th) {
            throw $th;
        }
    }

    public static function createSystemUser(
        string $name,
        string $username,
        string $email,
        string $phone_no,
        string $password,
        int $access_level_id,
        int $company,
        int $branch
    ) {
        try {

            User::upsert([
                [
                    'name' => $name,
                    'username' => $username,
                    'email' => $email,
                    'phone_no' => $phone_no,
                    'email_verified_at' => now(),
                    'password' => Hash::make($password),
                    'access_level_id' => $access_level_id ?? 5,
                    'company_id' => $company,
                    'branch_id' => $branch,
                    'multi_access' => false,
                    'first_login' => true,
                ]
            ], ['username', 'email'], ['name', 'phone_no', 'email_verified_at', 'password', 'access_level_id', 'company_id', 'branch_id', 'multi_access']);


            return true;

        } catch (\Throwable $th) {
            throw $th;
        }
    }
}