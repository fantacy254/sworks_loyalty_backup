<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use PDO;

class DynamicService
{
    public static function setDatabaseConnection(string $companyDb)
    {
        if ($companyDb === 'smart_core') {
            return; // Skip setting connection if it's smart_core
        }

        $dbConfig = [
            'driver' => 'mysql',
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => $companyDb,
            'username' => env('DB_USERNAME', 'sworksco_support'),
            'password' => env('DB_PASSWORD', '$m@rt$#123'),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
            'options' => extension_loaded('pdo_mysql') ? array_filter([
                PDO::MYSQL_ATTR_SSL_CA => env('MYSQL_ATTR_SSL_CA'),
            ]) : [],
        ];

        config(['database.connections.dynamic' => $dbConfig]);

        DB::purge('dynamic');
        DB::setDefaultConnection('dynamic');
    }
}