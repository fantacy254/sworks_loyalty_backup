<?php

namespace App\Services;

use Google\Client;
use Google\Service\Drive;
use Google\Service\Drive\DriveFile;

class GoogleDriveService{

    protected Drive $drive;

    public function __construct()
    {
    $client = new Client();

    $client->setAuthConfig(
        config('services.google_drive.credentials')
    );
    $client->addScope(Drive::DRIVE);

    $this->drive = new Drive($client);
    }

    /**
     * Summary of uploadFile
     * @param string $filePath
     * @param string $fileName
     * @param mixed $fileId
     * @return void
     */
    public function uploadFile(string $filePath, string $fileName, ?string $fileId = null)
    {
        
        $fileMetadata = new DriveFile([
            'name' => $fileName,
            'parents' => [ $fileId ?? config('services.google_drive.folder_id')]
        ]);

        $content = file_get_contents($filePath);

        $this->drive->files->create($fileMetadata, [
            'data' => $content,
            'mimeType' => 'application/octet-stream',
            'uploadType' => 'resumable',
            'supportsAllDrives' => true,
            'fields' => 'id,name,size,webViewLink'
        ]);


    }
}