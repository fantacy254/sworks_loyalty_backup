<?php

namespace App\Console\Commands;

use App\Services\DynamicService;
use Illuminate\Console\Command;
use App\Models\Company;
use Illuminate\Support\Facades\DB;

class MigrateDynamicConnections extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migrate:dynamic {--path=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run migrations on all dynamic connections';

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * 
     */
    public function handle()
    {
        $companies = Company::all();

        foreach ($companies as $company) {
            if ($company->db !== 'sworksco_core') {
                DynamicService::setDatabaseConnection($company->db);
                $this->info("Migrating database for company: {$company->name}");

                $this->call('migrate', [
                    '--database' => 'dynamic',
                    '--path' => 'database/migrations',
                ]);
            } else {
                $this->info("Skipping migration for core database.");
            }
        }

        $this->info('All migrations completed successfully.');
    }
}
