<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class MigrateSmartCore extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migrate:smartcore {--path=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run migrations on smart core connection';

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Running migrations on smart core connection...');

        $this->call('migrate', [
            '--database' => 'smart_core',
            '--path' => 'database/migrations',
        ]);

        $this->info('Smart Core migrations completed successfully.');

        return 0;
    }
}
