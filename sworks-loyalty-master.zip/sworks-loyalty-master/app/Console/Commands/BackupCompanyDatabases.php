<?php

namespace App\Console\Commands;

use App\Events\DailyBackup;
use App\Models\Company;
use App\Services\DynamicService;
use App\Services\GoogleDriveService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Symfony\Component\Process\Process;
use ZipArchive;

class BackupCompanyDatabases extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'backup:companies';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run dynamic backup for all registered companies.';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle()
    {
        $companies = Company::all();
        
        $backupDir = storage_path('backups');

        foreach ($companies as $company) {
            try {

                DynamicService::setDatabaseConnection($company->db);

                $cpName = explode(' ', $company->name)[0];

                if (!file_exists($backupDir)) {
                    mkdir($backupDir, 0755, true);
                }

                $today = now()->format('Y-m-d');

                $todayBackups = glob(
                    $backupDir . '/' . $cpName . '_' . $today . '_*.sql.zip'
                ) ?: [];

                if (count($todayBackups) >= 2) {
                    $this->info(
                        "Skipping {$company->name}: already has "
                        . count($todayBackups)
                        . " backups for today. Deleting old files."
                    );

                    // Delete old backups
                    $this->deleteOldBackup($backupDir);

                    continue;
                }


                $filename = $backupDir . '/'
                    . $cpName . '_'
                    . now()->format('Y-m-d_H-i-s')
                    . '.sql';

                $mysql_dump = config('backup.mysqldump');

                $command = [
                    $mysql_dump,
                    '-h' . env('DB_HOST', '127.0.0.1'),
                    '-P' . env('DB_PORT', '3306'),
                    '-u' . env('DB_USERNAME', 'sworksco_support'),
                    '-p' . env('DB_PASSWORD', '$m@rt$#123'),
                    $company->db,
                    '--result-file=' . $filename
                ];

                $process = new Process($command);
                $process->run();

                if (!$process->isSuccessful()) {
                    $this->error("Error processing backup for {$company->name}: {$process->getErrorOutput()}");
                    logger()->error("Error processing backup for {$company->name}: {$process->getErrorOutput()}");
                }

                $zipFile = $filename . '.zip';

                $this->zipBackupFile($zipFile, $filename);

                $this->deleteOldBackup($backupDir);

                $this->info($company->name . ' backed up.');

                /**Upload to Google Drive
                $googleDriveService = new GoogleDriveService();
        
                $googleDriveService->uploadFile($zipFile, basename($zipFile));

                $this->info('Uploaded '.$company->name.' successfully');*/

            } catch (\Exception $e) {
                $this->error("Error backing up {$company->name}: {$e->getMessage()}");
            }
        }

        // Create daily backup file
        $dailyZip = $this->createDailyBackupZip($backupDir);

        if ($dailyZip) {
            event(new DailyBackup($dailyZip));

            $this->info('Daily backup archive created and mail event triggered.');
        }

        $this->info('Backup complete for all companies');
    }

    private function zipBackupFile(string $zipFile, string $filename)
    {
        $zip = new ZipArchive;

        if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $zip->addFile($filename, basename($filename));
            $zip->close();

            unlink($filename);
        }

    }

    /**
     * Summary of deleteOldBackup
     * @param string $backupDir
     * @return void
     */
    private function deleteOldBackup(string $backupDir)
    {
        $maxBackupDays = (int) env('Max_Backup_Days', 3);
        $minimumDailyBackups = 2;
        $cutoff = now()->subDays($maxBackupDays)->timestamp;

        $files = collect(File::files($backupDir))
            ->filter(function ($file) {
                return preg_match(
                    '/^(.+)_(\d{4}-\d{2}-\d{2})_\d{2}-\d{2}-\d{2}\.sql\.zip$/',
                    $file->getFilename()
                );
            })
            ->sortByDesc(fn ($file) => $file->getMTime())
            ->values();

        // Group by company name and backup date
        $groupedFiles = $files->groupBy(function ($file) {
            preg_match(
                '/^(.+)_(\d{4}-\d{2}-\d{2})_\d{2}-\d{2}-\d{2}\.sql\.zip$/',
                $file->getFilename(),
                $matches
            );

            return $matches[1] . '|' . $matches[2];
        });

        foreach ($groupedFiles as $dailyFiles) {
            $dailyFiles = $dailyFiles
                ->sortByDesc(fn ($file) => $file->getMTime())
                ->values();

            foreach ($dailyFiles as $index => $file) {
                // Always keep at least 2 backups per company per day
                if ($index < $minimumDailyBackups) {
                    continue;
                }

                // Delete expired backups beyond the minimum
                if ($file->getMTime() < $cutoff || $index >= $minimumDailyBackups) {
                    File::delete($file->getPathname());
                }
            }
        }
    }

    /**
     * Summary of createDailyBackupZip
     * @param string $backupDir
     * @throws \RuntimeException
     * @return string|null
     */
    private function createDailyBackupZip(string $backupDir)
    {
        $today = now()->format('Y-m-d');

        $dailyZip = $backupDir . '/daily_backup_' . $today . '.zip';

        //check if files already exists
        if(File::exists($dailyZip)){
            $this->info("Daily backup already exists. Skipping: {$dailyZip}");

            return null;
        }


        // Find all company backup ZIPs created today
        $files = collect(File::files($backupDir))
            ->filter(function ($file) use ($today) {
                return preg_match(
                    '/^.+_' . preg_quote($today, '/') .
                    '_\d{2}-\d{2}-\d{2}\.sql\.zip$/',
                    $file->getFilename()
                );
            });

        if ($files->isEmpty()) {
            $this->warn('No backup files found for today.');

            return null;
        }

        $zip = new ZipArchive();

        $result = $zip->open(
            $dailyZip,
            ZipArchive::CREATE | ZipArchive::OVERWRITE
        );

        if ($result !== true) {
            throw new \RuntimeException(
                "Could not create daily backup archive: {$dailyZip}"
            );
        }

        foreach ($files as $file) {
            $zip->addFile(
                $file->getPathname(),
                $file->getFilename()
            );
        }

        if (!$zip->close()) {
            throw new \RuntimeException(
                "Could not finalize daily backup archive: {$dailyZip}"
            );
        }

        $this->info("Created daily archive: {$dailyZip}");

        return $dailyZip;
    }
}
