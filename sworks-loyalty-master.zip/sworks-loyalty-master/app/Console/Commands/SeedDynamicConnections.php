<?php

namespace App\Console\Commands;

use App\Services\DynamicService;
use Illuminate\Console\Command;
use App\Models\Company;
use Illuminate\Support\Facades\DB;

class SeedDynamicConnections extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'db:seed:dynamic {--class=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Seed all dynamic connections, excluding smart_core';
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * 
     */
    public function handle()
    {
        $companies = Company::all();
        $seederClass = $this->option('class') ?: 'DatabaseSeeder';

        foreach ($companies as $company) {
            if ($company->db !== 'smart_core') {
               DynamicService::setDatabaseConnection($company->db);
                $this->info("Seeding database for company: {$company->name}");

                $this->call('db:seed', [
                    '--class' => $seederClass,
                    '--database' => 'dynamic',
                ]);
            } else {
                $this->info("Skipping seeding for smart_core database.");
            }
        }

        $this->info('Seeding completed for all dynamic databases, excluding smart_core.');
    }
}
