<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class MigrateFreshSmartCore extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'migrate:smartcore:fresh';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Run fresh migrations on smart core connection';

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Running fresh migrations on smart core connection...');

        $this->call('migrate:fresh', [
            '--database' => 'smart_core',
            '--path' => 'database/migrations',
        ]);

        $this->info('Smart Core fresh migrations completed successfully.');

        return 0;
    }
}
