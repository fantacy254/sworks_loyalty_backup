<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Branch extends Model
{
    use HasFactory;


    /**
     * The database connection that should be used by the model.
     *
     * @var string
     */
    protected $connection = 'dynamic';
    
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'branch';

    /**
     * 
     * define potected connection
     * 
     */
    

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'id';
    /**
     * 
     * define fillables for branch
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'mpesa_till',
        'phone',
        'address',
        'input_by',
        'edit_by'
    ];

    /**
     * 
     * get company associated with the company
     * 
     */
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * 
     * get user branch
     * 
     */
    public function user()
    {
        return $this->hasOne(User::class);
    }

    public function customers()
    {
        return $this->hasMany(Loyalty::class);
    }

}
