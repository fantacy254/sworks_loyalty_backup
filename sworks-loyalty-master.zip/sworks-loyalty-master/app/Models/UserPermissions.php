<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserPermissions extends Model
{
    use HasFactory;

    /**
     * 
     * specify table
     */
    protected $table = 'user_permissions';

    /**
     * 
     * define connection
     * 
     */
    protected $connection = 'smart_core';

    /**
     * 
     * permissions relationship with user model
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
