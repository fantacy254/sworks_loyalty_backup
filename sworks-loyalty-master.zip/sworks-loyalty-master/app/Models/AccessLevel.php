<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccessLevel extends Model
{
    use HasFactory;

    /**
     * define model connection
     * @var string
     */
    protected $connection = 'smart_core';

    /**
     * define model table
     * @var string
     */
    protected $table = 'access_level';

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'id';

    public function users()
    {
        return $this->hasMany(User::class);
    }
}
