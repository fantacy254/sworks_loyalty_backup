<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Company extends Model
{
    use HasFactory;

    /**
     * The database connection that should be used by the model.
     *
     * @var string
     */
    protected $connection = 'smart_core';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'company';

    protected $fillable = [
        'name',
        'address',
        'phone',
        'pin_no',
        'vat_no',
        'email',
        'db',
        'license'
    ];

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'id';

    /**
     * 
     * get company user is associated to
     * 
     */
    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function sysAdmin()
    {
        return $this->belongsTo(User::class,'admin');
    }

    /**
     * 
     * get all branches associated with the company
     * 
     */
    public function branches()
    {
        return $this->hasMany(Branch::class);
    }

    /**
     * 
     * get all branches associated with the company
     * 
     */
    public function loyCustomer()
    {
        return $this->hasMany(Loyalty::class);
    }

    public function canSendText()
    {
        return $this->send_sms === 1 ? true : false;
    }

    public function sender()
    {
        return $this->sender_id;
    }

    public function canSendEmail()
    {
        return $this->send_email === 1 ? true : false;
    }

    public function smsTemplate($temp_id)
    {
        return SMSTemplate::on('smart_core')
            ->where('temp_id', $temp_id)
            ->where(function ($query) {
                $query->where('company_id', $this->id)
                    ->orWhereNull('company_id');
            })
            ->orderByRaw('CASE WHEN company_id = ? THEN 0 ELSE 1 END', [$this->id])
            ->first();
    }

}
