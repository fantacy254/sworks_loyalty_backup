<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoyMaster extends Model
{
    use HasFactory;
      /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $attributes = [
        'status' => true,
    ];

     /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'loy_masters';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'item',
        'last_no',
        'length',
        'status',
        'notes',
    ];
}
