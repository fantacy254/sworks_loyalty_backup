<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class AccessToken extends Model
{
    use HasFactory;

    /**
     * The database connection that should be used by the model.
     *
     * @var string
     */
    protected $connection = 'smart_core';

    protected $hidden = [
        'api_token'
    ];

    protected $casts = [
        'verified_at' => 'datetime'
    ];

    protected $fillable = [
        'api_token',
        'verified_at',
    ];

    /**
     * generate new API token
     *
     */
    public static function generateApiToken()
    {
        return self::create([
            'api_token' => Str::random(80),
            'verified_at' => now(),
        ])->api_token;
    }
}
