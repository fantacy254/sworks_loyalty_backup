<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoyType extends Model
{
    use HasFactory;

    /**
     * define model connection
     * @var string
     */
    protected $connection='dynamic';

    /**
     * cast column values
     * 
     */
    protected $casts=[
    'auth'=> 'bool',
    'print'=> 'bool',
    'show'=> 'bool',
    ];

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'loy_type';
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'last_no',
    ];

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = false;
}
