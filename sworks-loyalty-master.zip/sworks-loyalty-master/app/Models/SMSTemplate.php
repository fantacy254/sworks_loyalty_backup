<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SMSTemplate extends Model
{
    use HasFactory;

    /**
     * The database connection that should be used by the model.
     *
     * @var string
     */
    protected $connection = 'smart_core';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'sms_template';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'temp_id',
        'name',
        'description',
        'company_id',
        'level',
        'input_by',
        'edit_by'
    ];

    public function texts()
    {
        return $this->hasMany(SMS::class, 'sms_temp', 'id');
    }
}
