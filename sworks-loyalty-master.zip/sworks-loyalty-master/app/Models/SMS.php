<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SMS extends Model
{
    use HasFactory;

    /**
     * The database connection that should be used by the model.
     *
     * @var string
     */
    protected $connection = 'smart_core';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'sms_trans';

    public function template()
    {
        return $this->belongsTo(SMSTemplate::class, 'sms_temp');
    }
}
