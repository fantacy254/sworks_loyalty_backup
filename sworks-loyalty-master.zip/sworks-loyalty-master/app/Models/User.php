<?php

namespace App\Models;

use App\Http\Controllers\CompanyDetails;
use App\Notifications\sendVerificationMail;
use Illuminate\Contracts\Auth\MustVerifyEmail as MustVerifyEmailContract;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Illuminate\Support\Facades\Gate;
use Illuminate\Database\Eloquent\SoftDeletes;

class User extends Authenticatable implements MustVerifyEmailContract
{
    use HasApiTokens, Notifiable; //HasFactory
    use SoftDeletes;

    /**
     * 
     * define model connection
     * 
     */
    protected $connection = 'smart_core';

    /**
     * Summary of table
     * @var string
     */
    protected $table = 'users';
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'company_id',
        'name',
        'username',
        'email',
        'password',
        'phone_no',
        'access_level_id',
        'br_code',
        'multi_access'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * get company associated with the user
     * 
     */
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    /**
     * 
     * get user branch
     */
    // public function branch()
    //{
    //   return $this->hasOne(Branch::class);
    //}

    /**
     * 
     * user relationship with permissions
     * 
     */
    public function permissions()
    {
        return $this->hasMany(UserPermissions::class);
    }

    /**
     * 
     * define user access level
     */
    public function AccessLevel()
    {
        return $this->belongsTo(AccessLevel::class);
    }

    /**
     * class to notify users through sms
     * 
     */
    public function routeNotificationForTextSms()
    {
        return $this->phone_no;
    }

    /**
     * 
     * return user multi user
     * @return boolean
     * 
     */
    public function isMultiCompanyAccess()
    {
        return $this->multi_access === 0 ? false : true;
    }

    /**
     * 
     * return user admin status
     * @return boolean
     * 
     */
    public function isAdmin()
    {
        return $this->access_level_id === 2 ? true : false;
    }

    /**
     * 
     * return user login status
     * @return boolean
     * 
     */
    public function isFirstLogin()
    {
        return $this->first_login === 1 ? true : false;
    }

    public function hasSMSNotification()
    {
        return $this->auth_sms === 1 ? true : false;
    }

    public function hasEmailNotification()
    {
        return $this->auth_email === 1 ? true : false;
    }
}
