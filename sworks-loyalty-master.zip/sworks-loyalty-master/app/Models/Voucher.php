<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Voucher extends Model
{
    use HasFactory;

    protected $connection = 'dynamic';


    protected $primaryKey = 'doc_no';

    public $incrementing = false;

    protected $keyType = 'string';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'voucher';
    /**
     * 
     * define fillables for branch
     * @var array
     */
    protected $fillable = [
        'doc_no',
        'payload',
        'date',
        'cust_accno',
        'cust_name',
        'cust_code',
        'amount',
        'used',
        'input_by',
        'input_date',
        'edit_by',
        'edit_date',
        'printed',
        'expiry',
        'points',
        'br_code',
        'used_date',
        'used_branch',
        'used_receipt',
        'used_rdate',
        'used_till',
        'sync_stamp',
    ];

    /**
     * The name of the "created at" column.
     *
     * @var string|null
     */
    public const CREATED_AT = 'input_date';

    /**
     * The name of the "updated at" column.
     *
     * @var string|null
     */
    public const UPDATED_AT = 'edit_date';

}
