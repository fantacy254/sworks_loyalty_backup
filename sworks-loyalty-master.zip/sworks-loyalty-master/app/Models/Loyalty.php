<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;

class Loyalty extends Model
{
    use HasFactory, SoftDeletes, Notifiable;

    protected $connection = 'dynamic';

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'code';

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'loy_customer';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'accno',
        'code',
        'name',
        'email',
        'phone',
        'card_no',
        'actual_bal',
        'bal_bf',
        'gender',
        'dob',
        'address',
        'active',
        'branch_id',
        'input_by',
        'location_id',
        'group_id'
    ];

    protected $casts = [
        'active' => 'bool'
    ];

    /**
     * 
     * get company associated with loyalty customers
     * 
     */
    public function company()
    {
        return $this->belongsTo(Company::class);
    }

    public function branch()
    {
        return $this->belongsTo(Branch::class);
    }

    /**
     * class to notify users through sms
     * 
     */
    public function routeNotificationForTextSms()
    {
        return $this->phone;
    }
}
