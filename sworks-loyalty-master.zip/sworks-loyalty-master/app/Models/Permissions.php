<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Permissions extends Model
{
    use HasFactory;

    /**
     * The database connection that should be used by the model.
     *
     * @var string
     */
    protected $connection = 'smart_core';

    /**
     * 
     * fillables
     */
    protected $fillable = [
        'id',
        'permission',
        'description',
        'active'
    ];
}
