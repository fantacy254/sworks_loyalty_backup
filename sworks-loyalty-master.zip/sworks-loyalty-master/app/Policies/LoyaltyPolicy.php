<?php

namespace App\Policies;

use App\Models\Loyalty;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Auth\Access\Response;

class LoyaltyPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        $permission = $user->permissions->contains('permission_id', 'can_view_loyalty_customers') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_view_loyalty_customers') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function create(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_create_loy_customer') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user)
    {
        $permission = $user->permissions->contains('permission_id', 'can_edit_loy_customer') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function award(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_award_points') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function cancelAward(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_cancel_points') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function adjust(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_adjust_points') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_delete_loy_customer') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to delete customers');
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function restore(User $user, Loyalty $loyalty)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function forceDelete(User $user, Loyalty $loyalty)
    {
        //
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewBalance(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_view_balance_enquiry') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to view this section');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function canRedeemPoints(User $user, Loyalty $loyalty)
    {
        $permission = $user->permissions->contains('permission_id', 'can_redeem_points') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }
    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function loadTrans(User $user)
    {
        $permission = $user->permissions->contains('permission_id', 'can_load_transactions') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewStatement(User $user)
    {
        $permission = $user->permissions->contains('permission_id', 'can_view_statement') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to view customer statement');
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function canGetStatement(User $user)
    {
        $permission = $user->permissions->contains('permission_id', 'can_get_statement') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this task');
    }

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function canPrintVoucher(User $user)
    {
        $permission = $user->permissions->contains('permission_id', 'can_print_voucher') || $user->permissions->contains('permission_id', 'is_superuser') || $user->isAdmin();
        return $permission ? Response::allow() : Response::deny('You are not authorized to print loyalty vouchers');
    }
}
