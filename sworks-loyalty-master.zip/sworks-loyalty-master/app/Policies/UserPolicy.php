<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Auth\Access\Response;

class UserPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\User  $model
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function view(User $user, User $model)
    {
        $permission = $user->permissions->contains('permission_id', 'is_admin') || $user->isAdmin() || $user->permissions->contains('permission_id', 'is_superuser') || $user->isMultiCompanyAccess(); //&& $user->tier === 1;
        return $permission ? Response::allow() : Response::deny('You are not authorized to view this section');
    }

    /**
     * Determine whether the user can create models.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function edit(User $user)
    {
        $permission = $user->permissions->contains('permission_id', 'can_edit_user') || $user->isAdmin() || $user->permissions->contains('permission_id', 'is_superuser') || $user->isMultiCompanyAccess();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this section');
    }

    /**
     * Determine whether the user can update the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\User  $model
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function update(User $user, User $model)
    {
        $permission = $user->permissions->contains('permission_id', 'can_edit_user') || $user->isAdmin() || $user->permissions->contains('permission_id', 'is_superuser') || $user->isMultiCompanyAccess();
        return $permission ? Response::allow() : Response::deny('You are not authorized to view this section');
    }

    /**
     * Determine whether the user can delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\User  $model
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function delete(User $user, User $model)
    {
        $permission = $user->permissions->contains('permission_id', 'can_delete_user') || $user->isAdmin()  || $user->permissions->contains('permission_id', 'is_superuser') || $user->isMultiCompanyAccess();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this action');
    }

    /**
     * Determine whether the user can restore the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\User  $model
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function restore(User $user, User $model)
    {
        $permission = $user->permissions->contains('permission_id', 'is_admin') || $user->isAdmin() || $user->permissions->contains('permission_id', 'is_superuser') || $user->isMultiCompanyAccess();
        return $permission ? Response::allow() : Response::deny('You are not authorized to perform this action');
    }

    /**
     * Determine whether the user can permanently delete the model.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\User  $model
     * @return \Illuminate\Auth\Access\Response|bool
     */
    public function forceDelete(User $user, User $model)
    {
        //
    }
}
