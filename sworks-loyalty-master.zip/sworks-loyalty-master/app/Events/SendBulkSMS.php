<?php

namespace App\Events;

use App\Models\Loyalty;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class SendBulkSMS
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $customer;
    public $sender;
    public $template;
    public $message;
    public $company;
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Loyalty $customer, $sender, $template, $message, int $company)
    {
        $this->customer = $customer;
        $this->sender = $sender;
        $this->template = $template;
        $this->message = $message;
        $this->company = $company;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
