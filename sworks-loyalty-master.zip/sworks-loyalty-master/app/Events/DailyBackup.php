<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class DailyBackup
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public string $backup;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(string $backupfile)
    {
        $this->backup = $backupfile;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
