<?php

namespace App\Events;

use App\Models\Branch;
use App\Models\Company;
use App\Models\Loyalty;
use App\Models\Voucher;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RedeemedPoints
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $company;
    public $customer;
    public $branch;
    public $voucher;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(Company $company, Loyalty $customer, Branch $branch, Voucher $voucher)
    {
        $this->company = $company;
        $this->customer = $customer;
        $this->branch = $branch;
        $this->voucher = $voucher;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
