<?php

namespace App\Events;

use App\Models\Branch;
use App\Models\Company;
use App\Models\Loyalty;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class EarnedPoints
{
    use Dispatchable, InteractsWithSockets, SerializesModels;


    public Company $company;
    public Loyalty $customer;
    public Branch $branch;
    public string $points;
    /**
     * Create a new event instance.
     *
     * @return mixed,void
     */
    public function __construct(Company $company, Loyalty $customer, Branch $branch, string $points)
    {
        $this->company = $company;
        $this->customer = $customer;
        $this->branch = $branch;
        $this->points = $points;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
