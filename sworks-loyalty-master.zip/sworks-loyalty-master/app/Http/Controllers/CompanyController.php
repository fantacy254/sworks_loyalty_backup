<?php

namespace App\Http\Controllers;

use App\Events\NewUser;
use App\Models\Branch;
use App\Models\Company;
use App\Models\User;
use App\Services\CompanyService;
use App\Services\DynamicService;
use Carbon\Carbon;
use Illuminate\Console\Scheduling\Event;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Inertia\Inertia;

class CompanyController extends Controller
{
    public function index()
    {
        $companies = Company::leftJoin('users', 'company.admin', '=', 'users.id')
            ->select('company.id', 'company.name', 'address', 'company.email', 'phone', 'pin_no', 'users.name as admin', 'db', 'company.created_at')
            ->get();

        foreach ($companies as $company) {
            DynamicService::setDatabaseConnection($company->db);
            $company->branches = Branch::on('dynamic')->count();
        }

        return Inertia::render('Master/CompanyCenter', [
            'companies' => $companies
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:' . Company::class,
            'phone' => 'required|string|max:20',
            'pin_no' => 'required|string|max:50',
        ]);

        try {

            CompanyService::addCompany(
                $request->name,
                $request->address,
                $request->email,
                $request->phone,
                $request->pin_no
            );

            return redirect()->back()->with('success', 'Company created successfully.');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage());
        }
    }

    public function adminStore(Request $request)
    {
        $request->validate([
            'adminState' => 'required|numeric'
        ]);

        //add company admin user
        if ($request->adminState === 0) {

            $request->validate([
                'company' => 'required|numeric',
                'user_id' => 'required|numeric|exists:' . User::class . ',id'
            ]);

            try {

                CompanyService::setAdminUser(
                    (int) $request->company,
                    (int) $request->user_id
                );

                return redirect()->back()->with('success', 'Company admin set successfully.');
            } catch (\Throwable $th) {
                return redirect()->back()->withError($th->getMessage());
            }

        } else {
            $request->validate([
                'company' => 'required|numeric',
                'branch' => 'required|numeric',
                'name' => 'required|string',
                'username' => 'required|string|unique:' . User::class,
                'email' => 'required|string|unique:' . User::class,
                'phone' => 'required|string',
                'access_level' => 'required|numeric'
            ]);

            try {

                //update company admin user
                CompanyService::addUser(
                $request->name,
                $request->username,
                $request->email,
                $request->phone,
                (int) $request->access_level,
                (int) $request->company,
                (int) $request->branch
            );

                $user = User::where('email', $request->email)->firstOrFail();

                CompanyService::setAdminUser(
                    (int) $request->company,
                    (int) $user->id
                );

                return redirect()->back()->with('success', 'Company admin created successfully.');
            } catch (\Throwable $th) {

                return redirect()->back()->withError($th->getMessage());
            }

        }

    }

    public function adminShow(Request $request)
    {
        $request->validate([
            'company' => 'required|numeric'
        ]);

        try {

            $users = User::where('company_id', (int) $request->company)
                ->where('access_level_id', 2)
                ->get();

            return $users;
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }

    public function smsUsage()
    {
        $cp = Company::select('id', 'name', 'sender_id')
            ->get();

        return Inertia::render('Master/SmsUsage', [
            'companies' => $cp
        ]);
    }

    public function smsTrans(Request $request)
    {
        $request->validate([
            'from' => 'required|date|string',
            'to' => 'required|date|string'
        ]);

        try {
            $fromDate = Carbon::parse($request->from)->startOfDay();
            $toDate = Carbon::parse($request->to)->endOfDay();

            $dt = DB::connection('smart_core')
                ->table('sms_trans')
                ->leftJoin('company', 'sms_trans.company_id', '=', 'company.id')
                ->whereBetween('sms_trans.created_at', [$fromDate, $toDate])
                ->select('sms_trans.phone as receiver', 'company.name as from', 'company_id', 'sender', 'sent', 'sms_trans.created_at as sent_at', 'message')
                ->orderBy('sms_trans.created_at', 'asc')
                ->get();

            return $dt->toArray();

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json($th->getMessage(), 505);
        }
    }
}
