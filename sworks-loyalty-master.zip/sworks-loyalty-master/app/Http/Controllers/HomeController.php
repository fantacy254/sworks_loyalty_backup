<?php

namespace App\Http\Controllers;

use App\Models\Agent;
use App\Models\Loan;
use App\Models\Mfloat;
use App\Models\Receipts;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Loyalty;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;


class HomeController extends Controller
{
    /**
     * 
     * homepage controller
     */
    public function index()
    {
        return Inertia::render('Home/Index');
    }
    /**
     * Summary of getDashboardData
     * @return mixed
     */
    public function show(Request $request)
    {
        $request->validate([
            'period' => 'required|string|date',
            'from' => 'required|string|date',
            'to' => 'required|string|date'
        ]);

        try {
            //get grouped sum points
            $result = DB::connection('dynamic')
            ->table('loy_trans')
            ->leftJoin('loy_type', 'loy_trans.type', '=', 'loy_type.type')
            ->selectRaw("
            COALESCE(SUM(CASE WHEN loy_type.sign = '+' THEN points END), 0) AS points_in, 
            COALESCE(SUM(CASE WHEN loy_type.sign = '-' THEN points END), 0) AS points_out
            ")
            ->first();
            
            $netPoints = $result->points_in - $result->points_out;


            $fromDate = Carbon::parse($request->input('from'))->startOfDay();
            $toDate = Carbon::parse($request->input('to'))->endOfDay();
            $period = Carbon::parse($request->input('period'))->toDateString();

            $loy = DB::connection('dynamic')
                ->table('loy_trans')
                ->leftJoin('loy_type', 'loy_trans.type', '=', 'loy_type.type')
                ->leftJoin('loy_customer', 'loy_trans.accno', '=', 'loy_customer.accno')
                ->select(
                    'run_date',
                    'doc_no',
                    'loy_trans.type',
                    'short_desc',
                    'loy_type.sign',
                    'loy_trans.accno',
                    'loy_customer.name as customer',
                    'loy_trans.branch_id',
                    'amount',
                    'points',
                    'reference',
                    'loy_trans.created_at'
                )
                ->whereBetween('run_date', [$fromDate, $toDate])
                ->orWhere(DB::raw('period'), $period ? $period : DB::raw('last_day(now())'))
                ->orderByDesc('run_date')
                ->get();

            $loy->toArray();

            $data = [
                $loy,
                $netPoints,
            ];

            return $data;

        } catch (\Throwable $th) {
            return response()->json(['Error getting the data']);
        }
    }

    /**
     * 
     * get dashboard customer analysis
     * 
     */
    public function showCustomers(Request $request)
    {
        try {
            $customers = Loyalty::on('dynamic')
                ->leftJoin('branch', 'loy_customer.branch_id', '=', 'branch.id')
                ->select(
                    'accno',
                    'loy_customer.name',
                    'actual_bal as acc_bal',
                    'loy_customer.phone',
                    'loy_customer.email',
                    'code',
                    'pin_no',
                    'active',
                    'card_no',
                    'branch.name as branch',
                    'branch_id',
                    'gender',
                    'loy_customer.input_by',
                    'loy_customer.created_at'
                )
                ->orderByDesc('loy_customer.created_at')
                ->get();

            $customers->toArray();


            return $customers;

        } catch (\Throwable $th) {
            //Log::error($th->getMessage());
            return Response('Error getting customer analysis', 505);
        }
    }
}
