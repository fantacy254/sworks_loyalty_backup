<?php

namespace App\Http\Controllers;

use App\Models\region;
use Illuminate\Http\Request;

class RegionController extends Controller
{
    public function index()
    {
        try {
            $region = region::select('id', 'name')->get();
            return $region;
        } catch (\Throwable $th) {
            return response([
                'code' => 05,
                'msg' => $th->getMessage()
            ]);
        }
    }
}
