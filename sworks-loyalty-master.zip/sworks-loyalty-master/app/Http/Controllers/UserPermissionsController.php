<?php

namespace App\Http\Controllers;

use App\Models\Permissions;
use App\Models\User;
use App\Models\UserPermissions;
use App\Http\Requests\StoreUserPermissionsRequest;
use App\Http\Requests\UpdateUserPermissionsRequest;
use App\Providers\RouteServiceProvider;
use Inertia\Inertia;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class UserPermissionsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return mixed
     */
    public function index(User $user)
    {
        $response = Gate::inspect('view', $user);

        if ($response->allowed()) {
            try {
                $results = Permissions::select('category', DB::raw('GROUP_CONCAT(permission ORDER BY permission SEPARATOR ", ") as permissions'), 'permission_id', 'description', 'level')
                    ->where('active', true)
                    ->groupBy('category', 'permission_id', 'description', 'level')
                    ->get()
                    ->groupBy('category');

                $finalResult = $results->map(function ($group, $category) {
                    return [
                        'category' => $category,
                        'details' => $group->map(function ($item) {
                            return [
                                'id' => $item->permission_id,
                                'permission' => $item->permissions,
                                'description' => $item->description,
                                'level' => $item->level,
                            ];
                        })->toArray(),
                    ];
                });

                $finalResult->toArray();

                return Inertia::render('Auth/Permissions', [
                    'permissions' => $finalResult
                ]);
            } catch (\Throwable $th) {
                //throw $th;
                Log::error($th->getMessage());
                return redirect()->intended(RouteServiceProvider::HOME)->withError('There was an error retriving permissions');
            }
        } else {
            return Redirect::route('home')->withInfo($response->message());
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreUserPermissionsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreUserPermissionsRequest $request, UserPermissions $userPermissions)
    {
        $response = Gate::inspect('update', Auth::user());

        if ($response->allowed()) {
            try {
                UserPermissions::where('user_id', $request->userId)->delete();

                foreach ($request->selectedUserPermissions as $permissions) {
                    UserPermissions::insert([
                        'permission_id' => $permissions,
                        'user_id' => $request->userId,
                        'input_by' => Auth::user()->username
                    ]);
                }

                return redirect()->route('users')->withSuccess('User permissions added successfully');

            } catch (\Throwable $th) {
                //throw $th;
                Log::error($th->getMessage());
                return redirect()->route('home')->withError('An error has occured while updating user permissions');
            }
        } else {
            return Redirect::route('home')->withInfo($response->message());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        try {
            $request->validate([
                'id' => 'required|integer'
            ]);

            $permissions = UserPermissions::select('permission_id', 'user_id')
                ->where('user_id', $request->input('id'))
                ->get();

            return response()->json($permissions);
        } catch (\Throwable $th) {
            //throw $th;
            Log::error($th->getMessage());
            return response('There was an error getting user permissions', 505);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\UserPermissions  $userPermissions
     * @return \Illuminate\Http\Response
     */
    public function edit(UserPermissions $userPermissions)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateUserPermissionsRequest  $request
     * @param  \App\Models\UserPermissions  $userPermissions
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateUserPermissionsRequest $request, UserPermissions $userPermissions)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\UserPermissions  $userPermissions
     * @return \Illuminate\Http\Response
     */
    public function destroy(UserPermissions $userPermissions)
    {
        //
    }
}
