<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Company;
use App\Services\ApiService;
use App\Services\DynamicService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class OauthController extends Controller
{
    public function index()
    {
        $companies = Company::select('id', 'name', 'token', 'db')->get();

        foreach ($companies as $company) {
            DynamicService::setDatabaseConnection($company->db);
            $company->branches = Branch::on('dynamic')->select('id', 'name', 'client_key')->get();
        }

        return Inertia::render('Oauth/Index', [
            'companies' => $companies
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'company_id' => 'required|exists:' . Company::class . ',id'
        ]);

        try {

            $token = ApiService::generateAccessToken();

            Company::where('id', $request->company_id)->update(['token' => $token]);

            return redirect()->back()->withSuccess('Access token generated successfully.');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage());
        }
    }

    public function genBranchToken(Request $request)
    {
        $request->validate([
            'company_id' => 'required|numeric',
            'branch_id' => 'required|numeric'
        ]);

        try {

            ApiService::generateClientKey($request->company_id, $request->branch_id);

            return redirect()->back()->withSuccess('Branch API token generated successfully.');
            
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage());
        }
    }
}
