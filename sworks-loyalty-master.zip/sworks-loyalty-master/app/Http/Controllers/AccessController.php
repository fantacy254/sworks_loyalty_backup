<?php

namespace App\Http\Controllers;

use App\Models\AccessLevel;
use Illuminate\Http\Request;

class AccessController extends Controller
{
    /**
     * Summary of show
     * @return mixed|\Illuminate\Database\Eloquent\Collection<int, AccessLevel>|\Illuminate\Http\JsonResponse
     */
    public function show()
    {
        try {
            $access = AccessLevel::all();
            $access->toArray();

            return $access;
        } catch (\Throwable $th) {
            return response()->json([
                'message' => 'Error',
                'error' => $th->getMessage()
            ], 500);
        }
    }
}
