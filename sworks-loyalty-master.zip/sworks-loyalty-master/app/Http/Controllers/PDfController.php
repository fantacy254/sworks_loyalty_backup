<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Barryvdh\DomPDF\Facade\PDF;
use Illuminate\Support\Facades\Log;
use Illuminate\Http\Request;

class PDfController extends Controller
{
    public function exportPDF(Request $request)
    {
        try {
            $request->validate([
                'data' => 'required|array',
                'title' => 'required|string'
            ]);

            $headers = Company::where('id', session('company_id'))->get();
            Log::info($headers);

            $data = [
                'title' => $request->input('title'),
                'tableRows' => $request->input('data'),
                'headers' => $headers
            ];

            // Load a view and pass the data to it
            $pdf = PDF::loadView('Export.PdfExport', $data)->setPaper('a4', 'landscape');


            // Download the generated PDF
            return $pdf->download($request->input('title') . '.pdf');

        } catch (\Throwable $th) {
            Log::error($th->getMessage());
            return response($th->getMessage());
        }
    }
}
