<?php

namespace App\Http\Controllers;

use App\Exports\LoyaltyCustomerTemplateExport;
use App\Imports\LoyaltyCustomerImport;
use App\Models\Branch;
use App\Models\Company;
use App\Models\Group;
use App\Models\Location;
use App\Models\Loyalty;
use App\Models\LoyMaster;
use App\Models\LoyType;
use App\Models\Master;
use App\Exports\LoyatyExport;
use App\Exports\ListingExport;
use App\Exports\TransExport;
use App\Models\Voucher;
use App\Notifications\SmsNotification;
use App\Services\DynamicService;
use App\Services\LoyaltyService;
use Cache;
use Exception;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Contracts\Support\Responsable;
use Illuminate\Http\Request;
use App\Http\Requests\CustomerRequest;
use App\Http\Requests\ReportRequest;
use App\Http\Requests\CustomerUpdateRequest;
use App\Http\Requests\AwardPointsRequest;
use Inertia\Inertia;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Routing\Redirector;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Response;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

use Illuminate\Validation\ValidationException;


class LoyaltyController extends Controller
{
    public function __construct()
    {
        $this->middleware('dynamic.connection');
    }

    public function masterIndex()
    {
        $locs = Location::on('dynamic')->get();
        $gps = Group::on('dynamic')->get();

        return Inertia::render('Loyalty/Masters', [
            'locations' => $locs,
            'groups' => $gps
        ]);
    }

    public function storeLocation(Request $request)
    {
        $request->validate([
            'name' => 'required|string'
        ]);

        try {
            Location::on('dynamic')
                ->create([
                    'name' => $request->name,
                    'input_by' => Auth::user()->username
                ]);

            return redirect()->back()->withSuccess('Location master saved successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError('Error has occured saving location masters');
        }
    }

    /**
     * Summary of updateLocation
     * @param Request $request
     */
    public function updateLocation(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string'
        ]);

        try {
            $location = Location::on('dynamic')->findOrFail($id);
            $location->name = $request->name;
            $location->input_by = Auth::user()->username;
            $location->save();

            return redirect()->back()->withSuccess('Location master updated successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError('Error has occured updating location masters');
        }
    }

    public function destroyLocation($id)
    {
        try {
            $location = Location::on('dynamic')->findOrFail($id);
            $location->delete();

            return redirect()->back()->withSuccess('Location master deleted successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError('Error has occured deleted location masters');
        }
    }

    public function storeGroup(Request $request)
    {
        $request->validate([
            'name' => 'required|string'
        ]);

        try {
            Group::on('dynamic')
                ->create([
                    'name' => $request->name,
                    'input_by' => Auth::user()->username
                ]);

            return redirect()->back()->withSuccess('Group master saved successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage()); //('Error has occured saving group masters');
        }
    }

    /**
     * Summary of updategroup
     * @param Request $request
     */
    public function updateGroup(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string'
        ]);

        try {
            $group = Group::on('dynamic')->findOrFail($id);
            $group->name = $request->name;
            $group->input_by = Auth::user()->username;
            $group->save();

            return redirect()->back()->withSuccess('group master updated successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage()); //('Error has occured updating group masters');
        }
    }

    public function destroyGroup($id)
    {
        try {
            $group = Group::on('dynamic')->findOrFail($id);
            $group->delete();

            return redirect()->back()->withSuccess('group master deleted successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage()); //('Error has occured deleting group masters');
        }
    }

    public function assignMaster(Request $request)
    {
        $request->validate([
            'currentTemp' => 'required|string',
            'master' => 'required|numeric',
            'custs' => 'required|array',
        ]);

        try {
            //set dynamic connection
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $cp = Company::findOrFail($cp_id);
            DynamicService::setDatabaseConnection($cp->db);
            
            //update customer group
            if ($request->currentTemp === 'group') {
                foreach ($request->custs as $cust) {
                    Loyalty::on('dynamic')
                        ->where('accno', $cust['accno'])
                        ->where('code', $cust['id_no'])
                        ->update([
                            'group_id' => $request->master
                        ]);
                }
            } else if ($request->currentTemp === 'location') {
                foreach ($request->custs as $cust) {
                    Loyalty::on('dynamic')
                        ->where('accno', $cust['accno'])
                        ->where('code', $cust['id_no'])
                        ->update([
                            'location_id' => $request->master
                        ]);
                }
            } else {
                throw new Exception('Missing or invalid masters');
            }

            return redirect()->back()->withSuccess('Customer ' . $request->currentTemp . ' updated successfully');
        } catch (\Throwable $th) {
            Log::error($th->getMessage());
            return redirect()->back()->withError($th->getMessage());
        }

    }

    public function showMasters()
    {
        try {
            $gp = Group::all();
            $loc = Location::all();

            $data = [$gp, $loc];

            return response($data);

        } catch (\Throwable $th) {
            return response($th->getMessage());
        }
    }

    public function custCount(Request $request)
    {
        $request->validate([
            'selection' => 'required|string',
            'master' => 'required_unless:selection,all|numeric',
            'gender' => 'required_if:selection,gender|string'
        ]);

        try {
            // Validate early and throw immediately
            $validSelections = ['all', 'group', 'location', 'gender'];

            if (!in_array($request->selection, $validSelections)) {
                throw new \InvalidArgumentException("Invalid selection: {$request->selection}");
            }

            $query = Loyalty::on('dynamic');

            if ($request->selection !== 'all' && $request->selection !== 'gender') {
                $query->where($request->selection . '_id', $request->master)->count();
            }

            if ($request->selection === 'gender') {
                $query->where('gender', Str::upper($request->gender))->count();
            }

            return $query->count();
        } catch (\Throwable $th) {
            return response($th->getMessage(), 500);
        }
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Inertia\Response
     * @return mixed
     */
    public function index(Loyalty $loyalty, Request $request)
    {
        $response = Gate::inspect('view', $loyalty);

        if ($response->allowed()) {
            try {
                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $branch = Branch::on('dynamic')->get();

                $customers = Loyalty::on('dynamic')
                    ->select('accno', 'loy_customer.name', 'actual_bal as acc_bal', 'branch_id', 'branch.name as branch', 'groups.name as group', 'locations.name as location', 'loy_customer.code', 'gender', 'pin_no', 'loy_customer.email', 'loy_customer.phone', 'card_no', 'active as status', 'loy_customer.input_by', 'loy_customer.created_at')
                    ->leftJoin('branch', 'loy_customer.branch_id', '=', 'branch.id')
                    ->leftJoin('groups', 'loy_customer.group_id', '=', 'groups.id')
                    ->leftJoin('locations', 'loy_customer.location_id', '=', 'locations.id')
                    ->orderBy('name', 'asc')
                    ->get();

                $customers->toArray();

                $lcs = Location::on('dynamic')->select('id', 'name')->get();
                $gps = Group::on('dynamic')->select('id', 'name')->get();

                return Inertia::render('Loyalty/Index', [
                    'customers' => $customers,
                    'branch' => $branch,
                    'locations' => $lcs,
                    'groups' => $gps,
                ]);
            } catch (\Throwable $th) {
                return Redirect::back()->withError('Error occured while retriving Customer records');
            }
        } else {
            return Redirect::route('home')->with('info', $response->message());
        }
    }

    /**
     * get customer whose id like request id
     * 
     * @return mixed
     * 
     */
    public function searchCust(Request $request)
    {
        $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
        $cp = Company::findOrFail($cp_id);
        DynamicService::setDatabaseConnection($cp->db);

        $customer = Loyalty::on('dynamic')
            ->where('active', true)
            ->orderBy('name', 'asc')
            ->select('accno', 'code', 'name', 'actual_bal')
            ->get();

        return $customer->toArray();
    }

    /**
     * Display customer listing
     * 
     * @return \Inertia\Response
     * @param \App\Models\Loyalty $loyalty
     * @return mixed
     * 
     */
    public function customerList(Loyalty $loyalty)
    {
        $response = Gate::inspect('view', $loyalty);

        if ($response->allowed()) {
            try {
                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $data = Loyalty::on('dynamic')
                    ->where('active', true)
                    ->select('accno', 'loy_customer.name', 'actual_bal', 'loy_customer.branch_id', 'branch.name as branch', 'loy_customer.code', 'loy_customer.phone', 'card_no')
                    ->leftJoin('branch', 'loy_customer.branch_id', '=', 'branch.id')
                    ->orderBy('loy_customer.name', 'asc')
                    ->get()
                    ->map(fn($cust) => $this->attachCustLastTrans($cust))
                    ->map(function ($cust) {
                        return (object) [
                            'accno' => $cust->accno,
                            'name' => $cust->name,
                            'acc_bal' => $cust->actual_bal,
                            'last_trans' => $cust->last_trans,
                            'trans_date' => $cust->trans_date,
                            'last_type' => $cust->last_type,
                            'branch_id' => $cust->branch_id,
                            'branch' => $cust->branch,
                            'id_no' => $cust->code,
                            'phone' => $cust->phone,
                            'card_no' => $cust->card_no,
                        ];
                    })
                    ->toArray();

                return Inertia::render('Loyalty/Listing', [
                    'data' => $data
                ]);
            } catch (\Throwable $th) {
                Log::error($th->getMessage());
                return Redirect::route('home')->with('error', 'An error occured while retriving lolalty customers');
            }
        } else {
            return Redirect::route('home')->with('info', $response->message());
        }
    }

    private function attachCustLastTrans($cust)
    {
        $trns = DB::connection('dynamic')
            ->table('loy_trans')
            ->where('accno', $cust->accno)
            ->select('doc_no', 'type', 'run_date')
            ->orderByDesc('run_date')
            ->first();

        if ($trns) {
            $cust->last_trans = $trns->doc_no ?? null;
            $cust->trans_date = $trns->run_date ?? null;
            $cust->last_type = $trns->type ?? null;
        }

        return $cust;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Inertia\Response
     * @return mixed
     */
    public function create(Loyalty $loyalty)
    {
        $response = Gate::inspect('create', $loyalty);

        if ($response->allowed()) {

            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $cp = Company::findOrFail($cp_id);
            DynamicService::setDatabaseConnection($cp->db);

            $branch = Branch::on('dynamic')
                ->select('id', 'name')
                ->get();
            $branch->toArray();

            return Inertia::render('Loyalty/Create', [
                'branch' => $branch
            ]);
        } else {
            return back()->with('info', $response->message());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Loyalty $loyalty, CustomerRequest $request): RedirectResponse
    {
        $response = Gate::inspect('create', $loyalty);
        
        if ($response->allowed()) {
            try {
                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                LoyaltyService::registerLoyaltyCustomer(
                    $request->validated('code'),
                    $request->validated('name'),
                    $request->validated('email'),
                    $request->validated('phone'),
                    $request->validated('pin_no'),
                    $request->validated('card_no'),
                    $request->validated('address'),
                    $request->validated('status') === true ? false : true,
                    $request->validated('gender'),
                    $request->validated('dob'),
                    $cp_id,
                    $request->validated('branchId'),
                    Auth::user()->username
                );

                return redirect()->route('loyalty.index')->with('success', 'Loyalty customer created successfully');

            } catch (\Throwable $th) {
                Log::debug($th->getMessage());
                return back()->withError('Error occured while saving the customer. Kindly check your inputs');
            }
        } else {
            return redirect()->route('loyalty.index')->with('info', $response->message());
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Http\Response
     * @return \Illuminate\Http\RedirectResponse
     */
    public function show(Request $request): Response
    {
        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $cp = Company::findOrFail($cp_id);
            DynamicService::setDatabaseConnection($cp->db);

            $loyCust = Loyalty::on('dynamic')
                ->where('code', $request->input('id'))
                ->orWhere('accno', $request->input('id'))
                ->first();

            Log::info($loyCust);

            if (!$loyCust) {
                return response('The Customer details does not exists', 500);
            }

            if (!$loyCust->active) {
                return response('The Customer ID is blocked', 500);
            }

            return response($loyCust);

        } catch (\Throwable $th) {
            Log::error($th->getMessage());
            return response($th->getMessage(), 505);
        }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Http\Response
     * @return \Inertia\Response
     * @return mixed
     */
    public function edit($id)
    {
        $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
        $cp = Company::findOrFail($cp_id);
        DynamicService::setDatabaseConnection($cp->db);

        $loyalty = Loyalty::on('dynamic')->find($id);
        $response = Gate::inspect('update', $loyalty);

        if ($response->allowed()) {

            $branch = Branch::on('dynamic')->select('id', 'name')->get();
            $branch->toArray();

            //$customer = Loyalty::find($id);

            return Inertia::render('Loyalty/Edit', [
                'branch' => $branch,
                'cust' => [
                    'code' => $loyalty->code,
                    'accno' => $loyalty->accno,
                    'name' => $loyalty->name,
                    'email' => $loyalty->email,
                    'phone' => $loyalty->phone,
                    'card_no' => $loyalty->card_no,
                    'gender' => $loyalty->gender,
                    'dob' => $loyalty->dob,
                    'address' => $loyalty->address,
                    'status' => $loyalty->active,
                    'branch' => $loyalty->branch_id,
                    'pin_no' => $loyalty->pin_no
                ]
            ]);
        } else {
            return back()->with('info', $response->message());
        }


    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     * @return mixed
     */
    public function update(CustomerUpdateRequest $request, $id): RedirectResponse
    {

        $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
        $cp = Company::findOrFail($cp_id);
        DynamicService::setDatabaseConnection($cp->db);

        $loyalty = Loyalty::on('dynamic')->where('code',$id)->first();
        $response = Gate::inspect('update', $loyalty);

        if ($response->allowed()) {
            try {
                LoyaltyService::updateLoyaltyCustomer(
                    $id,
                    $request->validated('name'),
                    $request->validated('email'),
                    $request->validated('phone'),
                    $request->validated('pin_no'),
                    $request->validated('card_no'),
                    $request->validated('address'),
                    $request->validated('status') === true ? false : true,
                    $request->validated('gender'),
                    $request->validated('dob'),
                    $cp_id,
                    $request->validated('branchId'),
                    Auth::user()->username
                );

                return redirect()->route('loyalty.index')->with('success', 'Customer details updated successfully');
            } catch (\Throwable $th) {
                Log::error($th->getMessage());
                return redirect()->back()->withError($th->getMessage());
                //return back()->withError('error', $th->getCode() . ' Error while updating customer records');
            }
        } else {
            return redirect()->route('loyalty.index')->with('info', $response->message());
        }

    }
    /**
     * award loyalty points to the customer
     * 
     * @return \Inertia\Response
     * @return mixed
     * 
     */
    public function awardCreate(Loyalty $loyalty)
    {
        $response = Gate::inspect('award', $loyalty);

        if ($response->allowed()) {
$type = 'AWD';
            $mustAuth = LoyType::on('dynamic')
            ->where('type', $type)
            ->select('auth')
            ->value('auth');

            return Inertia::render('Loyalty/Award',[
                'trans_type'=>$type,
                'has_auth'=>$mustAuth
            ]);

        } else {
            return redirect()->intended(RouteServiceProvider::HOME)->with('info', $response->message());
        }

    }
    /**
     * award loyalty points to the customer
     * 
     * @return \Inertia\Response
     * @return mixed
     * 
     */
    public function awardCancel(Loyalty $loyalty)
    {
        $response = Gate::inspect('cancelAward', $loyalty);

        if ($response->allowed()) {
            $type = 'CAN';
            $mustAuth = LoyType::on('dynamic')
            ->where('type', $type)
            ->select('auth')
            ->value('auth');

            return Inertia::render('Loyalty/Cancel',[
                'trans_type'=>$type,
                'has_auth'=>$mustAuth
            ]);

        } else {
            return redirect()->intended(RouteServiceProvider::HOME)->with('info', $response->message());
        }
    }
    /**
     * save customer points
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Http\Response
     */
    public function storePoints($id, Loyalty $loyalty, AwardPointsRequest $request): RedirectResponse
    {
        $response = Gate::inspect('award', $loyalty);

        if ($response->allowed()) {
            try {

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $loy = Loyalty::on('dynamic')->find($id);
                $doc_no = LoyaltyService::generateTransDocNo($cp_id, $request->validated('brcode'), 'AWD');

                LoyaltyService::postEarnPoints(
                    $cp_id,
                    $request->validated('brcode'),
                    $doc_no,
                    $request->validated('trans_type'),
                    $loy->accno,
                    now()->toDateString(),
                    $request->validated('refNo'),
                    $request->validated('points'),
                    $request->validated('points'),
                    99,
                    Auth::user()->username,
                    $request->validated('notes')
                );

                //clear chached code                
                $cache_key = '_trans_auth_'.$request->validated('trans_type');
                Cache::forget($cache_key);

                return redirect()->intended(RouteServiceProvider::HOME)->with('success', 'Loyalty Points awarded successfully');

            } catch (\Throwable $th) {
                Log::error($th->getMessage());
                return back()->withError($th->getMessage());
            }
        } else {
            return redirect()->back()->with('info', $response->message());
        }
    }

    /**
     * save customer points
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Http\Response
     */
    public function cancelPoints(Loyalty $loyalty, $id, AwardPointsRequest $request): RedirectResponse
    {
        $response = Gate::inspect('cancelAward', $loyalty);

        if ($response->allowed()) {
            try {

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $doc_no = LoyaltyService::generateTransDocNo($cp_id, $request->validated('brcode'), 'CAN');

                LoyaltyService::postLoyTrans(
                    $cp_id,
                    $request->validated('brcode'),
                    $doc_no,
                    $request->validated('trans_type'),
                    $id,
                    now()->toDateString(),
                    $request->validated('refNo'),
                    $request->validated('points'),
                    Auth::user()->username,
                    $request->validated('points'),
                    99,
                    Auth::user()->username,
                    $request->validated('notes')
                );

                
                //clear chached code                
                $cache_key = '_trans_auth_'.$request->validated('trans_type');
                Cache::forget($cache_key);


                return redirect()->intended(RouteServiceProvider::HOME)->withSuccess('Loyalty Points cancelled successfully');

            } catch (\Throwable $th) {
                Log::error($th->getMessage());
                return back()->withError('An has occured while saving records! Kindly check your inputs.');
            }
        } else {
            return redirect()->back()->with('info', $response->message());
        }
    }

    /**
     * loyalty smartpoint adjustment
     * @param \App\Models\Loyalty $loyalty
     * @return mixed
     */
    public function pointsAdj(Loyalty $loyalty)
    {
        $response = Gate::inspect('adjust', $loyalty);

        if ($response->allowed()) {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $cp = Company::findOrFail($cp_id);
            DynamicService::setDatabaseConnection($cp->db);

            $branch = Branch::on('dynamic')->select('id', 'name')->get();
            $branch->toArray();


            $master_types = DB::connection('dynamic')
                ->table('loy_type')
                ->where('sub_type', 'ADJ')
                ->get();

            $master_types->toArray();

            return Inertia::render('Loyalty/AdjPoints', [
                'types' => $master_types
            ]);
        } else {
            return Redirect::back()->with('info', $response->message());
        }
    }

    /**
     * save customer points
     * 
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Http\Response
     */
    public function adjustPoints(Loyalty $loyalty, $id, AwardPointsRequest $request): RedirectResponse
    {
        $response = Gate::inspect('adjust', $loyalty);

        if ($response->allowed()) {
            try {

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $doc_no = LoyaltyService::generateTransDocNo($cp_id, $request->validated('brcode'), $request->validated('trans_type'));

                LoyaltyService::postPointsAdjustment(
                    $cp_id,
                    $request->validated('brcode'),
                    $doc_no,
                    $request->validated('trans_type'),
                    $id,
                    $request->validated('refNo'),
                    $request->validated('points'),
                    99,
                    Auth::user()->username,
                    $request->validated('notes')
                );

                //clear chached code                
                $cache_key = '_trans_auth_'.$request->validated('trans_type');
                Cache::forget($cache_key);

                return redirect()->intended(RouteServiceProvider::HOME)->withSuccess('Loyalty Points adjusted successfully');
            } catch (\Throwable $th) {
                Log::error($th->getMessage());
                return back()->withError('An error occured while saving records');
            }
        } else {
            return redirect()->back()->with('info', $response->message());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Loyalty  $loyalty
     * @return \Illuminate\Http\Response
     * @return mixed
     */
    public function destroy($index)
    {
        $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
        $cp = Company::findOrFail($cp_id);
        DynamicService::setDatabaseConnection($cp->db);

        $loyalty = Loyalty::on('dynamic')->findOrFail($index);

        $response = Gate::inspect('delete', $loyalty);
        if ($response->allowed()) {
            try {
                
                $loyalty->delete();

                return Redirect::route('loyalty.index')->with('success', 'Loyalty Customer deleted successfully');
            } catch (\Throwable $th) {
                return Redirect::back()->with('error', $th->getMessage());
            }
        } else {
            return Redirect::back()->with('info', $response->message());
        }
    }
    /**
     * Restore deleted loyalty customer
     * 
     * @param \App\Models\Loyalty $loyalty
     * @return 
     * 
     */
    public function restore()
    {
        //
    }
    /**
     * 
     * Export loyalty customers
     * 
     */
    public function LoyaltyExport()
    {
        try {
            return Excel::download(new LoyatyExport, 'loyaltyloy_Customer.xlsx');
        } catch (\Throwable $th) {
            return Redirect::back()->with('error', $th->getMessage());
        }

    }
    /**
     * 
     * Export loyalty customers
     * 
     */
    public function LoyaltyPrint()
    {
        try {
            return Excel::download(new LoyatyExport, 'loyaltyloy_Customer.pdf', \Maatwebsite\Excel\Excel::MPDF);
        } catch (\Throwable $th) {
            return Redirect::back()->with('error', $th->getMessage());
        }

    }
    /**
     * 
     * Export loyalty customers
     * 
     */
    public function ListingExport()
    {
        try {
            return Excel::download(new ListingExport, 'CustomersListing.xlsx');
        } catch (\Throwable $th) {
            return Redirect::back()->with('error', $th->getMessage());
        }

    }
    /**
     * 
     * Export loyalty customers
     * 
     */
    public function ListingPrint()
    {
        try {
            return Excel::download(new ListingExport, 'CustomersListing.pdf', \Maatwebsite\Excel\Excel::MPDF);
        } catch (\Throwable $th) {
            return Redirect::back()->with('error', $th->getMessage());
        }

    }
    /**
     * 
     * use App/Model/Loyalty $loyalty
     * 
     */
    public function loyaltyStatement(Loyalty $loyalty)
    {
        $response = Gate::inspect('viewStatement', $loyalty);

        if ($response->allowed()) {
            return Inertia::render('Loyalty/Statement');

        } else {

            return back()->with('info', $response->message());

        }
    }

    /**
     * get loyalty customer statement
     * 
     * @return mixed
     */
    public function loyaltyReport(Loyalty $loyalty, Request $request)
    {
        $response = Gate::inspect('canGetStatement', $loyalty);

        if ($response->allowed()) {
            try {
                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $fromDate = Carbon::parse($request->from)->startOfDay();
                $toDate = Carbon::parse($request->to)->endOfDay();

                $query = DB::connection('dynamic')
                    ->table('loy_trans')
                    ->select('run_date', 'loy_trans.type','loy_type.sign','loy_type.long_desc', 'doc_no', 'amount', 'reference', 'loy_trans.input_by', 'loy_trans.created_at', DB::raw('CASE WHEN loy_type.sign = "+" THEN points ELSE 0 END AS points_in'), DB::raw('CASE WHEN loy_type.sign = "-" THEN points ELSE 0 END AS points_out'))                 
                    ->leftJoin('loy_type', 'loy_trans.type', '=', 'loy_type.type')
                    ->leftJoin('loy_customer', 'loy_trans.accno', '=', 'loy_customer.accno')
                    ->where('loy_customer.code', $request->input('id'));                  

                    if(!$request->viewAll){
                        $query->whereBetween('run_date', [$fromDate, $toDate]);
                    }

                    $rslt = $query->orderBy('created_at', 'asc')->get();

                return Response($rslt);
            } catch (\Throwable $th) {
                return Response($th->getMessage());
            }
        } else {

            return response($response->message(), 406);

        }
    }

    /**
     * 
     * check customer balance
     * @param App/Models/Loyalty $loyalty
     * 
     */
    public function balanceEnquiry(Loyalty $loyalty)
    {
        $response = Gate::inspect('viewBalance', $loyalty);

        if ($response->allowed()) {

            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $cp = Company::findOrFail($cp_id);
            DynamicService::setDatabaseConnection($cp->db);

            $branch = Branch::on('dynamic')->get();
            $branch->toArray();

            return Inertia::render('Loyalty/Balance', [
                'branches' => $branch
            ]);

        } else {

            return back()->with('info', $response->message());

        }
    }
    /**
     * get customer points balance
     * @param App/Model/Loyalty $loyalty
     * 
     */
    public function getBalanceEnquiry($id, Loyalty $loyalty)
    {
        $response = Gate::inspect('viewBalance', $loyalty);

        if ($response->allowed()) {

            try {

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $loyCust = Loyalty::on('dynamic')
                    ->where('code', $id)
                    ->select('active as status')
                    ->get();

                if ($loyCust->count() === 1 && $loyCust[0]->status === 1) {
                    $master = Master::on('dynamic')->where('id', 1)->get();

                    if ($master->isEmpty()) {
                        $message = 'Master records not found';
                        return $message;
                    }

                    if ($master[0]->active === 1) {
                        $loyalty = Loyalty::on('dynamic')->where('code', $id)->select('accno', 'name', 'actual_bal', 'updated_at')->get()->toArray();
                        $masters = Master::on('dynamic')->select('earn', 'redeem', 'min_redeem', 'expiry')->where('id', 1)->get()->toArray();

                        $resultQuery = array_merge($loyalty, $masters);

                        return response($resultQuery, 200);
                    } else {
                        $message = 'This operation is not allowed';
                        return $message;
                    }
                } else {
                    $message = 'Customer is blocked or does not exists';
                    return $message;
                }

            } catch (\Throwable $th) {
                
                return response('Something went wrong, kindly check your inputs', 504);
            }
        } else {

            return back()->with('info', $response->message());

        }
    }
    /**
     * get customer points balance
     * @param App/Model/Loyalty $loyalty
     * @return mixed
     * 
     * @return \Illuminate\Http\Response
     */
    public function redeemPoints(Loyalty $loyalty, Request $request)
    {
        $response = Gate::inspect('canRedeemPoints', $loyalty);

        if ($response->allowed()) {
            try {
                $request->validate([
                    'br_id' => 'required|numeric',
                    'id' => 'required|numeric',
                    'points' => 'required|numeric'
                ]);

                //if (Auth::user()->isMultiCompanyAccess()) {
                //   return response('You are not allowed to redeem loyalty points', 505);
                //}

                if ($request->input('br_id') === "00") {
                    return response('Customer cannot be of branch All. Kindly change the branch', 505);
                }

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $type = LoyType::on('dynamic')->where('type', 'RED')->get();

                if ($type->isEmpty()) {
                    return response('Type not found', 505);
                }

                $cust = Loyalty::on('dynamic')->where('code', $request->input('id'))->get();

                if ($cust->isEmpty()) {
                    return response('Customer not found', 505);
                }

                DB::beginTransaction();

                $voucherData = LoyaltyService::generateVoucherNumber($cp_id, $request->input('br_id'));
                $RedDoc = LoyaltyService::generateTransDocNo($cp_id, $request->input('br_id'), 'RED');

                LoyaltyService::postLoyTrans(
                    $cp_id,
                    $request->input('br_id'),
                    $RedDoc,
                    'RED',
                    $request->input('id'),
                    now()->toDateString(),
                    $voucherData['voucher'],
                    $request->input('points'),
                    Auth::user()->username,
                    $request->input('points'),
                    99,
                    Auth::user()->username
                );

                LoyaltyService::postVoucher(
                    $cp_id,
                    $request->input('br_id'),
                    $voucherData['voucher'],
                    $voucherData['payload'],
                    $RedDoc,
                    $request->input('id'),
                    $request->input('points'),
                    Auth::user()->username,
                    $voucherData['expiry']
                );

                DB::commit();

                $data = [
                    'voucher' => $voucherData['voucher'],
                    'points' => $request->input('points'),
                    'expiry' => $voucherData['expiry'],
                    'days' => $voucherData['days']
                ];

                return Response($data, 200);
            } catch (\Throwable $th) {
                DB::rollBack();
                return Response('An error has occured', 505);
            }
        } else {
            Log::error($response);
            return Response($response->message(), 406);
        }
    }

    /**
     * transaction listing create
     * @return mixed
     * 
     */
    public function transListing(Request $request ,Loyalty $loyalty)
    {
        $response = Gate::inspect('view', $loyalty);

        if ($response->allowed()) {
            try {

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $loy_type = LoyType::on('dynamic')->select('type', 'long_desc as name')->get();
                $loy_type->toArray();

                return Inertia::render('Loyalty/TransListing', [
                    'types' => $loy_type,
                    'type' => $request->typ
                ]);
            } catch (\Throwable $th) {
                
                return Redirect::intended(RouteServiceProvider::HOME)->withError('An error has occured');
            }
        } else {

            return back()->with('info', $response->message());

        }
    }
    /**
     * 
     * 
     */
    public function LoadTrans(Loyalty $loyalty, Request $request)
    {
        $response = Gate::inspect('loadTrans', $loyalty);

        if ($response->allowed()) {
            try {
                $request->validate([
                    'type' => 'required|string',
                    'from' => 'required|date',
                    'to' => 'required|date'
                ]);

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $query = DB::connection('dynamic')
                ->table('loy_trans')
                    ->select('run_date', 'doc_no', 'loy_trans.type', 'loy_trans.accno', 'loy_customer.name', 'reference', 'points', 'amount', 'loy_trans.branch_id', 'branch.name as branch', 'notes', 'loy_customer.input_by', 'loy_customer.created_at')
                    //->where('loy_trans.company_id', Auth::user()->company_id)
                    ->whereBetween('run_date', [$request->input('from'), $request->input('to')])
                    ->LeftJoin('loy_customer', 'loy_trans.accno', '=', 'loy_customer.accno')
                    ->LeftJoin('branch', 'loy_trans.branch_id', '=', 'branch.id')
                    ->leftJoin('loy_type', 'loy_trans.type', '=', 'loy_type.type')
                    ->orderByDesc('run_date')
                    ->orderBy('name', 'asc');

                if ($request->input('type') !== 'all') {
                    $query->where('loy_trans.type', $request->input('type'));
                }

                $data = $query->get();

                return response($data, 200);

            } catch (\Throwable $th) {
                
                return response('An error occured while getting the report', 505);
            }
        } else {

            return response($response->message(), 406);

        }
    }

    public function TransExport()
    {
        try {
            //return Excel::download(new TransExport('all'), 'TransactionListing.xlsx', \Maatwebsite\Excel\Excel::XLSX);
            //return back()->withSuccess('Export started');
        } catch (\Throwable $th) {
            return Redirect::back()->with('error', $th->getMessage());
        }

    }
    public function loyaltyVouchers()
    {
        $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
        $cp = Company::findOrFail($cp_id);
        DynamicService::setDatabaseConnection($cp->db);

        return Inertia::render('Loyalty/Vouchers');
    }

    public function getVouchers(Request $request)
    {
        try {
            $request->validate([
                'from' => 'required|date',
                'to' => 'required|date'
            ]);

            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $cp = Company::findOrFail($cp_id);
            DynamicService::setDatabaseConnection($cp->db);

            $query = DB::connection('dynamic')
            ->table('voucher')
                ->select('date', 'doc_no as voucher', 'br_code as branch_id', 'cust_name', 'amount', 'expiry', 'used', 'branch.name as branch_used', 'used_receipt', 'used_rdate', 'printed', 'used_till', 'voucher.input_by', 'input_date', )
                ->leftJoin('branch', 'voucher.used_branch', '=', 'branch.id')
                ->whereBetween('date', [$request->input('from'), $request->input('to')]);

            $data = $query->get();

            $data->toArray();

            return $data;

        } catch (\Throwable $th) {
            //throw $th;
            Log::error($th->getMessage());
            return response('An error has occured!', 505);
        }
    }

    public function printVoucher(Loyalty $loyalty, $doc)
    {
        $response = Gate::inspect('canPrintVoucher', $loyalty);

        if ($response->allowed()) {
            try {

                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
                $cp = Company::findOrFail($cp_id);
                DynamicService::setDatabaseConnection($cp->db);

                $details = Voucher::on('dynamic')
                    ->select('doc_no', 'date', 'cust_accno', 'cust_name', 'cust_code', 'amount', 'voucher.input_by', 'voucher.input_date', 'expiry', 'points', 'branch.name as branch', 'loy_customer.card_no as card')
                    ->where('doc_no', $doc)
                    //->where('used', false)
                    ->leftJoin('branch', 'voucher.br_code', '=', 'branch.id')
                    ->leftJoin('loy_customer', 'voucher.cust_code', '=', 'loy_customer.code')
                    ->get();
                $details->toArray();

                if (count($details) === 0) {
                    return response('Voucher details not found', 500);
                }

                return $details;
            } catch (\Throwable $th) {
                //throw $th;
                Log::error($th->getMessage());
                return response('An error has occured while retriving customer voucher!', 500);
            }
        } else {
            return response($response->message(), 406);

        }
    }

    public function downloadImportTemplate()
    {
        try {
            return Excel::download(new LoyaltyCustomerTemplateExport(), 'loyalty_customers.xlsx');
        } catch (\Throwable $th) {
            return Redirect::back()->with('error', $th->getMessage());
        }
    }

    public function importCustomers(Request $request)
    {
        $request->validate([
            'file' => ['required', 'file', 'mimes:xlsx,xls,csv'],
        ]);

        try {
            Excel::import(
                new LoyaltyCustomerImport,
                $request->file('file')
            );            

            return back()->with('success', 'Customers imported successfully');

        } catch (\Throwable $th) {
            return back()->with('error', $th->getMessage());
        }
    }
}
