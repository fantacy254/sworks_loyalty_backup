<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Services\TextSmsService;
use App\Support\SmsTemplateParser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class TransController extends Controller
{

protected $textSmsService;

public function __construct(TextSmsService $textSmsService)
{
    $this->textSmsService = $textSmsService;
}

    /**
     * generate transaction auth code
     * @param mixed $request
     */
    public function store(Request $request)
    {

        try{
            
        $request->validate([
            'transType' => ['required','string'],
        ]);

            //generate unique code
            $code = random_int(100000,999999);
            $maxLimit = 2;

            //store the code in cache
            Cache::put('_trans_auth_'.$request->transType, $code, now()->addMinutes($maxLimit));

            //initialize company details            
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $company = Company::on('smart_core')->findOrFail($cp_id);
            
            //send notification if enebled
            if($company->sysAdmin->hasSMSNotification() && $company->canSendText()){
            $sender = $company->sender();
            $template = $company->smsTemplate('authentication');

            $message = SmsTemplateParser::parse($template->description, [
                '{auth_code}' => $code
            ]);

            $this->textSmsService->sendSms($company->sysAdmin->routeNotificationForTextSms(), $message, $sender, $template->temp_id, $cp_id);

            }else{
                throw new \Exception('SMS notification has not been enabled.');
            }

            return response()->json([
                'cd'=>0,
                'msg'=>'Authentication code has been sent. Valid only for '.$maxLimit.' minutes'
            ]);

        } catch(\Throwable $e){
            return  response()->json([
                'cd'=>5,
                'msg'=>$e->getMessage(),
            ],500);
        }
    }

    public function authenticate(Request $request){
    {
        try {
            
        $request->validate([
            'transType' => ['required','string'],
            'authCode'=>['required','string'],
        ]);

        $cache_key = '_trans_auth_'.$request->transType;

        if(!Cache::has($cache_key) || $request->authCode != Cache::get($cache_key)){
            throw new \Exception('Missing or invalid code provided');
        }

        return response()->json([
            'cd' => 0,
            'msg' => 'Authenticated'
        ]);

        } catch(\Throwable $th){
            return response()->json([
                'cd' => 6,
                'msg'=>$th->getMessage()
            ]);
        }
    }
 }
}
