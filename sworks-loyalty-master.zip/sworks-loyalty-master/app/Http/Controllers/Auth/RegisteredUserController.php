<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use App\Http\Requests\Auth\RegisterUserRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use App\Models\Company;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): Response
    {
        $company = Company::all();

        return Inertia::render('Auth/Register', [
            'company' => $company
        ]);
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function stores(RegisterUserRequest $request): RedirectResponse
    {
        $companyId = $request->validated('company_id');
        $company = Company::find($companyId);

        if ($company) {
            $this->setDatabaseConnection($company->db);

            session([
                'company_id' => $companyId,
                'company_db' => $company->db
            ]);

            DB::setDefaultConnection('dynamic');

            $user = User::create([
                'name' => $request->validated('name'),
                'username' => $request->validated('username'),
                'email' => $request->validated('email'),
                'phone_no' => $request->validated('phoneNo'),
                'password' => Hash::make($request->validated('password')),
                'rememberToken' => $request->validated('remember')
            ]);

            Auth::guard('web')->login($user, true);

            //Store user ID in session
            session(['auth_user_id' => Auth::user()->id]);

            return Redirect::intended(RouteServiceProvider::HOME);
        } else {
            return Redirect::back()->withError('Company ID not found');
        }
    }
    private function setDatabaseConnection($database)
    {
        $dbConfig = [
            'driver' => 'mysql',
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => $database,
            'username' => env('DB_USERNAME', 'forge'),
            'password' => env('DB_PASSWORD', ''),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
        ];

        config(['database.connections.dynamic' => $dbConfig]);

        DB::purge('mysql');
        DB::setDefaultConnection('dynamic');
    }
}
