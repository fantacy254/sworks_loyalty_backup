<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use App\Models\Company;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class ManageUserController extends Controller
{
    /**
     * Summary of index
     * @param \Illuminate\Http\Request $request
     * @return mixed
     */
    public function index(Request $request)
    {
        try {
            $company = Company::find($request->input('company_id'));

            if ($company) {
                session(['company_db' => $company->db]);
                $this->setDatabaseConnection($company->db);
            }

            $users = User::all();
            $users->toArray();

            return $users;
        } catch (\Throwable $th) {
            return response()->json(['errors' => $th->getMessage()]);
        }
    }


    public function setDatabaseConnection($database)
    {
        $dbConfig = [
            'driver' => 'mysql',
            'host' => env('DB_HOST', '127.0.0.1'),
            'port' => env('DB_PORT', '3306'),
            'database' => $database,
            'username' => env('DB_USERNAME', 'root'),
            'password' => env('DB_PASSWORD', '$ilh0u3tt3'),
            'charset' => 'utf8mb4',
            'collation' => 'utf8mb4_unicode_ci',
            'prefix' => '',
            'strict' => true,
            'engine' => null,
        ];

        config(['database.connections.dynamic' => $dbConfig]);

        DB::purge('mysql');
        DB::setDefaultConnection('dynamic');
    }
}
