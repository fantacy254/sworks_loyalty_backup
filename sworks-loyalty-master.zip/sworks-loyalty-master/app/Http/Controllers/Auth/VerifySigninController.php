<?php

namespace App\Http\Controllers\Auth;

use App\Events\Authorize;
use App\Http\Controllers\Controller;
use App\Services\CompanyService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use Inertia\Inertia;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use App\Notifications\SmsNotification;
use App\Models\User;

class VerifySigninController extends Controller
{
    /**
     * Summary of authView
     * Display the authorization code view.
     * 
    * @param $token
     * @return \Illuminate\Http\RedirectResponse|\Inertia\Response
     */
    public function authView($token)
    {
        return Inertia::render('Auth/AuthCode');
    }

    public function ResendCode()
    {
        event(new Authorize(Auth::user(), CompanyService::generateAuthCode()));

        return redirect()->back()->withSuccess('We have sent you the Auth code, kindly check your phone');
    }

    public function verify(Request $request)
    {
        //validate request
        $request->validate([
            'code' => 'required|numeric'
        ]);

        try {
            //retrive code from session
            $cache_key = '_auth_code_' . Auth::user()->id;
            $cache_auth_key = '_authorize_user_' . Auth::user()->id;

            if (!Cache::has($cache_key)) {
                throw new Exception("Invalid or Expired code provided. Please try again");
            }

            $cachedCode = Cache::get($cache_key);

            if ((string) $request->input('code') != (string) $cachedCode) {
                throw new Exception("Invalid code provided. Please try again");
            }

            // Clear the stored code
            Cache::forget($cache_key);
            Cache::forget($cache_auth_key);

            // Redirect to the intended URL or home page

            return redirect()->intended(RouteServiceProvider::HOME)->withSuccess('You have been successfully logged in!');

        } catch (\Throwable $th) {
            //throw $th;
            return redirect()->back()->with('error', $th->getMessage());
        }

    }

    public function verifyCode(Request $request)
    {
        $userId = session('auth_user_id');
        $storedCode = Cache::get('auth_code_' . $userId);

        if ($storedCode && $storedCode == $request->input('auth_code')) {

            return 'success';
        } else {

            return 'fail';
        }

    }

}
