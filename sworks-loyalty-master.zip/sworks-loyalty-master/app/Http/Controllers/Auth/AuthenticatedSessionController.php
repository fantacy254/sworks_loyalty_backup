<?php

namespace App\Http\Controllers\Auth;

use App\Events\Authorize;
use App\Models\User;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Providers\RouteServiceProvider;
use App\Services\CompanyService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\RateLimiter;
use App\Mail\AuthorizationCodeMail;
use Illuminate\Support\Facades\Mail;

class AuthenticatedSessionController extends Controller
{
    public function index(Request $request)
    {
        return Inertia::render('Auth/Authenticate', [
            'token' => $request->route('token')
        ]);
    }
    /**
     * Display the login view.
     * @return mixed
     */
    public function create()
    {
        return Inertia::render('Auth/Login', [
            'canResetPassword' => Route::has('password.request'),
            'status' => session('status'),
        ]);

    }

    /**
     * Handle an incoming authentication request.
     * @return mixed
     */
    public function store(LoginRequest $request)
    {

        $request->authenticate();

        $request->session()->regenerate();

        if (Auth::user()->hasEmailNotification() || Auth::user()->hasSmsNotification()) {
            event(new Authorize(Auth::user(), CompanyService::generateAuthCode()));
        }

        if (!Auth::user()->isMultiCompanyAccess()) {

            //set session variables
            session([
                'company_id' => Auth::user()->company_id
            ]);
        }

        return redirect()->intended(RouteServiceProvider::HOME)->withSuccess('Welcome back ' . Auth::user()->name . '!');
        
    }
    

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->intended(RouteServiceProvider::LOGIN)->withSuccess('You have successfully logged out!');
    }

    public function destroyAll(Request $request): RedirectResponse
    {
        Auth::logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->intended(RouteServiceProvider::LOGIN)->withSuccess('You have successfully logged out!');
    }

    public function signout()
    {
        session()->forget('company_id');
        return redirect()->route('companySelect', ['token' => session('_token')])->withSuccess('You have been signed out. Kindly select the company to continue!');
    }
}
