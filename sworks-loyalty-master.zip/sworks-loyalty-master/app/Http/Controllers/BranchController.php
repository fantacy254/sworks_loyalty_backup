<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Company;
use App\Services\CompanyService;
use App\Services\DynamicService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Log;

class BranchController extends Controller
{
    public function show(Request $request)
    {
        try {
            $cp = Company::find($request->company);
            DynamicService::setDatabaseConnection($cp->db);

            $branch = Branch::on('dynamic')->get();
            $branch->toArray();

            return $branch;
        } catch (\Throwable $th) {
            return response()->json([
                'message' => 'Error',
                'error' => $th->getMessage()
            ], 500);
        }
    }

    public function store(Request $request)
    {
        $request->validate([
            'company' => 'required|exists:' . Company::class . ',id',
            'name' => 'required|string|max:255',
            'address' => 'nullable|string|max:255',
            'email' => 'nullable|email|max:255',
            'phone' => 'nullable|string|max:20',
        ]);

        try {

            CompanyService::addBranch(
                (int) $request->company,
                $request->name,
                $request->address,
                $request->email,
                $request->phone,
                Auth::user()->username
            );

            return redirect()->back()->withSuccess('Branch created successfully.');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage());
        }
    }
}
