<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class DeployController extends Controller
{
    public function handle(Request $request)
    {
        $payload = $request->getContent();

        $signature = $request->header('X-Hub-Signature-256');

        $secret = config('app.deploy_secret');

        if (!$signature) {
            return response()->json(['error' => 'Signature missing'], 400);
        }

        $hash = hash_hmac('sha256', $payload, $secret);

        $expected = "sha256={$hash}";

        if (!hash_equals($expected, $signature)) {
            Log::error('Signature mismatch', [
                'expected' => $expected,
                'github' => $signature
            ]);
            return response()->json(['error' => 'Mismatching tokens'], 403);
        }

        exec('bash /home/sworksco/loyalty/deploy.sh >> /home/sworksco/deploy.log 2>&1 &');

        return 'Deploy started';

    }
}
