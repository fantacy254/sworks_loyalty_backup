<?php

namespace App\Http\Controllers;

use App\Events\SendBulkSMS;
use App\Models\Loyalty;
use App\Models\SMSTemplate;
use App\Notifications\SmsNotification;
use App\Services\TextSmsService;
use App\Support\SmsTemplateParser;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Inertia\Inertia;

class TextSmsController extends Controller
{
    protected $textSmsService;

    public function __construct(TextSmsService $textSmsService)
    {
        $this->textSmsService = $textSmsService;
    }

    public function masterIndex()
    {
        $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

        $templates = SMSTemplate::on('smart_core')
            ->where(function ($query) use ($cp_id) {
                $query->where('company_id', $cp_id)
                    ->orWhereNull('company_id');
            })
            ->orderByRaw('CASE WHEN company_id = ? THEN 0 ELSE 1 END', [$cp_id])
            ->orderBy('temp_id')
            ->get();

        $cp_temp = $templates
            ->unique('temp_id')
            ->values();

        return Inertia::render('CRM/Master', [
            'templates' => $cp_temp
        ]);
    }

    public function store(Request $request)
    {
        //dd($request->all());
        $request->validate([
            'temp_id' => 'required|string',
            'title' => 'required|string',
            'level' => 'required|string',
            'description' => 'required|string',
            'isDefault' => 'boolean'
        ]);

        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

            if ($request->isDefault) {
                SMSTemplate::on('smart_core')
                    ->create([
                        'temp_id' => $request->temp_id,
                        'name' => $request->title,
                        'level' => $request->level,
                        'description' => $request->description,
                        'company_id' => $cp_id,
                        'input_by' => Auth::user()->username,
                    ]);
            } else {
                SMSTemplate::on('smart_core')
                    ->where('temp_id', $request->temp_id)
                    ->where('company_id', $cp_id)
                    ->update([
                        'temp_id' => $request->temp_id,
                        'name' => $request->title,
                        'level' => $request->level,
                        'description' => $request->description,
                        'input_by' => Auth::user()->username,
                        'edit_by' => Auth::user()->username,
                    ]);
            }

            return redirect()->back()->withSuccess('SMS template recorded successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage());
        }
    }

    public function sendBulk()
    {
        return Inertia::render('CRM/SendBulk');
    }

    public function storeBulk(Request $request)
    {
        $request->validate([
            'sender' => 'required|string',
            'recipient' => 'required|string',
            'phone_number' => 'nullable|required_if:recipient,manual|string',
            'master' => 'required_unless:recipient,all|numeric',
            'template_id' => 'required|string',
            'message' => 'required|string|max:1600',
        ]);

        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

            if ($request->recipient === 'manual') {
                $msg = SmsTemplateParser::parse($request->message);

                $this->textSmsService->sendSms($request->phone_number, $msg, $request->sender, $request->template_id, $cp_id);

            } else {
                $custs = $request->recipient === 'all'
                    ? Loyalty::on('dynamic')
                        ->whereNotNull('phone')
                        ->get()
                    : Loyalty::on('dynamic')
                        ->whereNotNull('phone')
                        ->where($request->recipient . '_id', $request->master)
                        ->get();

                foreach ($custs as $cust) {
                    event(new SendBulkSMS($cust, $request->sender, $request->template_id, $request->message, $cp_id));
                }
            }

            return redirect()->back()->withSuccess('Bulk SMS messages sent successfully');
        } catch (\Throwable $th) {
            return redirect()->back()->withError($th->getMessage());
        }
    }

    public function show()
    {
        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

            $templates = SMSTemplate::on('smart_core')
                ->where(function ($query) use ($cp_id) {
                    $query->where('company_id', $cp_id)
                        ->orWhereNull('company_id');
                })
                ->orderByRaw('CASE WHEN company_id = ? THEN 0 ELSE 1 END', [$cp_id])
                ->orderBy('temp_id')
                ->get();

            $cp_temp = $templates
                ->unique('temp_id')
                ->values();

            return response()->json($cp_temp);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }

    public function outbox()
    {
        return Inertia::render('CRM/Outbox');
    }

    public function outboxTrans(Request $request)
    {
        $request->validate([
            'from' => 'required|date|string',
            'to' => 'required|date|string'
        ]);

        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

            $fromDate = Carbon::parse($request->from)->startOfDay();
            $toDate = Carbon::parse($request->to)->endOfDay();

            $dt = DB::connection('smart_core')
                ->table('sms_trans')
                ->where('company_id', $cp_id)
                ->whereBetween('created_at', [$fromDate, $toDate])
                ->orderByDesc('created_at')
                ->get();

            return response()->json($dt);
        } catch (\Throwable $th) {
            return response()->json(['error' => $th->getMessage()], 500);
        }
    }
}
