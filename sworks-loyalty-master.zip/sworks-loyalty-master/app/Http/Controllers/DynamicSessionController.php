<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class DynamicSessionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        try {
            if (Auth::check() && !Auth::user()->isMultiCompanyAccess()) {

                return redirect(RouteServiceProvider::HOME)->withSuccess('Welcome back ' . Auth::user()->name . '!');
            }

            $company = Company::select('id', 'name')->orderBy('id')->get();

            return Inertia::render('Auth/Authenticate', [
                'companies' => $company
            ]);

        } catch (\Throwable $th) {
            //Log::error($th->getMessage());
            return redirect()->route('login')->with('Error', 'An error has occued');
        }
    }
    public function store(Request $request)
    {
        //validate request
        $request->validate([
            'company' => 'required|numeric'
        ]);

        //set company db to the session
        session([
            'company_id' => $request->input('company')
        ]);

        return redirect()->intended(RouteServiceProvider::HOME)->withSuccess('Welcome back ' . Auth::user()->name . '!');
    }

    public function masterIndex()
    {
        //set company db to the session
        session([
            'company_id' => 0
        ]);

        return Inertia::render('Master/MasterIndex');
    }
}
