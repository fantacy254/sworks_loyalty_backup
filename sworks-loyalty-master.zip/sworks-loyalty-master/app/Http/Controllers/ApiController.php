<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Loyalty;
use App\Models\LoyType;
use App\Models\Master;
use App\Notifications\SmsNotification;
use App\Services\ApiService;
use App\Services\LoyaltyService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use App\Models\User;
use Carbon\Carbon;

class ApiController extends Controller
{
    /**
     * 
     * create system users
     * @return mixed
     * 
     */
    public function addSysUser(Request $request)
    {

        try {

            $request->validate([
                'name' => 'required|string',
                'username' => 'required|string|unique:' . User::class,
                'email' => 'nullable|email|unique:' . User::class,
                'phone_no' => 'nullable|string|max:13|unique:' . User::class,
                'access_level_id' => 'required|numeric'
            ]);

            //Extract Key data
            $key = $request->header('ClientKey');
            $clientData = ApiService::getClientKeyData($key);

            //create system user
            $password = Str::random(8);

            ApiService::createSystemUser(
                $request->name,
                $request->username,
                $request->email,
                $request->phone_no,
                $password,
                $request->access_level_id,
                $clientData['company'],
                $clientData['branch']
            );


            /**$user = User::where('username', $request->username)->first();
            $sender = $user->company->sender_id;

            if (!$sender) {
               Log::error('Sender ID not found.');
            }

            //$message = "Your credentials are:\nUsername: " . $request->username . ",\nPassword: " . $password;

            //$user->notify(new SmsNotification($message, $sender));*/

            return response()->json([
                'rsltCd' => 200,
                'rsltMsg' => "User created successfully.\nNew Password is: " . $password
            ]);

        } catch (\Throwable $th) {
            return response()->json([
                'cd' => 3,
                'msg' => $th->getMessage()
            ], 422);
        }

    }

    /**
     * Register loyalty customer
     * 
     * @return mixed
     */
    public function addLoyaltyCustomer(Request $request)
    {

        try {

            $request->validate([
                'id_no' => ['required', 'numeric'],
                'name' => ['required', 'string'],
                'email' => ['nullable', 'email'],
                'phone' => ['required', 'numeric'],
                'pin_no' => ['nullable', 'string'],
                'card_no' => ['nullable', 'string'],
                'address' => ['nullable', 'string'],
                'gender' => ['required', 'string'],
                'dob' => ['required', 'date'],
                'input_by' => ['required', 'string']
            ]);

            //Extract Key data
            $key = $request->header('ClientKey');
            $clientData = ApiService::getClientKeyData($key);

            LoyaltyService::registerLoyaltyCustomer(
                $request->id_no,
                $request->name,
                $request->email,
                $request->phone,
                $request->pin_no,
                $request->card_no,
                $request->address,
                $request->gender,
                true,
                $request->dob,
                $clientData['company'],
                $clientData['branch'],
                $request->input_by
            );

            /**send sms notification to the customer
            $cp = Company::find($clientData['company']);
            $sender = $cp->sender_id;

            if (!$sender) {
                Log::error('Sender ID not found.');
            }

            $message = "Your account has been created.\nShop more to earn more points.";

            DynamicService::setDatabaseConnection($cp->db);
            $cust = Loyalty::on('dynamic')
                    ->where('code', $request->id_no)
                    ->first();

            //$cust->notify(new SmsNotification($message, $sender));*/

            return response()->json([
                'cd' => 0,
                'msg' => "Customer registered successfully"
            ]);

        } catch (\Throwable $th) {
            return response()->json([
                'cd' => 4,
                'msg' => $th->getMessage()
            ], 422);
        }
    }


    /**
     * Validate loyalty customer upon points earning
     * @return mixed
     */
    public function validateCustomer(Request $request)
    {
        try {
            //validate 
            $request->validate([
                'cust_code' => 'required|String',
            ]);

            //Extract Key data
            $key = $request->header('ClientKey');
            $clientData = ApiService::getClientKeyData($key);

            $cust = LoyaltyService::validateLoyaltyCustomer($clientData['company'], $request->cust_code);

            return response()->json([
                'cd' => 0,
                'msg' => 'success',
                'data' => $cust
            ]);

        } catch (\Throwable $th) {
            return response()->json([
                'cd' => 5,
                'msg' => $th->getMessage()
            ], 422);
        }
    }

    public function storeBranches(Request $request)
    {
        try {
            //validate 
            $request->validate([
                'cpnyId' => 'required|Numeric'
            ]);

            //validate companydetails
            if (!$this->isValidCompany($request->input('cpnyId'))) {
                return response()->json([
                    'rsltCd' => "01",
                    'Msg' => 'Invalid Company details or license issue'
                ]);
            }

            $request->validate([
                'data' => 'required|Array',
                'data.*.code' => 'required|string|unique:' . Branch::class,
                'data.*.name' => 'required|string|unique:' . Branch::class,
                'data.*.input_by' => 'nullable|string',
                'data.*.edit_by' => 'nullable|string',
                'data.*.email' => 'nullable|email'
            ]);


            DB::transaction(function () use ($request) {
                $data = $request->data;
                $updDt = [];

                foreach ($data as $key => $value) {
                    $updDt[] = [
                        'code' => $value['code'],
                        'name' => $value['name'],
                        'branch_level' => '2',
                        'branch_location' => '1',
                        'input_by' => $value['input_by'],
                        'edit_by' => $value['edit_by'],
                        'ip_address' => '0.0.0.0',
                        'port' => '23',
                        'username' => 'admin',
                        'password' => 'password',
                        'sync' => false,
                        'email' => $value['email'],
                        'mpesa_till' => null,
                        'short_name' => Str::of($value['name'])->explode(' ')[0],
                        'connected' => false,
                        'created_at' => now(),
                        'updated_at' => now()
                    ];
                }

                DB::table('branch')->upsert(
                    $updDt,
                    ['id', 'code', 'name'],
                    [
                        'branch_level',
                        'branch_location',
                        'input_by',
                        'edit_by',
                        'ip_address',
                        'port',
                        'username',
                        'password',
                        'sync',
                        'email',
                        'mpesa_till',
                        'short_name',
                        'connected',
                        'created_at',
                        'updated_at'
                    ]
                );
            });

            return response()->json([
                'rsltCd' => '00',
                'rsltMsg' => 'Branche{s} added successfully'
            ], 200);

        } catch (\Throwable $th) {
            return response()->json([
                'errCd' => 505,
                'errMsg' => $th->getMessage()
            ]);
        }
    }

    public function storeEarnedPoints(Request $request)
    {
        try {
            //validate 
            $request->validate([
                'cust_code' => 'required|numeric',
                'run_date' => 'required|date',
                'rct_no' => 'required|string',
                'rct_amt' => 'required|numeric',
                'points' => 'required|numeric',
                'till_no' => 'required|string',
                'operator' => 'required|string',
            ]);

            //Extract Key data
            $key = $request->header('ClientKey');
            $clientData = ApiService::getClientKeyData($key);

            $docNo = LoyaltyService::generateTransDocNo(
                $clientData['company'],
                $clientData['branch'],
                'ERN'
            );

            LoyaltyService::postEarnPoints(
                $clientData['company'],
                $clientData['branch'],
                $docNo,
                'ERN',
                $request->cust_code,
                $request->run_date,
                $request->rct_no,
                $request->rct_amt,
                $request->points,
                $request->till_no,
                $request->operator
            );
            
            return response()->json([
                'cd' => 0,
                'msg' => 'success'
            ]);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json([
                'cd' => 6,
                'msg' => $th->getMessage()
            ], 422);
        }
    }

    public function consumeVoucher(Request $request)
    {
        try {
            //validate 
            $request->validate([
                'rct_no' => 'required|string',
                'voucher' => 'required|string',
                'run_date' => 'required|date',
                'used_till' => 'required|string',
                'operator' => 'required|string',
            ]);

            //Extract Key data
            $key = $request->header('ClientKey');
            $clientData = ApiService::getClientKeyData($key);

            LoyaltyService::consumeVoucher(
                $clientData['company'],
                $clientData['branch'],
                $request->voucher,
                $request->run_date,
                $request->rct_no,
                $request->used_till,
                $request->operator,
            );

            return response()->json([
                'cd' => 0,
                'msg' => 'Success'
            ]);

        } catch (\Throwable $th) {
            //throw $th;
            return response()->json([
                'cd' => 7,
                'msg' => $th->getMessage()
            ], 422);
        }
    }

    public function validateLoyaltyVoucher(Request $request)
    {
        try {
            //validate request inputs
            $request->validate([
                'voucher' => 'required|string'
            ]);

            //Extract Key data
            $key = $request->header('ClientKey');
            $clientData = ApiService::getClientKeyData($key);

            $vch = LoyaltyService::validateVoucher(
                $clientData['company'],
                $clientData['branch'],
                $request->voucher
            );

            return response()->json([
                'cd' => 0,
                'msg' => 'success',
                'data' => $vch
            ]);

        } catch (\Throwable $th) {
            return response()->json([
                'cd' => 8,
                'msg' => $th->getMessage()
            ], 422);
        }
    }
}
