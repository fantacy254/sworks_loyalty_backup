<?php

namespace App\Http\Controllers;


use App\Models\AccessLevel;
use App\Models\Branch;
use App\Services\CompanyService;
use Hash;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Str;
use Inertia\Inertia;
use App\Models\Company;
use App\Http\Requests\Auth\UserRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Log;
use App\Http\Requests\UserProfileRequest;
use App\Http\Requests\UserProfilePasswordResetRequest;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * @return mixed
     */
    public function index(User $user)
    {
        $response = Gate::inspect('view', $user);

        if ($response->allowed()) {
            try {
                $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

                $users = User::withTrashed()
                    ->select('users.id', 'users.name', 'username', 'phone_no', 'users.email', 'access_level.name as level', 'users.created_at')
                    ->where('company_id', $cp_id)
                    ->leftJoin('access_level', 'users.access_level_id', '=', 'access_level.id')
                    ->get();

                return Inertia::render('Auth/Users', [
                    'users' => $users
                ]);
            } catch (\Throwable $th) {
                Log::error($th->getMessage());
                return Redirect::route('home')->withError('We have encoutered an error');
            }
        } else {
            return Redirect::route('home')->withInfo($response->message());
        }
    }
    /**
     * 
     * show current user profile
     * @return mixed
     * 
     */
    public function showProfile()
    {
        try {
            $user = Auth::user();

            return Inertia::render('Auth/AuthProfile', [
                'user' => $user
            ]);
            
        } catch (\Throwable $th) {
            return redirect()->route('home')->withError('Error getting user profile');
        }
    }

    public function updateProfile(UserProfileRequest $request, User $user)
    {
        try {
            Log::info($request->validated());

            $user->update([
                'username' => $request->validated('username'),
                'name' => $request->validated('name'),
                'phone_no' => $request->validated('phone_no'),
                'email' => $request->validated('email'),
            ]);
            Log::info($user);
            return redirect()->back()->withSuccess('User profile updated successfully');
        } catch (\Throwable $th) {
            //Log::error($th->getMessage());
            return redirect()->route('home')->withError('An has error has occured updating user profile');
        }
    }

    public function ProfilePasswordReset(UserProfilePasswordResetRequest $request, User $user)
    {
        try {
            $user->update([
                'password' => Hash::make($request->validated('password'))
            ]);

            return redirect()->route('logout')->with('info', 'Password updated successfully');
        } catch (\Throwable $th) {
            Log::error($th->getMessage());
            return redirect()->route('home')->withError('An has error has occured updating user password');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return mixed
     */
    public function create()
    {
        return Inertia::render('Auth/Create');
    }


    /**
     * Summary of getUsers
     * @param mixed $companyId
     * @return mixed
     */
    public function getUsers(Request $request)
    {
        try {
            $users = User::where('company_id', session('company_id'))->select('id', 'name', 'username')->get();
            $users->toArray();

            return response()->json($users);
        } catch (\Throwable $th) {
            Log::error($th->getMessage());
            return response('An error has occured retriving users', 505);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request)
    {
        //$password = Str::random(8);
        $name = $request->validated('fname') . ' ' . $request->validated('lname');

        CompanyService::addUser(
            Str::upper($name),
            Str::upper($request->validated('username')),
            $request->validated('email'),
            $request->validated('phone_no'),
            $request->validated('access_level'),
            session('company_id'),
            $request->validated('branch')
        );

        return Redirect::route('users')->withSuccess('User created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        try {
            $user = User::where('users.id', $request->input('id'))
                ->select('users.id', 'username', 'users.name', 'company.name as company')
                ->leftJoin('company', 'users.company_id', '=', 'company.id')
                ->firstOrFail();
            return response()->json($user);
        } catch (\Throwable $th) {
            //throw $th;
            Log::error($th->getMessage());
            return response('An error has occured, kindly check your inputs', 505);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     * @return mixed
     */
    public function edit(User $user, $id)
    {
        $response = Gate::inspect('edit', $user);

        if ($response->allowed()) {
            try {
                $levels = AccessLevel::all();
                $levels->toArray();

                $branch = Branch::all();
                $branch->toArray();

                $user = User::where('id', $id)->get();

                return Inertia::render('Auth/Edit', [
                    'user' => $user,
                    'levels' => $levels,
                    'branches' => $branch
                ]);
            } catch (\Throwable $th) {
                return Redirect::back()->withError($th->getMessage());
            }
        } else {
            return Redirect::back()->withInfo($response->message());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        $response = Gate::inspect('update', $user);

        if ($response->allowed()) {
            try {
                $request->validate([
                    'username' => [
                        'required',
                        'string',
                        Rule::unique(User::class, 'username')->ignore($user->id),
                    ],
                    'email' => ['required', 'string', 'lowercase', 'email', 'max:255', Rule::unique(User::class, 'email')->ignore($user->id)],
                    'phone' => ['required', 'string', 'max:13', Rule::unique(User::class, 'phone_no')->ignore($user->id)],
                    'access_level' => 'required|numeric',
                    'branch' => 'required|Numeric'
                ]);

                $user->update([
                    'username' => $request->input('username'),
                    'name' => $request->input('name'),
                    'email' => $request->input('email'),
                    'phone_no' => $request->input('phone'),
                    'access_level_id' => $request->input('access_level'),
                    'br_code' => $request->input('branch')
                    ]);

                //dd($query);    
                return Redirect::route('users')->withSuccess('User records updated successfully');
            } catch (\Throwable $th) {
                return Redirect::back()->withError($th->getMessage());
            }
        } else {
            return Redirect::back()->withInfo($response->message());
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        $response = Gate::inspect('delete', $user);

        if ($response->allowed()) {
            try {
                $user->delete();
                return Redirect::back()->withSuccess('User Deleted Successfully');
            } catch (\Throwable $th) {
                return Redirect::back()->withError($th->getMessage());
            }
        } else {
            return Redirect::back()->withInfo($response->message());
        }
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore(User $user, $id)
    {
        $response = Gate::inspect('restore', $user);

        if ($response->allowed()) {
            try {
                User::where('id', $id)->withTrashed()->restore();
                return Redirect::back()->withInfo('User restored Successfully');
            } catch (\Throwable $th) {
                return Redirect::back()->withError($th->getMessage());
            }
        } else {
            return Redirect::back()->withInfo($response->message());
        }
    }

    public function sysAdmin()
    {
        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

            $cp = Company::on('smart_core')->findOrFail($cp_id);

            $admn = $cp->sysAdmin()
            ->select('id', 'name', 'phone_no')
            ->first();

            $result = [
                'id' => $admn->id,
                'name' => $admn->name,
                'masked_phone' => $this->masked_phone($admn->phone_no),
            ];

            return response($result);
        } catch (\Throwable $th) {
            return response($th->getMessage(),500);
        }   
    }

    private function masked_phone($phone)
    {
        return str_repeat('*', strlen($phone)-3).substr($phone,-3);
    }
}
