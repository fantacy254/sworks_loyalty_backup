<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\User;
use App\Services\CompanyService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class SettingsController extends Controller
{
    public function index()
    {
        return Inertia::render('Settings/General');
    }

    public function notify()
    {
        return Inertia::render('Settings/Notifications');
    }

    public function showNotify()
    {
        $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
        $res = Company::where('id', $cp_id)
            ->select('send_email', 'send_sms', 'sender_id')
            ->get();

        return $res->toArray();
    }

    public function storeNotify(Request $request)
    {
        $request->validate([
            'type' => 'required|string',
            'value' => 'required|string'
        ]);

        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

            CompanyService::updateNofication(
                $cp_id,
                $request->type,
                (int) $request->value
            );

            return response('Success');
        } catch (\Throwable $th) {
            //throw $th;
            return response($th->getMessage());
        }
    }

    public function updateSender(Request $request)
    {
        $request->validate([
            'sender' => 'required|string|max:11'
        ]);

        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

            CompanyService::updateSender(
                $cp_id,
                $request->sender
            );

            return back()->with('success', 'Sender name updated successfully');
        } catch (\Throwable $th) {
            //throw $th;
            return back()->with('error', $th->getMessage());
        }
    }

    public function privacy()
    {
        return Inertia::render('Settings/Privacy');
    }

    public function showPrivacy()
    {
        try {
            $res = User::where('id', Auth::user()->id)
                ->select('two_factor', 'auth_email', 'auth_sms')
                ->firstOrFail();

            return $res->toArray();
        } catch (\Throwable $th) {
            return response($th->getMessage());
        }
    }

    public function enableTwoFactor(Request $request)
    {
        try {

            CompanyService::enableTwoFactor(
                Auth::user()->id,
                (bool) $request->input('activateTwoFactor')
            );

            return response('success');

        } catch (\Throwable $th) {
            return response($th->getMessage());
        }
    }

    public function enableSMSAuthentication(Request $request)
    {
        try {

            CompanyService::enableSMSAuthentication(
                Auth::user()->id,
                (bool) $request->input('activateAuthText')
            );

            return response('success');

        } catch (\Throwable $th) {
            return response($th->getMessage());
        }
    }

    public function enableEmailAuthentication(Request $request)
    {
        try {

            CompanyService::enableEmailAuthentication(
                Auth::user()->id,
                (bool) $request->input('activateAuthEmail')
            );

            return response('success');

        } catch (\Throwable $th) {
            return response($th->getMessage());
        }
    }
}
