<?php

namespace App\Http\Middleware;

use App\Models\Company;
use App\Services\ApiService;
use Closure;
use Illuminate\Http\Request;

class EnsureValidClientKey
{
    private function isValidClientKey($key)
    {
        try {

            $data = ApiService::getClientKeyData($key);

            if (!$data) {
                return false;
            }

            $exists = Company::where('id', $data['company'])->exists();

            return $data && isset($data['company']) && isset($data['branch']) && $exists;
        } catch (\Throwable $th) {
            //throw $th;
            return false;
        }
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        //get authorization from request header
        $key = $request->header('ClientKey');

        //confirm key validity
        if (!$key || !$this->isValidClientKey($key)) {
            return response()->json([
                'cd' => 2,
                'msg' => 'Missing or Invalid Client Key'
            ], 401);
        }

        return $next($request);
    }
}
