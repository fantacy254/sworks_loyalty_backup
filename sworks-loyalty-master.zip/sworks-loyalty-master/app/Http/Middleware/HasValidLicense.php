<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\Company;
use Carbon\Carbon;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Redirect;

class HasValidLicense
{
    private function isValidCompany($company_id)
    {
        //check company license
        if (!Company::where('id', $company_id)->exists()) {
            return false;
        }

        $company = Company::where('id', $company_id)->get();

        $expireDt = Carbon::parse($company[0]->expire_at);

        if ($expireDt->lessThan(Carbon::today())) {
            return false;
        }

        $license = $company[0]->license;

        if (!$license) {
            return false;
        }

        return true;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        //check company license validity
        if (!$this->isValidCompany(session('company_id'))) {
            return redirect()->route('license.index'); //->with('info', 'invalid company details or license has expires');
        }
        return $next($request);
    }
}
