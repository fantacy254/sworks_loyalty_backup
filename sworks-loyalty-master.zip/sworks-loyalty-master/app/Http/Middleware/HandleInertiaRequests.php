<?php

namespace App\Http\Middleware;

use App\Models\Branch;
use App\Services\CompanyService;
use App\Services\DynamicService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Inertia\Middleware;
use App\Models\Company;
use App\Models\Loyalty;
use Illuminate\Support\Facades\Gate;

class HandleInertiaRequests extends Middleware
{
    /**
     * The root template that's loaded on the first page visit.
     *
     * @see https://inertiajs.com/server-side-setup#root-template
     * @var string
     */
    protected $rootView = 'app';

    /**
     * Determines the current asset version.
     *
     * @see https://inertiajs.com/asset-versioning
     * @param  \Illuminate\Http\Request  $request
     * @return string|null
     */
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    /**
     * Defines the props that are shared by default.
     *
     * @see https://inertiajs.com/shared-data
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function share(Request $request): array
    {
        return array_merge(parent::share($request), [
            'auth' => function () use ($request) {
                return [
                    'user' => $request->user() ? [
                        'id' => $request->user()->id,
                        'username' => $request->user()->username,
                        'name' => $request->user()->name,
                        'avatar' => $request->user()->avatar,
                        'email' => $request->user()->email,
                        'branch' => $request->user()->isMultiCompanyAccess() ? 0 : $request->user()->branch_id,
                        'access_level' => $request->user()->AccessLevel->id,
                        'multi_access' => $request->user()->isMultiCompanyAccess(),
                        'isAdmin' => $request->user()->isAdmin() || $request->user()->isMultiCompanyAccess(),
                        'sys_type' => CompanyService::userCompany($request->user())
                    ] : null,
                    'company' => $this->currentCompany($request) ?? ['name' => 'Master Company'],
                    'branch' => $this->currentUserBranch($request) ?? ['name' => 'Main']
                ];
            },
            'branches' => function () use ($request) {
                return $this->sessionBranches($request);
            },
            'flash' => function () {
                return [
                    'success' => session('success'),
                    'error' => session('error'),
                    'logout' => session('logout'),
                    'info' => session('info'),
                    'status' => session('status'),
                ];
            }
        ]);
    }
    private function currentCompany($request)
    {
        if (is_null($request->user()) || (is_null(session('company_id'))) || (session('company_id') == 0)) {
            return null;
        }

        $cp_id = $request->user()->isMultiCompanyAccess() ? session('company_id') : $request->user()->company_id;

        $company = Company::find($cp_id, ['id', 'name', 'address', 'phone', 'email', 'sender_id', 'sms_rate']);

        return $company->toArray();
    }
    private function currentUserBranch($request)
    {
        if (is_null($request->user()) || (is_null(session('company_id'))) || (session('company_id') == 0)) {
            return null;
        }

        $cp_id = $request->user()->isMultiCompanyAccess() ? session('company_id') : $request->user()->company_id;
        $company = Company::find($cp_id);
        DynamicService::setDatabaseConnection($company->db);

        $branch = null;
        $exists = Branch::on('dynamic')->where('id', $request->user()->branch_id)->exists();

        if ($exists) {
            $branch = Branch::on('dynamic')->where('id', $request->user()->branch_id)->select('id', 'name')->first();
        } else {
            $branch = Branch::where('id', 1)->select('id', 'name')->first();
        }

        return $branch;

    }

    private function sessionBranches($request)
    {
        if (is_null($request->user()) || (is_null(session('company_id'))) || (session('company_id') == 0)) {
            return [];
        }

        $cp_id = $request->user()->isMultiCompanyAccess() ? session('company_id') : $request->user()->company_id;
        $cp = Company::findOrFail($cp_id);
        DynamicService::setDatabaseConnection($cp->db);

        $brs = Branch::on('dynamic')
            ->select('id', 'name')
            ->orderBy('id')
            ->get();

        $branches = [
            [
                'id' => 0,
                'name' => 'ALL BRANCHES'
            ],
            ...$brs
        ];

        return $branches;
    }
}
