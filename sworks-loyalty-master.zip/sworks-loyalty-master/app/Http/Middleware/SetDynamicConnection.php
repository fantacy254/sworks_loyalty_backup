<?php

namespace App\Http\Middleware;

use App\Providers\RouteServiceProvider;
use App\Services\DynamicService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Company;

class SetDynamicConnection
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Retrieve the dynamic connection name from session or any other source
        $dynamicConnection = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;

        // Set the dynamic connection
        if (!$dynamicConnection) {
            return redirect()->intended(RouteServiceProvider::LOGIN)->withSuccess('You have successfully logged out!');
        }

        $cp = Company::findOrFail($dynamicConnection);
        DynamicService::setDatabaseConnection($cp->db);

        return $next($request);
    }

}
