<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;

class EncryptDecryptParameters
{
    /**
     * Summary of encryptable
     * @var array
     */
    protected $encryptable = ['id', 'typ', 'doc', 'type', 'user'];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        // Decrypt route parameters
        $this->decryptRouteParameters($request);

        // Decrypt query parameters
        $this->decryptQueryParameters($request);

        return $next($request);
    }

    protected function decryptRouteParameters($request)
    {
        $routeParams = $request->route()?->parameters() ?? [];

        foreach ($this->encryptable as $param) {
            if (isset($routeParams[$param])) {
                try {
                    $decrypted = Crypt::decrypt($routeParams[$param]);
                    // Replace the route parameter
                    $request->route()->setParameter($param, $decrypted);
                } catch (\Exception $e) {
                    Log::warning("Failed to decrypt route parameter: {$param}");
                }
            }
        }
    }

    protected function decryptQueryParameters($request)
    {
        $query = $request->query();

        foreach ($this->encryptable as $param) {
            if ($request->has($param)) {
                try {
                    $encrypted = $request->query($param);
                    $decrypted = Crypt::decrypt($encrypted);
                    $request->query->set($param, $decrypted);
                } catch (\Exception $e) {
                    Log::warning("Failed to decrypt query parameter: {$param}");
                }
            }
        }
    }

}
