<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cache;

class EnsureAuthorizationCodeIsValid
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $cacheKey = '_authorize_user_' . Auth::user()->id;

        // Check if the auth code session exists
        if (($request->user()->hasEmailNotification() || $request->user()->hasSmsNotification()) && ($request->user()->company->canSendEmail() || $request->user()->company->canSendText()) && Cache::has($cacheKey)) {
            // Store the intended URL before redirecting
            $sessionId = session('_token');

            return redirect()->route('auth.session', ['token' => $sessionId])->withSuccess('Authorization has been sent!');

        }

        return $next($request);
    }
}
