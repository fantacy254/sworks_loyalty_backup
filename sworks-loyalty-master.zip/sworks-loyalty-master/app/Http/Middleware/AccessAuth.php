<?php

namespace App\Http\Middleware;

use App\Models\AccessToken;
use Closure;
use Illuminate\Http\Request;

class AccessAuth
{

    private function isinvalidToken($token)
    {
        //check is the token exists in the database
        return AccessToken::where('api_token', $token)->whereNotNull('verified_at')->exists();
    }

    /**
     * Handle an incoming request.
     *
     * @param  Request  $request
     * @param  \Closure(Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        //get authorization from request header
        $token = $request->header('Authorization');

        //confirm token validity
        if (!$token || !$this->isInvalidToken($token)) {
            return response()->json([
                'cd' => 1,
                'msg' => 'Unauthorized Access'
            ], 401);
        }

        return $next($request);
    }
}
