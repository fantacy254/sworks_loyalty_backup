<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CustomerUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'name' => 'required|string',
            'email' => 'nullable|string|lowercase|email|max:255',
            'phone' => 'required|string',
            'card_no' => 'nullable|string',
            'gender' => 'required|string',
            'dob' => 'required|date',
            'address' => 'nullable|string',
            'status' => 'nullable|boolean',
            'pin_no' => 'nullable|string|max:12|min:11',
            'branchId' => 'required|numeric'
        ];
    }
}
