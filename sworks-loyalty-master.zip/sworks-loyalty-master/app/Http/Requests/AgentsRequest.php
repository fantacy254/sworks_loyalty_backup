<?php

namespace App\Http\Requests;

use App\Models\Agent;
use Illuminate\Foundation\Http\FormRequest;

class AgentsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'agent_id' => 'required|numeric|digits_between:7,9|unique:' . Agent::class, //36979821
            'agent_name' => 'required|string|unique:' . Agent::class,
            'agent_pin' => 'required|alpha_num|max:11|unique:' . Agent::class, //A012129655U
            'address' => 'required|string',
            'email' => 'required|email',
            'county' => 'required|Numeric',
            'city' => 'required|string',
            'region' => 'required|numeric'
        ];
    }
}
