<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class PaymentsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'type' => 'required|String',
            'agent_id' => 'required|Numeric',
            'amount' => 'required|Numeric',
            'mode' => 'required|Numeric',
            'ref' => 'required|String',
            'loans' => 'required|Array',
            'loans.*.loan_id' => 'required|exists:loans,id',
            'loans.*.allocated' => 'required|Numeric|min:0',
        ];
    }
}
