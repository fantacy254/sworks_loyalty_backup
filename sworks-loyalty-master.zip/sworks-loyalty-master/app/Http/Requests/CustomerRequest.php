<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Loyalty;

class CustomerRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'branchId' => 'required|numeric',
            'code' => 'required|string|unique:' . Loyalty::class,
            'name' => 'required|string|unique:' . Loyalty::class,
            'email' => 'nullable|string|lowercase|email|max:255|unique:' . Loyalty::class,
            'phone' => 'required|string|unique:' . Loyalty::class,
            'pin_no' => 'nullable|string|max:12|min:11|unique:' . Loyalty::class,
            'card_no' => 'nullable|string|unique:' . Loyalty::class,
            'gender' => 'required|string',
            'dob' => 'required|date',
            'address' => 'nullable|string',
            'status' => 'required|boolean',
        ];
    }
}
