<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AwardPointsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'brcode' => 'required|numeric',
            'trans_type' => 'nullable|string',
            'name' => 'required|string',
            'bal' => 'required|numeric',
            'refNo' => 'nullable|string',
            'points' => 'required|numeric',
            'notes' => 'nullable|string'
        ];
    }
}
