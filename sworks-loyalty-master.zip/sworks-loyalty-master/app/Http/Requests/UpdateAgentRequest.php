<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateAgentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'agent_id' => 'required|numeric|digits_between:7,9', //36979821
            'agent_name' => 'required|string',
            'agent_pin' => 'required|alpha_num|max:11', //A012129655U
            'address' => 'required|string',
            'email' => 'required|email',
            'county' => 'required|Numeric',
            'city' => 'required|string',
            'region' => 'required|numeric'
        ];
    }
}
