<?php

namespace App\Support;

class SmsTemplateParser
{
    public static function parse(string $template, array $data = []): string
    {
        // Convert literal \n to actual newlines
        $template = str_replace('\\n', "\n", $template);

        // Replace placeholders
        return strtr($template, $data);
    }
}