<?php

namespace App\Imports;

use App\Events\CustomerCreated;
use App\Models\Company;
use App\Models\Loyalty;
use App\Services\DynamicService;
use App\Services\LoyaltyService;
use Carbon\Carbon;
use Exception;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Maatwebsite\Excel\Concerns\OnEachRow;
use Maatwebsite\Excel\Concerns\SkipsEmptyRows;
use Maatwebsite\Excel\Concerns\SkipsOnFailure;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithUpserts;
use Maatwebsite\Excel\Concerns\WithValidation;
use Maatwebsite\Excel\Row;
use Maatwebsite\Excel\Validators\Failure;

class LoyaltyCustomerImport implements
    OnEachRow,
    WithUpserts,
    WithValidation,
    WithHeadingRow,
    WithChunkReading,
    ShouldQueue,
    SkipsOnFailure,
    WithBatchInserts,
    SkipsEmptyRows
{
    /**
     * @param Row $row
     *
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function onRow(Row $row)
    {
        try {
            $cp_id = Auth::user()->isMultiCompanyAccess() ? session('company_id') : Auth::user()->company_id;
            $cp = Company::findOrFail($cp_id);
            DynamicService::setDatabaseConnection($cp->db);

            $connection = DB::connection('dynamic');

            if (!$connection) {
                throw new Exception('Dynamic database connection failed to initialize');
            }

            $connection->beginTransaction();

            $data = $row->toArray();

            $branch = auth()->user()->branch_id;
            $init_bal = LoyaltyService::serializeAmount($data['acc_bal']) ?? 0;

            //create or update customer
            Loyalty::upsert(
                [
                    'accno' => LoyaltyService::generateAccNo($cp_id, $branch, $data['code'], $data['name']), //T1100002
                    'code' => $data['code'],
                    'name' => Str::upper($data['name']),
                    'email' => $data['email'] ?? null,
                    'phone' => $data['phone'],
                    'pin_no' => $data['pin_no'] ?? null,
                    'card_no' => $data['card_no'] ?? null,
                    'gender' => $data['gender'] ?? 'M',
                    'dob' => !empty($data['dob'])
                        ? Carbon::parse($data['dob'])->toDateString()
                        : Carbon::now()->subYears(18)->toDateString(),
                    'address' => $data['address'] ?? null,
                    'active' => true,
                    'branch_id' => $branch,
                    'input_by' => auth()->user()->username,
                    'created_at' => now(),
                ],
                ['code'],
                ['accno', 'name', 'email', 'phone', 'pin_no', 'actual_bal', 'card_no', 'gender', 'dob', 'address', 'active', 'branch_id', 'input_by', 'created_at']
            );


            //notify customer
            $ct = Loyalty::where('code', $data['code']);

            //post adjustment if customer has balance
            if ($init_bal > 0 && $ct->exists()) {

                $doc_no = LoyaltyService::generateTransDocNo($cp_id, $branch, 'AD+');

                LoyaltyService::postPointsAdjustment(
                    $cp_id,
                    $branch,
                    $doc_no,
                    'AD+',
                    $data['code'],
                    'ADJ' . $data['code'],
                    $init_bal,
                    99,
                    Auth::user()->username,
                    $notes = 'Initial imported balance for ' . $data['name']
                );
            }
           

            //notify customer
            $cts = Loyalty::where('code', $data['code']);
            if ($cts->exists()) {
                $cust = $cts->firstOrFail();

                event(new CustomerCreated($cp, $cust));
            }

            $connection->commit();

        } catch (\Throwable $th) {
            $connection = DB::connection('dynamic');
            if ($connection) {
                $connection->rollBack();
            }
            throw $th;
        }
    }

    public function uniqueBy()
    {
        return 'code';
    }

    public function rules(): array
    {
        return [
            '*.code' => ['required'],
            '*.name' => ['required'],
            '*.email' => ['nullable', 'email'],
            '*.phone' => ['required'],
            '*.gender' => ['nullable', 'string'],
            '*.dob' => ['nullable', 'date'],
            '*.address' => ['nullable'],
        ];
    }


    public function batchSize(): int
    {
        return 1000;
    }


    /**
     * Specify the chunk size for reading.
     */
    public function chunkSize(): int
    {
        return 1000;
    }

    /**
     * Handle row failures from validation.
     *
     * @param Failure ...$failures
     * @return void
     */
    public function onFailure(Failure ...$failures)
    {
        foreach ($failures as $failure) {
            $message = implode(', ', $failure->errors()) . ' on row ' . $failure->row();
            Log::error($message);
            session()->flash('error', $message);
        }

    }
}
