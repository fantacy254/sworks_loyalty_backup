<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;

class SmsNotification extends Notification
{
    private $message;
    private $senderId;
    private $template;
    private $company;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($message, $sender, $template, $company)
    {
        $this->message = $message;
        $this->senderId = $sender;
        $this->template = $template;
        $this->company = $company;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['textsms'];
    }

    /**
     * Get the vonage representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return mixed
     */
    public function toTextSms($notifiable)
    {
        return [
            'mobile' => $notifiable->routeNotificationForTextSms(),
            'message' => $this->message,
            'sender' => $this->senderId,
            'template' => $this->template,
            'company' => $this->company,
        ];
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
