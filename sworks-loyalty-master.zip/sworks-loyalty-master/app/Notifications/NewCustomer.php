<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NewCustomer extends Notification
{
    public $companyName;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($companyName)
    {
        $this->companyName = $companyName;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Account Creation Notification')
            ->greeting('Dear ' . $notifiable->name)
            ->line('Thank you for choosing ' . $this->companyName . '. We are excited to have you on board!')
            //->action('Notification Action', url('/'))
            ->line('To view your points balance and transaction history, portal will be available soon. In the meantime, you can visit our nearest branch to access your account information and enjoy our services.')
            ->line('If you have any questions or need assistance, feel free to reach out to our nearest branch.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
