<?php

namespace App\Notifications;

use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class RedemeedSmartPoints extends Notification
{
    public $companyName;
    public $branchName;
    public $voucher;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($companyName, $branchName, $voucher)
    {
        $this->companyName = $companyName;
        $this->branchName = $branchName;
        $this->voucher = $voucher;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Smart Loyalty points redeemed')
            ->greeting('Dear ' . $notifiable->name)
            ->line('Thank you for shopping with ' . $this->companyName . '~' . $this->branchName . '!')
            ->line('You have redeemed ' . $this->voucher->amount . ' smart points!')
            ->line('Voucher details;')
            ->line('Voucher No: ' . $this->voucher->doc_no)
            ->line('Value: ' . $this->voucher->amount)
            ->line('Expiry: ' . Carbon::parse($this->voucher->expiry)->format('jS F Y'))
            ->line('To view your points balance and transaction history, portal will be available soon. In the meantime, you can visit our nearest branch to access your account information and enjoy our services.')
            ->line('If you have any questions or need assistance, feel free to reach out to our nearest branch.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
