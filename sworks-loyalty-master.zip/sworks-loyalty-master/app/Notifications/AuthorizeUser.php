<?php

namespace App\Notifications;

use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\Cache;

class AuthorizeUser extends Notification
{

    public $authCode;

    public function __construct($code)
    {
        $this->authCode = $code;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Authorization code: ' . $this->authCode)
            ->greeting('Dear ' . '' . $notifiable->name)
            ->line('A sign in attempt requires further verification. To complete the sign in process, please enter the
            verification code provided below.')
            ->line('Your authorization code is, ' . $this->authCode)
            ->line('This code is only valid for 2 minute.')
            ->line('If you did not request this code, please ignore this email.')
            ->line('Thank you for using our application!')
            ->salutation('Regards,' . config('app.name'));
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
