<?php
// app/Notifications/Channels/TextSmsChannel.php
namespace App\Notifications\Channels;

use App\Notifications\SmsNotification;
use Illuminate\Notifications\Notification;
use App\Services\TextSmsService;
use Illuminate\Support\Facades\Log;

class TextSmsChannel
{
    protected $textSmsService;

    public function __construct(TextSmsService $textSmsService)
    {
        $this->textSmsService = $textSmsService;
    }

    public function send($notifiable, SmsNotification $notification)
    {
        try {

            $data = $notification->toTextSms($notifiable);

            if (!$data['mobile'] || !$data['message'] || !$data['sender']) {
                return;
            }

            $this->textSmsService->sendSms($data['mobile'], $data['message'], $data['sender'], $data['template'], $data['company']);

        } catch (\Throwable $th) {
            throw $th;
        }
    }
}
